# Copyright (c) Microsoft Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import datetime
import pathlib
import typing
from typing import Literal

from playwright._impl._api_structures import (
    BrowserBindResult,
    ClientCertificate,
    Cookie,
    DebuggerLocation,
    DebuggerPausedDetails,
    DropPayload,
    FilePayload,
    FloatRect,
    Geolocation,
    HttpCredentials,
    NameValue,
    PdfMargins,
    Position,
    ProxySettings,
    RemoteAddr,
    RequestSizes,
    ResourceTiming,
    ScreencastActionStyle,
    ScreencastFrame,
    ScreencastSize,
    SecurityDetails,
    SetCookieParam,
    SourceLocation,
    StorageState,
    TracingGroupLocation,
    ViewportSize,
    VirtualCredential,
    WebErrorLocation,
    WebMCPTool,
)
from playwright._impl._assertions import (
    APIResponseAssertions as APIResponseAssertionsImpl,
)
from playwright._impl._assertions import LocatorAssertions as LocatorAssertionsImpl
from playwright._impl._assertions import PageAssertions as PageAssertionsImpl
from playwright._impl._browser import Browser as BrowserImpl
from playwright._impl._browser_context import BrowserContext as BrowserContextImpl
from playwright._impl._browser_type import BrowserType as BrowserTypeImpl
from playwright._impl._cdp_session import CDPSession as CDPSessionImpl
from playwright._impl._clock import Clock as ClockImpl
from playwright._impl._console_message import ConsoleMessage as ConsoleMessageImpl
from playwright._impl._credentials import Credentials as CredentialsImpl
from playwright._impl._debugger import Debugger as DebuggerImpl
from playwright._impl._dialog import Dialog as DialogImpl
from playwright._impl._disposable import Disposable as DisposableImpl
from playwright._impl._download import Download as DownloadImpl
from playwright._impl._element_handle import ElementHandle as ElementHandleImpl
from playwright._impl._errors import Error
from playwright._impl._fetch import APIRequest as APIRequestImpl
from playwright._impl._fetch import APIRequestContext as APIRequestContextImpl
from playwright._impl._fetch import APIResponse as APIResponseImpl
from playwright._impl._file_chooser import FileChooser as FileChooserImpl
from playwright._impl._form_data import FormData
from playwright._impl._frame import Frame as FrameImpl
from playwright._impl._helper import to_milliseconds
from playwright._impl._input import Keyboard as KeyboardImpl
from playwright._impl._input import Mouse as MouseImpl
from playwright._impl._input import Touchscreen as TouchscreenImpl
from playwright._impl._js_handle import JSHandle as JSHandleImpl
from playwright._impl._locator import FrameLocator as FrameLocatorImpl
from playwright._impl._locator import Locator as LocatorImpl
from playwright._impl._network import Request as RequestImpl
from playwright._impl._network import Response as ResponseImpl
from playwright._impl._network import Route as RouteImpl
from playwright._impl._network import WebSocket as WebSocketImpl
from playwright._impl._network import WebSocketRoute as WebSocketRouteImpl
from playwright._impl._page import Page as PageImpl
from playwright._impl._page import Worker as WorkerImpl
from playwright._impl._playwright import Playwright as PlaywrightImpl
from playwright._impl._screencast import Screencast as ScreencastImpl
from playwright._impl._selectors import Selectors as SelectorsImpl
from playwright._impl._sync_base import (
    EventContextManager,
    SyncBase,
    SyncContextManager,
    mapping,
)
from playwright._impl._tracing import Tracing as TracingImpl
from playwright._impl._video import Video as VideoImpl
from playwright._impl._web_error import WebError as WebErrorImpl
from playwright._impl._web_storage import WebStorage as WebStorageImpl
from playwright._impl._webmcp import WebMCP as WebMCPImpl


class APIRequest(SyncBase):
    _impl_obj: APIRequestImpl

    def new_context(
        self,
        *,
        base_url: typing.Optional[str] = None,
        client_certificates: typing.Optional[typing.Sequence[ClientCertificate]] = None,
        extra_http_headers: typing.Optional[typing.Dict[str, str]] = None,
        fail_on_status_code: typing.Optional[bool] = None,
        http_credentials: typing.Optional[
            typing.Union[HttpCredentials, typing.Sequence[HttpCredentials]]
        ] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        max_redirects: typing.Optional[int] = None,
        proxy: typing.Optional[ProxySettings] = None,
        storage_state: typing.Optional[
            typing.Union[str, pathlib.Path, StorageState]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        user_agent: typing.Optional[str] = None,
    ) -> "APIRequestContext":
        """APIRequest.new_context

        Creates new instances of `APIRequestContext`.

        Parameters
        ----------
        base_url : Union[str, None]
            Methods like `api_request_context.get()` take the base URL into consideration by using the
            [`URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor for building the corresponding URL.
            Examples:
            - baseURL: `http://localhost:3000` and sending request to `/bar.html` results in `http://localhost:3000/bar.html`
            - baseURL: `http://localhost:3000/foo/` and sending request to `./bar.html` results in
              `http://localhost:3000/foo/bar.html`
            - baseURL: `http://localhost:3000/foo` (without trailing slash) and navigating to `./bar.html` results in
              `http://localhost:3000/bar.html`
        client_certificates : Union[Sequence[{origin: str, certPath: Union[pathlib.Path, str, None], cert: Union[bytes, None], keyPath: Union[pathlib.Path, str, None], key: Union[bytes, None], pfxPath: Union[pathlib.Path, str, None], pfx: Union[bytes, None], passphrase: Union[str, None]}], None]
            TLS Client Authentication allows the server to request a client certificate and verify it.

            **Details**

            An array of client certificates to be used. Each certificate object must have either both `certPath` and `keyPath`,
            a single `pfxPath`, or their corresponding direct value equivalents (`cert` and `key`, or `pfx`). Optionally,
            `passphrase` property should be provided if the certificate is encrypted. The `origin` property should be provided
            with an exact match to the request origin that the certificate is valid for.

            Client certificate authentication is only active when at least one client certificate is provided. If you want to
            reject all client certificates sent by the server, you need to provide a client certificate with an `origin` that
            does not match any of the domains you plan to visit.

            **NOTE** When using WebKit on macOS, accessing `localhost` will not pick up client certificates. You can make it
            work by replacing `localhost` with `local.playwright`.

        extra_http_headers : Union[Dict[str, str], None]
            An object containing additional HTTP headers to be sent with every request. Defaults to none.
        fail_on_status_code : Union[bool, None]
            Whether to throw on response codes other than 2xx and 3xx. By default response object is returned for all status
            codes.
        http_credentials : Union[Sequence[{username: str, password: str, origin: Union[str, None], send: Union["always", "unauthorized", None]}], {username: str, password: str, origin: Union[str, None], send: Union["always", "unauthorized", None]}, None]
            Credentials for [HTTP authentication](https://developer.mozilla.org/en-US/docs/Web/HTTP/Authentication). If no
            origin is specified, the username and password are sent to any servers upon unauthorized responses.

            Pass an array to use different credentials for different origins. The first entry that matches the request origin
            is used, and entries with no origin match any request.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects. This can be overwritten for each request
            individually.
        proxy : Union[{server: str, bypass: Union[str, None], username: Union[str, None], password: Union[str, None]}, None]
            Network proxy settings.
        storage_state : Union[pathlib.Path, str, {cookies: Sequence[{name: str, value: str, domain: str, path: str, expires: float, httpOnly: bool, secure: bool, sameSite: Union["Lax", "None", "Strict"]}], origins: Sequence[{origin: str, localStorage: Sequence[{name: str, value: str}]}]}, None]
            Populates context with given storage state. This option can be used to initialize context with logged-in
            information obtained via `browser_context.storage_state()` or `api_request_context.storage_state()`. Either a path
            to the file with saved storage, or the value returned by one of `browser_context.storage_state()` or
            `api_request_context.storage_state()` methods.
        timeout : Union[float, None]
            Maximum time in milliseconds to wait for the response. Defaults to `30000` (30 seconds). Pass `0` to disable
            timeout.
        user_agent : Union[str, None]
            Specific user agent to use in this context.

        Returns
        -------
        APIRequestContext
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.new_context(
                    baseURL=base_url,
                    clientCertificates=mapping.to_impl(client_certificates),
                    extraHTTPHeaders=mapping.to_impl(extra_http_headers),
                    failOnStatusCode=fail_on_status_code,
                    httpCredentials=mapping.to_impl(http_credentials),
                    ignoreHTTPSErrors=ignore_https_errors,
                    maxRedirects=max_redirects,
                    proxy=proxy,
                    storageState=storage_state,
                    timeout=to_milliseconds(timeout),
                    userAgent=user_agent,
                )
            )
        )


mapping.register(APIRequestImpl, APIRequest)


class APIRequestContext(SyncBase):
    _impl_obj: APIRequestContextImpl

    def add_cookies(self, cookies: typing.Sequence[SetCookieParam]) -> None:
        """APIRequestContext.add_cookies

        Adds cookies into this request context. They will be sent with matching subsequent requests. For
        `browser_context.request` and `page.request`, this is equivalent to calling `browser_context.add_cookies()` on the
        corresponding browser context.

        **Usage**

        ```py
        request.add_cookies([cookie_object1, cookie_object2])
        ```

        Parameters
        ----------
        cookies : Sequence[{name: str, value: str, url: Union[str, None], domain: Union[str, None], path: Union[str, None], expires: Union[float, None], httpOnly: Union[bool, None], secure: Union[bool, None], sameSite: Union["Lax", "None", "Strict", None], partitionKey: Union[str, None]}]
        """

        self._sync(self._impl_obj.add_cookies(cookies=mapping.to_impl(cookies)))

    def clear_cookies(
        self,
        *,
        domain: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        name: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        path: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> None:
        """APIRequestContext.clear_cookies

        Removes cookies from this request context. Accepts optional filter. For `browser_context.request` and
        `page.request`, this is equivalent to calling `browser_context.clear_cookies()` on the corresponding browser
        context.

        **Usage**

        ```py
        request.clear_cookies()
        request.clear_cookies(name=\"session-id\")
        request.clear_cookies(domain=\"my-origin.com\")
        request.clear_cookies(path=\"/api/v1\")
        request.clear_cookies(name=\"session-id\", domain=\"my-origin.com\")
        ```

        Parameters
        ----------
        domain : Union[Pattern[str], str, None]
            Only removes cookies with the given domain.
        name : Union[Pattern[str], str, None]
            Only removes cookies with the given name.
        path : Union[Pattern[str], str, None]
            Only removes cookies with the given path.
        """

        self._sync(self._impl_obj.clear_cookies(domain=domain, name=name, path=path))

    def cookies(
        self, urls: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None
    ) -> typing.List[Cookie]:
        """APIRequestContext.cookies

        If no URLs are specified, this method returns all cookies. If URLs are specified, only cookies that affect those
        URLs are returned. For `browser_context.request` and `page.request`, this is equivalent to calling
        `browser_context.cookies()` on the corresponding browser context.

        Parameters
        ----------
        urls : Union[Sequence[str], str, None]
            Optional list of URLs.

        Returns
        -------
        List[{name: str, value: str, domain: str, path: str, expires: float, httpOnly: bool, secure: bool, sameSite: Union["Lax", "None", "Strict"], partitionKey: Union[str, None]}]
        """

        return mapping.from_impl_list(
            self._sync(self._impl_obj.cookies(urls=mapping.to_impl(urls)))
        )

    def delete(
        self,
        url: str,
        *,
        data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        fail_on_status_code: typing.Optional[bool] = None,
        form: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], "FormData"]
        ] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        max_redirects: typing.Optional[int] = None,
        max_retries: typing.Optional[int] = None,
        multipart: typing.Optional[
            typing.Union[
                typing.Dict[str, typing.Union[str, float, bool, bytes, FilePayload]],
                "FormData",
            ]
        ] = None,
        params: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], str]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "APIResponse":
        """APIRequestContext.delete

        Sends HTTP(S) [DELETE](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/DELETE) request and returns its
        response. The method will populate request cookies from the context and update context cookies from the response.
        The method will automatically follow redirects.

        Parameters
        ----------
        url : str
            Target URL.
        data : Union[Any, bytes, str, None]
            Allows to set post data of the request. If the data parameter is an object, it will be serialized to json string
            and `content-type` header will be set to `application/json` if not explicitly set. Otherwise the `content-type`
            header will be set to `application/octet-stream` if not explicitly set.
        fail_on_status_code : Union[bool, None]
            Whether to throw on response codes other than 2xx and 3xx. By default response object is returned for all status
            codes.
        form : Union[Dict[str, Union[bool, float, str]], FormData, None]
            Provides an object that will be serialized as html form using `application/x-www-form-urlencoded` encoding and sent
            as this request body. If this parameter is specified `content-type` header will be set to
            `application/x-www-form-urlencoded` unless explicitly provided. Use `FormData` to send multiple values for the same
            field.
        headers : Union[Dict[str, str], None]
            Allows to set HTTP headers. These headers will apply to the fetched request as well as any redirects initiated by
            it.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects.
        max_retries : Union[int, None]
            Maximum number of times network errors should be retried. Currently only `ECONNRESET` error is retried. Does not
            retry based on HTTP response codes. An error will be thrown if the limit is exceeded. Defaults to `0` - no retries.
        multipart : Union[Dict[str, Union[bool, bytes, float, str, {name: str, mimeType: str, buffer: bytes}]], FormData, None]
            Provides an object that will be serialized as html form using `multipart/form-data` encoding and sent as this
            request body. If this parameter is specified `content-type` header will be set to `multipart/form-data` unless
            explicitly provided. File values can be passed as file-like object containing file name, mime-type and its content.
            Use `FormData` to send multiple files in the same field.
        params : Union[Dict[str, Union[bool, float, str]], str, None]
            Query parameters to be sent with the URL.
        timeout : Union[float, None]
            Request timeout in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        APIResponse
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.delete(
                    url=url,
                    data=mapping.to_impl(data),
                    failOnStatusCode=fail_on_status_code,
                    form=mapping.to_impl(form),
                    headers=mapping.to_impl(headers),
                    ignoreHTTPSErrors=ignore_https_errors,
                    maxRedirects=max_redirects,
                    maxRetries=max_retries,
                    multipart=mapping.to_impl(multipart),
                    params=mapping.to_impl(params),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def dispose(self, *, reason: typing.Optional[str] = None) -> None:
        """APIRequestContext.dispose

        All responses returned by `api_request_context.get()` and similar methods are stored in the memory, so that you can
        later call `api_response.body()`.This method discards all its resources, calling any method on disposed
        `APIRequestContext` will throw an exception.

        Parameters
        ----------
        reason : Union[str, None]
            The reason to be reported to the operations interrupted by the context disposal.
        """

        self._sync(self._impl_obj.dispose(reason=reason))

    def fetch(
        self,
        url_or_request: typing.Union[str, "Request"],
        *,
        data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        fail_on_status_code: typing.Optional[bool] = None,
        form: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], "FormData"]
        ] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        max_redirects: typing.Optional[int] = None,
        max_retries: typing.Optional[int] = None,
        method: typing.Optional[str] = None,
        multipart: typing.Optional[
            typing.Union[
                typing.Dict[str, typing.Union[str, float, bool, bytes, FilePayload]],
                "FormData",
            ]
        ] = None,
        params: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], str]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "APIResponse":
        """APIRequestContext.fetch

        Sends HTTP(S) request and returns its response. The method will populate request cookies from the context and
        update context cookies from the response. The method will automatically follow redirects.

        **Usage**

        JSON objects can be passed directly to the request:

        ```python
        data = {
            \"title\": \"Book Title\",
            \"body\": \"John Doe\",
        }
        api_request_context.fetch(\"https://example.com/api/createBook\", method=\"post\", data=data)
        ```

        The common way to send file(s) in the body of a request is to upload them as form fields with `multipart/form-data`
        encoding, by specifiying the `multipart` parameter:

        ```python
        api_request_context.fetch(
          \"https://example.com/api/uploadScript\",  method=\"post\",
          multipart={
            \"fileField\": {
              \"name\": \"f.js\",
              \"mimeType\": \"text/javascript\",
              \"buffer\": b\"console.log(2022);\",
            },
          })
        ```

        Parameters
        ----------
        url_or_request : Union[Request, str]
            Target URL or Request to get all parameters from.
        data : Union[Any, bytes, str, None]
            Allows to set post data of the request. If the data parameter is an object, it will be serialized to json string
            and `content-type` header will be set to `application/json` if not explicitly set. Otherwise the `content-type`
            header will be set to `application/octet-stream` if not explicitly set.
        fail_on_status_code : Union[bool, None]
            Whether to throw on response codes other than 2xx and 3xx. By default response object is returned for all status
            codes.
        form : Union[Dict[str, Union[bool, float, str]], FormData, None]
            Provides an object that will be serialized as html form using `application/x-www-form-urlencoded` encoding and sent
            as this request body. If this parameter is specified `content-type` header will be set to
            `application/x-www-form-urlencoded` unless explicitly provided. Use `FormData` to send multiple values for the same
            field.
        headers : Union[Dict[str, str], None]
            Allows to set HTTP headers. These headers will apply to the fetched request as well as any redirects initiated by
            it.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects.
        max_retries : Union[int, None]
            Maximum number of times network errors should be retried. Currently only `ECONNRESET` error is retried. Does not
            retry based on HTTP response codes. An error will be thrown if the limit is exceeded. Defaults to `0` - no retries.
        method : Union[str, None]
            If set changes the fetch method (e.g. [PUT](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/PUT) or
            [POST](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/POST)). If not specified, GET method is used.
        multipart : Union[Dict[str, Union[bool, bytes, float, str, {name: str, mimeType: str, buffer: bytes}]], FormData, None]
            Provides an object that will be serialized as html form using `multipart/form-data` encoding and sent as this
            request body. If this parameter is specified `content-type` header will be set to `multipart/form-data` unless
            explicitly provided. File values can be passed as file-like object containing file name, mime-type and its content.
            Use `FormData` to send multiple files in the same field.
        params : Union[Dict[str, Union[bool, float, str]], str, None]
            Query parameters to be sent with the URL.
        timeout : Union[float, None]
            Request timeout in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        APIResponse
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.fetch(
                    urlOrRequest=mapping.to_impl(url_or_request),
                    data=mapping.to_impl(data),
                    failOnStatusCode=fail_on_status_code,
                    form=mapping.to_impl(form),
                    headers=mapping.to_impl(headers),
                    ignoreHTTPSErrors=ignore_https_errors,
                    maxRedirects=max_redirects,
                    maxRetries=max_retries,
                    method=method,
                    multipart=mapping.to_impl(multipart),
                    params=mapping.to_impl(params),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def get(
        self,
        url: str,
        *,
        data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        fail_on_status_code: typing.Optional[bool] = None,
        form: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], "FormData"]
        ] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        max_redirects: typing.Optional[int] = None,
        max_retries: typing.Optional[int] = None,
        multipart: typing.Optional[
            typing.Union[
                typing.Dict[str, typing.Union[str, float, bool, bytes, FilePayload]],
                "FormData",
            ]
        ] = None,
        params: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], str]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "APIResponse":
        """APIRequestContext.get

        Sends HTTP(S) [GET](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/GET) request and returns its
        response. The method will populate request cookies from the context and update context cookies from the response.
        The method will automatically follow redirects.

        **Usage**

        Request parameters can be configured with `params` option, they will be serialized into the URL search parameters:

        ```python
        query_params = {
          \"isbn\": \"1234\",
          \"page\": \"23\"
        }
        api_request_context.get(\"https://example.com/api/getText\", params=query_params)
        ```

        Parameters
        ----------
        url : str
            Target URL.
        data : Union[Any, bytes, str, None]
            Allows to set post data of the request. If the data parameter is an object, it will be serialized to json string
            and `content-type` header will be set to `application/json` if not explicitly set. Otherwise the `content-type`
            header will be set to `application/octet-stream` if not explicitly set.
        fail_on_status_code : Union[bool, None]
            Whether to throw on response codes other than 2xx and 3xx. By default response object is returned for all status
            codes.
        form : Union[Dict[str, Union[bool, float, str]], FormData, None]
            Provides an object that will be serialized as html form using `application/x-www-form-urlencoded` encoding and sent
            as this request body. If this parameter is specified `content-type` header will be set to
            `application/x-www-form-urlencoded` unless explicitly provided. Use `FormData` to send multiple values for the same
            field.
        headers : Union[Dict[str, str], None]
            Allows to set HTTP headers. These headers will apply to the fetched request as well as any redirects initiated by
            it.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects.
        max_retries : Union[int, None]
            Maximum number of times network errors should be retried. Currently only `ECONNRESET` error is retried. Does not
            retry based on HTTP response codes. An error will be thrown if the limit is exceeded. Defaults to `0` - no retries.
        multipart : Union[Dict[str, Union[bool, bytes, float, str, {name: str, mimeType: str, buffer: bytes}]], FormData, None]
            Provides an object that will be serialized as html form using `multipart/form-data` encoding and sent as this
            request body. If this parameter is specified `content-type` header will be set to `multipart/form-data` unless
            explicitly provided. File values can be passed as file-like object containing file name, mime-type and its content.
            Use `FormData` to send multiple files in the same field.
        params : Union[Dict[str, Union[bool, float, str]], str, None]
            Query parameters to be sent with the URL.
        timeout : Union[float, None]
            Request timeout in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        APIResponse
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.get(
                    url=url,
                    data=mapping.to_impl(data),
                    failOnStatusCode=fail_on_status_code,
                    form=mapping.to_impl(form),
                    headers=mapping.to_impl(headers),
                    ignoreHTTPSErrors=ignore_https_errors,
                    maxRedirects=max_redirects,
                    maxRetries=max_retries,
                    multipart=mapping.to_impl(multipart),
                    params=mapping.to_impl(params),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def head(
        self,
        url: str,
        *,
        data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        fail_on_status_code: typing.Optional[bool] = None,
        form: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], "FormData"]
        ] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        max_redirects: typing.Optional[int] = None,
        max_retries: typing.Optional[int] = None,
        multipart: typing.Optional[
            typing.Union[
                typing.Dict[str, typing.Union[str, float, bool, bytes, FilePayload]],
                "FormData",
            ]
        ] = None,
        params: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], str]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "APIResponse":
        """APIRequestContext.head

        Sends HTTP(S) [HEAD](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD) request and returns its
        response. The method will populate request cookies from the context and update context cookies from the response.
        The method will automatically follow redirects.

        Parameters
        ----------
        url : str
            Target URL.
        data : Union[Any, bytes, str, None]
            Allows to set post data of the request. If the data parameter is an object, it will be serialized to json string
            and `content-type` header will be set to `application/json` if not explicitly set. Otherwise the `content-type`
            header will be set to `application/octet-stream` if not explicitly set.
        fail_on_status_code : Union[bool, None]
            Whether to throw on response codes other than 2xx and 3xx. By default response object is returned for all status
            codes.
        form : Union[Dict[str, Union[bool, float, str]], FormData, None]
            Provides an object that will be serialized as html form using `application/x-www-form-urlencoded` encoding and sent
            as this request body. If this parameter is specified `content-type` header will be set to
            `application/x-www-form-urlencoded` unless explicitly provided. Use `FormData` to send multiple values for the same
            field.
        headers : Union[Dict[str, str], None]
            Allows to set HTTP headers. These headers will apply to the fetched request as well as any redirects initiated by
            it.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects.
        max_retries : Union[int, None]
            Maximum number of times network errors should be retried. Currently only `ECONNRESET` error is retried. Does not
            retry based on HTTP response codes. An error will be thrown if the limit is exceeded. Defaults to `0` - no retries.
        multipart : Union[Dict[str, Union[bool, bytes, float, str, {name: str, mimeType: str, buffer: bytes}]], FormData, None]
            Provides an object that will be serialized as html form using `multipart/form-data` encoding and sent as this
            request body. If this parameter is specified `content-type` header will be set to `multipart/form-data` unless
            explicitly provided. File values can be passed as file-like object containing file name, mime-type and its content.
            Use `FormData` to send multiple files in the same field.
        params : Union[Dict[str, Union[bool, float, str]], str, None]
            Query parameters to be sent with the URL.
        timeout : Union[float, None]
            Request timeout in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        APIResponse
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.head(
                    url=url,
                    data=mapping.to_impl(data),
                    failOnStatusCode=fail_on_status_code,
                    form=mapping.to_impl(form),
                    headers=mapping.to_impl(headers),
                    ignoreHTTPSErrors=ignore_https_errors,
                    maxRedirects=max_redirects,
                    maxRetries=max_retries,
                    multipart=mapping.to_impl(multipart),
                    params=mapping.to_impl(params),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def patch(
        self,
        url: str,
        *,
        data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        fail_on_status_code: typing.Optional[bool] = None,
        form: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], "FormData"]
        ] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        max_redirects: typing.Optional[int] = None,
        max_retries: typing.Optional[int] = None,
        multipart: typing.Optional[
            typing.Union[
                typing.Dict[str, typing.Union[str, float, bool, bytes, FilePayload]],
                "FormData",
            ]
        ] = None,
        params: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], str]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "APIResponse":
        """APIRequestContext.patch

        Sends HTTP(S) [PATCH](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/PATCH) request and returns its
        response. The method will populate request cookies from the context and update context cookies from the response.
        The method will automatically follow redirects.

        Parameters
        ----------
        url : str
            Target URL.
        data : Union[Any, bytes, str, None]
            Allows to set post data of the request. If the data parameter is an object, it will be serialized to json string
            and `content-type` header will be set to `application/json` if not explicitly set. Otherwise the `content-type`
            header will be set to `application/octet-stream` if not explicitly set.
        fail_on_status_code : Union[bool, None]
            Whether to throw on response codes other than 2xx and 3xx. By default response object is returned for all status
            codes.
        form : Union[Dict[str, Union[bool, float, str]], FormData, None]
            Provides an object that will be serialized as html form using `application/x-www-form-urlencoded` encoding and sent
            as this request body. If this parameter is specified `content-type` header will be set to
            `application/x-www-form-urlencoded` unless explicitly provided. Use `FormData` to send multiple values for the same
            field.
        headers : Union[Dict[str, str], None]
            Allows to set HTTP headers. These headers will apply to the fetched request as well as any redirects initiated by
            it.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects.
        max_retries : Union[int, None]
            Maximum number of times network errors should be retried. Currently only `ECONNRESET` error is retried. Does not
            retry based on HTTP response codes. An error will be thrown if the limit is exceeded. Defaults to `0` - no retries.
        multipart : Union[Dict[str, Union[bool, bytes, float, str, {name: str, mimeType: str, buffer: bytes}]], FormData, None]
            Provides an object that will be serialized as html form using `multipart/form-data` encoding and sent as this
            request body. If this parameter is specified `content-type` header will be set to `multipart/form-data` unless
            explicitly provided. File values can be passed as file-like object containing file name, mime-type and its content.
            Use `FormData` to send multiple files in the same field.
        params : Union[Dict[str, Union[bool, float, str]], str, None]
            Query parameters to be sent with the URL.
        timeout : Union[float, None]
            Request timeout in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        APIResponse
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.patch(
                    url=url,
                    data=mapping.to_impl(data),
                    failOnStatusCode=fail_on_status_code,
                    form=mapping.to_impl(form),
                    headers=mapping.to_impl(headers),
                    ignoreHTTPSErrors=ignore_https_errors,
                    maxRedirects=max_redirects,
                    maxRetries=max_retries,
                    multipart=mapping.to_impl(multipart),
                    params=mapping.to_impl(params),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def post(
        self,
        url: str,
        *,
        data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        fail_on_status_code: typing.Optional[bool] = None,
        form: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], "FormData"]
        ] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        max_redirects: typing.Optional[int] = None,
        max_retries: typing.Optional[int] = None,
        multipart: typing.Optional[
            typing.Union[
                typing.Dict[str, typing.Union[str, float, bool, bytes, FilePayload]],
                "FormData",
            ]
        ] = None,
        params: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], str]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "APIResponse":
        """APIRequestContext.post

        Sends HTTP(S) [POST](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/POST) request and returns its
        response. The method will populate request cookies from the context and update context cookies from the response.
        The method will automatically follow redirects.

        **Usage**

        JSON objects can be passed directly to the request:

        ```python
        data = {
            \"title\": \"Book Title\",
            \"body\": \"John Doe\",
        }
        api_request_context.post(\"https://example.com/api/createBook\", data=data)
        ```

        To send form data to the server use `form` option. Its value will be encoded into the request body with
        `application/x-www-form-urlencoded` encoding (see below how to use `multipart/form-data` form encoding to send
        files):

        ```python
        formData = {
            \"title\": \"Book Title\",
            \"body\": \"John Doe\",
        }
        api_request_context.post(\"https://example.com/api/findBook\", form=formData)
        ```

        The common way to send file(s) in the body of a request is to upload them as form fields with `multipart/form-data`
        encoding. Use `FormData` to construct request body and pass it to the request as `multipart` parameter:

        ```python
        api_request_context.post(
          \"https://example.com/api/uploadScript'\",
          multipart={
            \"fileField\": {
              \"name\": \"f.js\",
              \"mimeType\": \"text/javascript\",
              \"buffer\": b\"console.log(2022);\",
            },
          })
        ```

        Parameters
        ----------
        url : str
            Target URL.
        data : Union[Any, bytes, str, None]
            Allows to set post data of the request. If the data parameter is an object, it will be serialized to json string
            and `content-type` header will be set to `application/json` if not explicitly set. Otherwise the `content-type`
            header will be set to `application/octet-stream` if not explicitly set.
        fail_on_status_code : Union[bool, None]
            Whether to throw on response codes other than 2xx and 3xx. By default response object is returned for all status
            codes.
        form : Union[Dict[str, Union[bool, float, str]], FormData, None]
            Provides an object that will be serialized as html form using `application/x-www-form-urlencoded` encoding and sent
            as this request body. If this parameter is specified `content-type` header will be set to
            `application/x-www-form-urlencoded` unless explicitly provided. Use `FormData` to send multiple values for the same
            field.
        headers : Union[Dict[str, str], None]
            Allows to set HTTP headers. These headers will apply to the fetched request as well as any redirects initiated by
            it.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects.
        max_retries : Union[int, None]
            Maximum number of times network errors should be retried. Currently only `ECONNRESET` error is retried. Does not
            retry based on HTTP response codes. An error will be thrown if the limit is exceeded. Defaults to `0` - no retries.
        multipart : Union[Dict[str, Union[bool, bytes, float, str, {name: str, mimeType: str, buffer: bytes}]], FormData, None]
            Provides an object that will be serialized as html form using `multipart/form-data` encoding and sent as this
            request body. If this parameter is specified `content-type` header will be set to `multipart/form-data` unless
            explicitly provided. File values can be passed as file-like object containing file name, mime-type and its content.
            Use `FormData` to send multiple files in the same field.
        params : Union[Dict[str, Union[bool, float, str]], str, None]
            Query parameters to be sent with the URL.
        timeout : Union[float, None]
            Request timeout in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        APIResponse
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.post(
                    url=url,
                    data=mapping.to_impl(data),
                    failOnStatusCode=fail_on_status_code,
                    form=mapping.to_impl(form),
                    headers=mapping.to_impl(headers),
                    ignoreHTTPSErrors=ignore_https_errors,
                    maxRedirects=max_redirects,
                    maxRetries=max_retries,
                    multipart=mapping.to_impl(multipart),
                    params=mapping.to_impl(params),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def put(
        self,
        url: str,
        *,
        data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        fail_on_status_code: typing.Optional[bool] = None,
        form: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], "FormData"]
        ] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        max_redirects: typing.Optional[int] = None,
        max_retries: typing.Optional[int] = None,
        multipart: typing.Optional[
            typing.Union[
                typing.Dict[str, typing.Union[str, float, bool, bytes, FilePayload]],
                "FormData",
            ]
        ] = None,
        params: typing.Optional[
            typing.Union[typing.Dict[str, typing.Union[str, float, bool]], str]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "APIResponse":
        """APIRequestContext.put

        Sends HTTP(S) [PUT](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/PUT) request and returns its
        response. The method will populate request cookies from the context and update context cookies from the response.
        The method will automatically follow redirects.

        Parameters
        ----------
        url : str
            Target URL.
        data : Union[Any, bytes, str, None]
            Allows to set post data of the request. If the data parameter is an object, it will be serialized to json string
            and `content-type` header will be set to `application/json` if not explicitly set. Otherwise the `content-type`
            header will be set to `application/octet-stream` if not explicitly set.
        fail_on_status_code : Union[bool, None]
            Whether to throw on response codes other than 2xx and 3xx. By default response object is returned for all status
            codes.
        form : Union[Dict[str, Union[bool, float, str]], FormData, None]
            Provides an object that will be serialized as html form using `application/x-www-form-urlencoded` encoding and sent
            as this request body. If this parameter is specified `content-type` header will be set to
            `application/x-www-form-urlencoded` unless explicitly provided. Use `FormData` to send multiple values for the same
            field.
        headers : Union[Dict[str, str], None]
            Allows to set HTTP headers. These headers will apply to the fetched request as well as any redirects initiated by
            it.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects.
        max_retries : Union[int, None]
            Maximum number of times network errors should be retried. Currently only `ECONNRESET` error is retried. Does not
            retry based on HTTP response codes. An error will be thrown if the limit is exceeded. Defaults to `0` - no retries.
        multipart : Union[Dict[str, Union[bool, bytes, float, str, {name: str, mimeType: str, buffer: bytes}]], FormData, None]
            Provides an object that will be serialized as html form using `multipart/form-data` encoding and sent as this
            request body. If this parameter is specified `content-type` header will be set to `multipart/form-data` unless
            explicitly provided. File values can be passed as file-like object containing file name, mime-type and its content.
            Use `FormData` to send multiple files in the same field.
        params : Union[Dict[str, Union[bool, float, str]], str, None]
            Query parameters to be sent with the URL.
        timeout : Union[float, None]
            Request timeout in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        APIResponse
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.put(
                    url=url,
                    data=mapping.to_impl(data),
                    failOnStatusCode=fail_on_status_code,
                    form=mapping.to_impl(form),
                    headers=mapping.to_impl(headers),
                    ignoreHTTPSErrors=ignore_https_errors,
                    maxRedirects=max_redirects,
                    maxRetries=max_retries,
                    multipart=mapping.to_impl(multipart),
                    params=mapping.to_impl(params),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def storage_state(
        self,
        *,
        indexed_db: typing.Optional[bool] = None,
        opfs: typing.Optional[bool] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
    ) -> StorageState:
        """APIRequestContext.storage_state

        Returns storage state for this request context, contains current cookies and local storage snapshot if it was
        passed to the constructor.

        Parameters
        ----------
        indexed_db : Union[bool, None]
            Set to `true` to include IndexedDB in the storage state snapshot.
        opfs : Union[bool, None]
            Set to `true` to include the origin private file system in the storage state snapshot.
        path : Union[pathlib.Path, str, None]
            The file path to save the storage state to. If `path` is a relative path, then it is resolved relative to current
            working directory. If no path is provided, storage state is still returned, but won't be saved to the disk.

        Returns
        -------
        {cookies: List[{name: str, value: str, domain: str, path: str, expires: float, httpOnly: bool, secure: bool, sameSite: Union["Lax", "None", "Strict"]}], origins: List[{origin: str, localStorage: List[{name: str, value: str}]}]}
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.storage_state(indexedDB=indexed_db, opfs=opfs, path=path)
            )
        )

    @property
    def tracing(self) -> "Tracing":
        """APIRequestContext.tracing

        Tracing recorder for requests made through this API request context.

        Returns
        -------
        Tracing
        """
        return mapping.from_impl(self._impl_obj.tracing)


mapping.register(APIRequestContextImpl, APIRequestContext)


class APIResponse(SyncBase):
    _impl_obj: APIResponseImpl

    def body(self) -> bytes:
        """APIResponse.body

        Returns the buffer with response body.

        Returns
        -------
        bytes
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.body()))

    def dispose(self) -> None:
        """APIResponse.dispose

        Disposes the body of this response. If not called then the body will stay in memory until the context closes.
        """

        self._sync(self._impl_obj.dispose())

    @property
    def headers(self) -> typing.Dict[str, str]:
        """APIResponse.headers

        An object with all the response HTTP headers associated with this response.

        Returns
        -------
        Dict[str, str]
        """
        return mapping.from_maybe_impl(self._impl_obj.headers)

    @property
    def headers_array(self) -> typing.List[NameValue]:
        """APIResponse.headers_array

        An array with all the response HTTP headers associated with this response. Header names are not lower-cased.
        Headers with multiple entries, such as `Set-Cookie`, appear in the array multiple times.

        Returns
        -------
        List[{name: str, value: str}]
        """
        return mapping.from_impl_list(self._impl_obj.headers_array)

    def json(self) -> typing.Any:
        """APIResponse.json

        Returns the JSON representation of response body.

        This method will throw if the response body is not parsable via `JSON.parse`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.json()))

    @property
    def ok(self) -> bool:
        """APIResponse.ok

        Contains a boolean stating whether the response was successful (status in the range 200-299) or not.

        Returns
        -------
        bool
        """
        return mapping.from_maybe_impl(self._impl_obj.ok)

    def security_details(self) -> typing.Optional[SecurityDetails]:
        """APIResponse.security_details

        Returns SSL and other security information. Resolves to `null` for non-HTTPS responses. For redirected requests,
        returns the information for the last request in the redirect chain.

        Returns
        -------
        Union[{issuer: Union[str, None], protocol: Union[str, None], subjectName: Union[str, None], validFrom: Union[float, None], validTo: Union[float, None]}, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.security_details()))

    def server_addr(self) -> typing.Optional[RemoteAddr]:
        """APIResponse.server_addr

        Returns the IP address and port of the server. Resolves to `null` if the server address is not available. For
        redirected requests, returns the information for the last request in the redirect chain.

        Returns
        -------
        Union[{ipAddress: str, port: int}, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.server_addr()))

    @property
    def status(self) -> int:
        """APIResponse.status

        Contains the status code of the response (e.g., 200 for a success).

        Returns
        -------
        int
        """
        return mapping.from_maybe_impl(self._impl_obj.status)

    @property
    def status_text(self) -> str:
        """APIResponse.status_text

        Contains the status text of the response (e.g. usually an \"OK\" for a success).

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.status_text)

    def text(self) -> str:
        """APIResponse.text

        Returns the text representation of response body.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.text()))

    @property
    def timing(self) -> ResourceTiming:
        """APIResponse.timing

        Returns resource timing information for given response. For redirected requests, returns the information for the
        last request in the redirect chain. When the response is served [from the HAR file](https://playwright.dev/python/docs/mock#replaying-from-har),
        timing information is not available and all the values are -1. Find more information at
        [Resource Timing API](https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming).

        Returns
        -------
        {startTime: float, domainLookupStart: float, domainLookupEnd: float, connectStart: float, secureConnectionStart: float, connectEnd: float, requestStart: float, responseStart: float, responseEnd: float}
        """
        return mapping.from_impl(self._impl_obj.timing)

    @property
    def url(self) -> str:
        """APIResponse.url

        Contains the URL of the response.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)


mapping.register(APIResponseImpl, APIResponse)


class APIResponseAssertions(SyncBase):
    _impl_obj: APIResponseAssertionsImpl

    def not_to_be_ok(self) -> None:
        """APIResponseAssertions.not_to_be_ok

        The opposite of `api_response_assertions.to_be_ok()`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.not_to_be_ok())

    def to_be_ok(self) -> None:
        """APIResponseAssertions.to_be_ok

        Ensures the response status code is within `200..299` range.

        **Usage**

        ```py
        import re
        from playwright.sync_api import expect

        # ...
        expect(response).to_be_ok()
        ```
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.to_be_ok())


mapping.register(APIResponseAssertionsImpl, APIResponseAssertions)


class Browser(SyncContextManager):
    _impl_obj: BrowserImpl

    def bind(
        self,
        title: str,
        *,
        host: typing.Optional[str] = None,
        port: typing.Optional[int] = None,
        workspace_dir: typing.Optional[str] = None,
    ) -> BrowserBindResult:
        """Browser.bind

        Binds the browser to a named pipe or web socket, making it available for other clients to connect to.

        Parameters
        ----------
        title : str
            Title of the browser server, used for identification.
        host : Union[str, None]
            Host to bind the web socket server to. When specified, a web socket server is created instead of a named pipe.
        port : Union[int, None]
            Port to bind the web socket server to. When specified, a web socket server is created instead of a named pipe. Use
            `0` to let the OS pick an available port.
        workspace_dir : Union[str, None]
            Working directory associated with this browser server.

        Returns
        -------
        {endpoint: str}
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.bind(
                    title=title, host=host, port=port, workspaceDir=workspace_dir
                )
            )
        )

    @property
    def browser_type(self) -> "BrowserType":
        """Browser.browser_type

        Get the browser type (chromium, firefox or webkit) that the browser belongs to.

        Returns
        -------
        BrowserType
        """
        return mapping.from_impl(self._impl_obj.browser_type)

    def close(self, *, reason: typing.Optional[str] = None) -> None:
        """Browser.close

        In case this browser is obtained using `browser_type.launch()`, closes the browser and all of its pages (if any
        were opened).

        In case this browser is connected to, clears all created contexts belonging to this browser and disconnects from
        the browser server.

        **NOTE** This is similar to force-quitting the browser. To close pages gracefully and ensure you receive page close
        events, call `browser_context.close()` on any `BrowserContext` instances you explicitly created earlier using
        `browser.new_context()` **before** calling `browser.close()`.

        The `Browser` object itself is considered to be disposed and cannot be used anymore.

        Parameters
        ----------
        reason : Union[str, None]
            The reason to be reported to the operations interrupted by the browser closure.
        """

        self._sync(self._impl_obj.close(reason=reason))

    @property
    def contexts(self) -> typing.List["BrowserContext"]:
        """Browser.contexts

        Returns an array of all open browser contexts. In a newly created browser, this will return zero browser contexts.

        **Usage**

        ```py
        browser = pw.webkit.launch()
        print(len(browser.contexts)) # prints `0`
        context = browser.new_context()
        print(len(browser.contexts)) # prints `1`
        ```

        Returns
        -------
        List[BrowserContext]
        """
        return mapping.from_impl_list(self._impl_obj.contexts)

    def is_connected(self) -> bool:
        """Browser.is_connected

        Indicates that the browser is connected.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._impl_obj.is_connected())

    def new_browser_cdp_session(self) -> "CDPSession":
        """Browser.new_browser_cdp_session

        **NOTE** CDP Sessions are only supported on Chromium-based browsers.

        Returns the newly created browser session.

        Returns
        -------
        CDPSession
        """

        return mapping.from_impl(self._sync(self._impl_obj.new_browser_cdp_session()))

    def new_context(
        self,
        *,
        accept_downloads: typing.Optional[bool] = None,
        base_url: typing.Optional[str] = None,
        bypass_csp: typing.Optional[bool] = None,
        client_certificates: typing.Optional[typing.Sequence[ClientCertificate]] = None,
        color_scheme: typing.Optional[
            Literal["dark", "light", "no-preference", "null"]
        ] = None,
        contrast: typing.Optional[Literal["more", "no-preference", "null"]] = None,
        default_browser_type: typing.Optional[str] = None,
        device_scale_factor: typing.Optional[float] = None,
        extra_http_headers: typing.Optional[typing.Dict[str, str]] = None,
        forced_colors: typing.Optional[Literal["active", "none", "null"]] = None,
        geolocation: typing.Optional[Geolocation] = None,
        has_touch: typing.Optional[bool] = None,
        http_credentials: typing.Optional[
            typing.Union[HttpCredentials, typing.Sequence[HttpCredentials]]
        ] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        is_mobile: typing.Optional[bool] = None,
        java_script_enabled: typing.Optional[bool] = None,
        locale: typing.Optional[str] = None,
        no_viewport: typing.Optional[bool] = None,
        offline: typing.Optional[bool] = None,
        permissions: typing.Optional[typing.Sequence[str]] = None,
        proxy: typing.Optional[ProxySettings] = None,
        record_har_content: typing.Optional[Literal["attach", "embed", "omit"]] = None,
        record_har_mode: typing.Optional[Literal["full", "minimal"]] = None,
        record_har_omit_content: typing.Optional[bool] = None,
        record_har_path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        record_har_url_filter: typing.Optional[
            typing.Union[str, typing.Pattern[str]]
        ] = None,
        record_video_dir: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        record_video_fps: typing.Optional[int] = None,
        record_video_size: typing.Optional[ViewportSize] = None,
        reduced_motion: typing.Optional[
            Literal["no-preference", "null", "reduce"]
        ] = None,
        screen: typing.Optional[ViewportSize] = None,
        service_workers: typing.Optional[Literal["allow", "block"]] = None,
        storage_state: typing.Optional[
            typing.Union[str, pathlib.Path, StorageState]
        ] = None,
        strict_selectors: typing.Optional[bool] = None,
        timezone_id: typing.Optional[str] = None,
        user_agent: typing.Optional[str] = None,
        viewport: typing.Optional[ViewportSize] = None,
    ) -> "BrowserContext":
        """Browser.new_context

        Creates a new browser context. It won't share cookies/cache with other browser contexts.

        **NOTE** If directly using this method to create `BrowserContext`s, it is best practice to explicitly close the
        returned context via `browser_context.close()` when your code is done with the `BrowserContext`, and before calling
        `browser.close()`. This will ensure the `context` is closed gracefully and any artifacts—like HARs and videos—are
        fully flushed and saved.

        **Usage**

        ```py
        browser = playwright.firefox.launch() # or \"chromium\" or \"webkit\".
        # create a new incognito browser context.
        context = browser.new_context()
        # create a new page in a pristine context.
        page = context.new_page()
        page.goto(\"https://example.com\")

        # gracefully close up everything
        context.close()
        browser.close()
        ```

        Parameters
        ----------
        accept_downloads : Union[bool, None]
            Whether to automatically download all the attachments. Defaults to `true` where all the downloads are accepted.
        base_url : Union[str, None]
            When using `page.goto()`, `page.route()`, `page.wait_for_url()`, `page.expect_request()`, or
            `page.expect_response()` it takes the base URL in consideration by using the
            [`URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor for building the corresponding URL.
            Unset by default. Examples:
            - baseURL: `http://localhost:3000` and navigating to `/bar.html` results in `http://localhost:3000/bar.html`
            - baseURL: `http://localhost:3000/foo/` and navigating to `./bar.html` results in
              `http://localhost:3000/foo/bar.html`
            - baseURL: `http://localhost:3000/foo` (without trailing slash) and navigating to `./bar.html` results in
              `http://localhost:3000/bar.html`
        bypass_csp : Union[bool, None]
            Toggles bypassing page's Content-Security-Policy. Defaults to `false`.
        client_certificates : Union[Sequence[{origin: str, certPath: Union[pathlib.Path, str, None], cert: Union[bytes, None], keyPath: Union[pathlib.Path, str, None], key: Union[bytes, None], pfxPath: Union[pathlib.Path, str, None], pfx: Union[bytes, None], passphrase: Union[str, None]}], None]
            TLS Client Authentication allows the server to request a client certificate and verify it.

            **Details**

            An array of client certificates to be used. Each certificate object must have either both `certPath` and `keyPath`,
            a single `pfxPath`, or their corresponding direct value equivalents (`cert` and `key`, or `pfx`). Optionally,
            `passphrase` property should be provided if the certificate is encrypted. The `origin` property should be provided
            with an exact match to the request origin that the certificate is valid for.

            Client certificate authentication is only active when at least one client certificate is provided. If you want to
            reject all client certificates sent by the server, you need to provide a client certificate with an `origin` that
            does not match any of the domains you plan to visit.

            **NOTE** When using WebKit on macOS, accessing `localhost` will not pick up client certificates. You can make it
            work by replacing `localhost` with `local.playwright`.

        color_scheme : Union["dark", "light", "no-preference", "null", None]
            Emulates [prefers-colors-scheme](https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-color-scheme)
            media feature, supported values are `'light'` and `'dark'`. See `page.emulate_media()` for more details. Passing
            `'null'` resets emulation to system defaults. Defaults to `'light'`.
        contrast : Union["more", "no-preference", "null", None]
            Emulates `'prefers-contrast'` media feature, supported values are `'no-preference'`, `'more'`. See
            `page.emulate_media()` for more details. Passing `'null'` resets emulation to system defaults. Defaults to
            `'no-preference'`.
        device_scale_factor : Union[float, None]
            Specify device scale factor (can be thought of as dpr). Defaults to `1`. Learn more about
            [emulating devices with device scale factor](../emulation.md#devices).
        extra_http_headers : Union[Dict[str, str], None]
            An object containing additional HTTP headers to be sent with every request. Defaults to none.
        forced_colors : Union["active", "none", "null", None]
            Emulates `'forced-colors'` media feature, supported values are `'active'`, `'none'`. See `page.emulate_media()` for
            more details. Passing `'null'` resets emulation to system defaults. Defaults to `'none'`.
        geolocation : Union[{latitude: float, longitude: float, accuracy: Union[float, None]}, None]
        has_touch : Union[bool, None]
            Specifies if viewport supports touch events. Defaults to false. Learn more about
            [mobile emulation](../emulation.md#devices).
        http_credentials : Union[Sequence[{username: str, password: str, origin: Union[str, None], send: Union["always", "unauthorized", None]}], {username: str, password: str, origin: Union[str, None], send: Union["always", "unauthorized", None]}, None]
            Credentials for [HTTP authentication](https://developer.mozilla.org/en-US/docs/Web/HTTP/Authentication). If no
            origin is specified, the username and password are sent to any servers upon unauthorized responses.

            Pass an array to use different credentials for different origins. The first entry that matches the request origin
            is used, and entries with no origin match any request.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        is_mobile : Union[bool, None]
            Whether the `meta viewport` tag is taken into account and touch events are enabled. isMobile is a part of device,
            so you don't actually need to set it manually. Defaults to `false`. Learn more about
            [mobile emulation](../emulation.md#ismobile).
        java_script_enabled : Union[bool, None]
            Whether or not to enable JavaScript in the context. Defaults to `true`. Learn more about
            [disabling JavaScript](../emulation.md#javascript-enabled).
        locale : Union[str, None]
            Specify user locale, for example `en-GB`, `de-DE`, etc. Locale will affect `navigator.language` value,
            `Accept-Language` request header value as well as number and date formatting rules. Defaults to the system default
            locale. Learn more about emulation in our [emulation guide](../emulation.md#locale--timezone).
        no_viewport : Union[bool, None]
            Does not enforce fixed viewport, allows resizing window in the headed mode.
        offline : Union[bool, None]
            Whether to emulate network being offline. Defaults to `false`. Learn more about
            [network emulation](../emulation.md#offline).
        permissions : Union[Sequence[str], None]
            A list of permissions to grant to all pages in this context. See `browser_context.grant_permissions()` for more
            details. Defaults to none.
        proxy : Union[{server: str, bypass: Union[str, None], username: Union[str, None], password: Union[str, None]}, None]
            Network proxy settings to use with this context. Defaults to none.
        record_har_content : Union["attach", "embed", "omit", None]
            Optional setting to control resource content management. If `omit` is specified, content is not persisted. If
            `attach` is specified, resources are persisted as separate files and all of these files are archived along with the
            HAR file. Defaults to `embed`, which stores content inline the HAR file as per HAR specification.
        record_har_mode : Union["full", "minimal", None]
            When set to `minimal`, only record information necessary for routing from HAR. This omits sizes, timing, page,
            cookies, security and other types of HAR information that are not used when replaying from HAR. Defaults to `full`.
        record_har_omit_content : Union[bool, None]
            Optional setting to control whether to omit request content from the HAR. Defaults to `false`.
        record_har_path : Union[pathlib.Path, str, None]
            Enables [HAR](http://www.softwareishard.com/blog/har-12-spec) recording for all pages into the specified HAR file
            on the filesystem. If not specified, the HAR is not recorded. Make sure to call `browser_context.close()` for the
            HAR to be saved.
        record_har_url_filter : Union[Pattern[str], str, None]
        record_video_dir : Union[pathlib.Path, str, None]
            Enables video recording for all pages into the specified directory. If not specified videos are not recorded. Make
            sure to call `browser_context.close()` for videos to be saved.
        record_video_fps : Union[int, None]
            Frame rate of the recorded videos in frames per second. Defaults to `25`. Firefox and WebKit currently capture up
            to 25 frames per second.
        record_video_size : Union[{width: int, height: int}, None]
            Dimensions of the recorded videos. If not specified the size will be equal to `viewport` scaled down to fit into
            800x800. If `viewport` is not configured explicitly the video size defaults to 800x450. Actual picture of each page
            will be scaled down if necessary to fit the specified size.
        reduced_motion : Union["no-preference", "null", "reduce", None]
            Emulates `'prefers-reduced-motion'` media feature, supported values are `'reduce'`, `'no-preference'`. See
            `page.emulate_media()` for more details. Passing `'null'` resets emulation to system defaults. Defaults to
            `'no-preference'`.
        screen : Union[{width: int, height: int}, None]
            Emulates consistent window screen size available inside web page via `window.screen`. Is only used when the
            `viewport` is set.
        service_workers : Union["allow", "block", None]
            Whether to allow sites to register Service workers. Defaults to `'allow'`.
            - `'allow'`: [Service Workers](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API) can be
              registered.
            - `'block'`: Playwright will block all registration of Service Workers.
        storage_state : Union[pathlib.Path, str, {cookies: Sequence[{name: str, value: str, domain: str, path: str, expires: float, httpOnly: bool, secure: bool, sameSite: Union["Lax", "None", "Strict"]}], origins: Sequence[{origin: str, localStorage: Sequence[{name: str, value: str}]}]}, None]
            Learn more about [storage state and auth](../auth.md).

            Populates context with given storage state. This option can be used to initialize context with logged-in
            information obtained via `browser_context.storage_state()`.
        strict_selectors : Union[bool, None]
            If set to true, enables strict selectors mode for this context. In the strict selectors mode all operations on
            selectors that imply single target DOM element will throw when more than one element matches the selector. This
            option does not affect any Locator APIs (Locators are always strict). Defaults to `false`. See `Locator` to learn
            more about the strict mode.
        timezone_id : Union[str, None]
            Changes the timezone of the context. See
            [ICU's metaZones.txt](https://cs.chromium.org/chromium/src/third_party/icu/source/data/misc/metaZones.txt?rcl=faee8bc70570192d82d2978a71e2a615788597d1)
            for a list of supported timezone IDs. Defaults to the system timezone.
        user_agent : Union[str, None]
            Specific user agent to use in this context.
        viewport : Union[{width: int, height: int}, None]
            Sets a consistent viewport for each page. Defaults to an 1280x720 viewport. `no_viewport` disables the fixed
            viewport. Learn more about [viewport emulation](../emulation.md#viewport).

        Returns
        -------
        BrowserContext
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.new_context(
                    acceptDownloads=accept_downloads,
                    baseURL=base_url,
                    bypassCSP=bypass_csp,
                    clientCertificates=mapping.to_impl(client_certificates),
                    colorScheme=color_scheme,
                    contrast=contrast,
                    defaultBrowserType=default_browser_type,
                    deviceScaleFactor=device_scale_factor,
                    extraHTTPHeaders=mapping.to_impl(extra_http_headers),
                    forcedColors=forced_colors,
                    geolocation=geolocation,
                    hasTouch=has_touch,
                    httpCredentials=mapping.to_impl(http_credentials),
                    ignoreHTTPSErrors=ignore_https_errors,
                    isMobile=is_mobile,
                    javaScriptEnabled=java_script_enabled,
                    locale=locale,
                    noViewport=no_viewport,
                    offline=offline,
                    permissions=mapping.to_impl(permissions),
                    proxy=proxy,
                    recordHarContent=record_har_content,
                    recordHarMode=record_har_mode,
                    recordHarOmitContent=record_har_omit_content,
                    recordHarPath=record_har_path,
                    recordHarUrlFilter=record_har_url_filter,
                    recordVideoDir=record_video_dir,
                    recordVideoFps=record_video_fps,
                    recordVideoSize=record_video_size,
                    reducedMotion=reduced_motion,
                    screen=screen,
                    serviceWorkers=service_workers,
                    storageState=storage_state,
                    strictSelectors=strict_selectors,
                    timezoneId=timezone_id,
                    userAgent=user_agent,
                    viewport=viewport,
                )
            )
        )

    def new_page(
        self,
        *,
        accept_downloads: typing.Optional[bool] = None,
        base_url: typing.Optional[str] = None,
        bypass_csp: typing.Optional[bool] = None,
        client_certificates: typing.Optional[typing.Sequence[ClientCertificate]] = None,
        color_scheme: typing.Optional[
            Literal["dark", "light", "no-preference", "null"]
        ] = None,
        contrast: typing.Optional[Literal["more", "no-preference", "null"]] = None,
        default_browser_type: typing.Optional[str] = None,
        device_scale_factor: typing.Optional[float] = None,
        extra_http_headers: typing.Optional[typing.Dict[str, str]] = None,
        forced_colors: typing.Optional[Literal["active", "none", "null"]] = None,
        geolocation: typing.Optional[Geolocation] = None,
        has_touch: typing.Optional[bool] = None,
        http_credentials: typing.Optional[
            typing.Union[HttpCredentials, typing.Sequence[HttpCredentials]]
        ] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        is_mobile: typing.Optional[bool] = None,
        java_script_enabled: typing.Optional[bool] = None,
        locale: typing.Optional[str] = None,
        no_viewport: typing.Optional[bool] = None,
        offline: typing.Optional[bool] = None,
        permissions: typing.Optional[typing.Sequence[str]] = None,
        proxy: typing.Optional[ProxySettings] = None,
        record_har_content: typing.Optional[Literal["attach", "embed", "omit"]] = None,
        record_har_mode: typing.Optional[Literal["full", "minimal"]] = None,
        record_har_omit_content: typing.Optional[bool] = None,
        record_har_path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        record_har_url_filter: typing.Optional[
            typing.Union[str, typing.Pattern[str]]
        ] = None,
        record_video_dir: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        record_video_fps: typing.Optional[int] = None,
        record_video_size: typing.Optional[ViewportSize] = None,
        reduced_motion: typing.Optional[
            Literal["no-preference", "null", "reduce"]
        ] = None,
        screen: typing.Optional[ViewportSize] = None,
        service_workers: typing.Optional[Literal["allow", "block"]] = None,
        storage_state: typing.Optional[
            typing.Union[str, pathlib.Path, StorageState]
        ] = None,
        strict_selectors: typing.Optional[bool] = None,
        timezone_id: typing.Optional[str] = None,
        user_agent: typing.Optional[str] = None,
        viewport: typing.Optional[ViewportSize] = None,
    ) -> "Page":
        """Browser.new_page

        Creates a new page in a new browser context. Closing this page will close the context as well.

        This is a convenience API that should only be used for the single-page scenarios and short snippets. Production
        code and testing frameworks should explicitly create `browser.new_context()` followed by the
        `browser_context.new_page()` to control their exact life times.

        Parameters
        ----------
        accept_downloads : Union[bool, None]
            Whether to automatically download all the attachments. Defaults to `true` where all the downloads are accepted.
        base_url : Union[str, None]
            When using `page.goto()`, `page.route()`, `page.wait_for_url()`, `page.expect_request()`, or
            `page.expect_response()` it takes the base URL in consideration by using the
            [`URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor for building the corresponding URL.
            Unset by default. Examples:
            - baseURL: `http://localhost:3000` and navigating to `/bar.html` results in `http://localhost:3000/bar.html`
            - baseURL: `http://localhost:3000/foo/` and navigating to `./bar.html` results in
              `http://localhost:3000/foo/bar.html`
            - baseURL: `http://localhost:3000/foo` (without trailing slash) and navigating to `./bar.html` results in
              `http://localhost:3000/bar.html`
        bypass_csp : Union[bool, None]
            Toggles bypassing page's Content-Security-Policy. Defaults to `false`.
        client_certificates : Union[Sequence[{origin: str, certPath: Union[pathlib.Path, str, None], cert: Union[bytes, None], keyPath: Union[pathlib.Path, str, None], key: Union[bytes, None], pfxPath: Union[pathlib.Path, str, None], pfx: Union[bytes, None], passphrase: Union[str, None]}], None]
            TLS Client Authentication allows the server to request a client certificate and verify it.

            **Details**

            An array of client certificates to be used. Each certificate object must have either both `certPath` and `keyPath`,
            a single `pfxPath`, or their corresponding direct value equivalents (`cert` and `key`, or `pfx`). Optionally,
            `passphrase` property should be provided if the certificate is encrypted. The `origin` property should be provided
            with an exact match to the request origin that the certificate is valid for.

            Client certificate authentication is only active when at least one client certificate is provided. If you want to
            reject all client certificates sent by the server, you need to provide a client certificate with an `origin` that
            does not match any of the domains you plan to visit.

            **NOTE** When using WebKit on macOS, accessing `localhost` will not pick up client certificates. You can make it
            work by replacing `localhost` with `local.playwright`.

        color_scheme : Union["dark", "light", "no-preference", "null", None]
            Emulates [prefers-colors-scheme](https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-color-scheme)
            media feature, supported values are `'light'` and `'dark'`. See `page.emulate_media()` for more details. Passing
            `'null'` resets emulation to system defaults. Defaults to `'light'`.
        contrast : Union["more", "no-preference", "null", None]
            Emulates `'prefers-contrast'` media feature, supported values are `'no-preference'`, `'more'`. See
            `page.emulate_media()` for more details. Passing `'null'` resets emulation to system defaults. Defaults to
            `'no-preference'`.
        device_scale_factor : Union[float, None]
            Specify device scale factor (can be thought of as dpr). Defaults to `1`. Learn more about
            [emulating devices with device scale factor](../emulation.md#devices).
        extra_http_headers : Union[Dict[str, str], None]
            An object containing additional HTTP headers to be sent with every request. Defaults to none.
        forced_colors : Union["active", "none", "null", None]
            Emulates `'forced-colors'` media feature, supported values are `'active'`, `'none'`. See `page.emulate_media()` for
            more details. Passing `'null'` resets emulation to system defaults. Defaults to `'none'`.
        geolocation : Union[{latitude: float, longitude: float, accuracy: Union[float, None]}, None]
        has_touch : Union[bool, None]
            Specifies if viewport supports touch events. Defaults to false. Learn more about
            [mobile emulation](../emulation.md#devices).
        http_credentials : Union[Sequence[{username: str, password: str, origin: Union[str, None], send: Union["always", "unauthorized", None]}], {username: str, password: str, origin: Union[str, None], send: Union["always", "unauthorized", None]}, None]
            Credentials for [HTTP authentication](https://developer.mozilla.org/en-US/docs/Web/HTTP/Authentication). If no
            origin is specified, the username and password are sent to any servers upon unauthorized responses.

            Pass an array to use different credentials for different origins. The first entry that matches the request origin
            is used, and entries with no origin match any request.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        is_mobile : Union[bool, None]
            Whether the `meta viewport` tag is taken into account and touch events are enabled. isMobile is a part of device,
            so you don't actually need to set it manually. Defaults to `false`. Learn more about
            [mobile emulation](../emulation.md#ismobile).
        java_script_enabled : Union[bool, None]
            Whether or not to enable JavaScript in the context. Defaults to `true`. Learn more about
            [disabling JavaScript](../emulation.md#javascript-enabled).
        locale : Union[str, None]
            Specify user locale, for example `en-GB`, `de-DE`, etc. Locale will affect `navigator.language` value,
            `Accept-Language` request header value as well as number and date formatting rules. Defaults to the system default
            locale. Learn more about emulation in our [emulation guide](../emulation.md#locale--timezone).
        no_viewport : Union[bool, None]
            Does not enforce fixed viewport, allows resizing window in the headed mode.
        offline : Union[bool, None]
            Whether to emulate network being offline. Defaults to `false`. Learn more about
            [network emulation](../emulation.md#offline).
        permissions : Union[Sequence[str], None]
            A list of permissions to grant to all pages in this context. See `browser_context.grant_permissions()` for more
            details. Defaults to none.
        proxy : Union[{server: str, bypass: Union[str, None], username: Union[str, None], password: Union[str, None]}, None]
            Network proxy settings to use with this context. Defaults to none.
        record_har_content : Union["attach", "embed", "omit", None]
            Optional setting to control resource content management. If `omit` is specified, content is not persisted. If
            `attach` is specified, resources are persisted as separate files and all of these files are archived along with the
            HAR file. Defaults to `embed`, which stores content inline the HAR file as per HAR specification.
        record_har_mode : Union["full", "minimal", None]
            When set to `minimal`, only record information necessary for routing from HAR. This omits sizes, timing, page,
            cookies, security and other types of HAR information that are not used when replaying from HAR. Defaults to `full`.
        record_har_omit_content : Union[bool, None]
            Optional setting to control whether to omit request content from the HAR. Defaults to `false`.
        record_har_path : Union[pathlib.Path, str, None]
            Enables [HAR](http://www.softwareishard.com/blog/har-12-spec) recording for all pages into the specified HAR file
            on the filesystem. If not specified, the HAR is not recorded. Make sure to call `browser_context.close()` for the
            HAR to be saved.
        record_har_url_filter : Union[Pattern[str], str, None]
        record_video_dir : Union[pathlib.Path, str, None]
            Enables video recording for all pages into the specified directory. If not specified videos are not recorded. Make
            sure to call `browser_context.close()` for videos to be saved.
        record_video_fps : Union[int, None]
            Frame rate of the recorded videos in frames per second. Defaults to `25`. Firefox and WebKit currently capture up
            to 25 frames per second.
        record_video_size : Union[{width: int, height: int}, None]
            Dimensions of the recorded videos. If not specified the size will be equal to `viewport` scaled down to fit into
            800x800. If `viewport` is not configured explicitly the video size defaults to 800x450. Actual picture of each page
            will be scaled down if necessary to fit the specified size.
        reduced_motion : Union["no-preference", "null", "reduce", None]
            Emulates `'prefers-reduced-motion'` media feature, supported values are `'reduce'`, `'no-preference'`. See
            `page.emulate_media()` for more details. Passing `'null'` resets emulation to system defaults. Defaults to
            `'no-preference'`.
        screen : Union[{width: int, height: int}, None]
            Emulates consistent window screen size available inside web page via `window.screen`. Is only used when the
            `viewport` is set.
        service_workers : Union["allow", "block", None]
            Whether to allow sites to register Service workers. Defaults to `'allow'`.
            - `'allow'`: [Service Workers](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API) can be
              registered.
            - `'block'`: Playwright will block all registration of Service Workers.
        storage_state : Union[pathlib.Path, str, {cookies: Sequence[{name: str, value: str, domain: str, path: str, expires: float, httpOnly: bool, secure: bool, sameSite: Union["Lax", "None", "Strict"]}], origins: Sequence[{origin: str, localStorage: Sequence[{name: str, value: str}]}]}, None]
            Learn more about [storage state and auth](../auth.md).

            Populates context with given storage state. This option can be used to initialize context with logged-in
            information obtained via `browser_context.storage_state()`.
        strict_selectors : Union[bool, None]
            If set to true, enables strict selectors mode for this context. In the strict selectors mode all operations on
            selectors that imply single target DOM element will throw when more than one element matches the selector. This
            option does not affect any Locator APIs (Locators are always strict). Defaults to `false`. See `Locator` to learn
            more about the strict mode.
        timezone_id : Union[str, None]
            Changes the timezone of the context. See
            [ICU's metaZones.txt](https://cs.chromium.org/chromium/src/third_party/icu/source/data/misc/metaZones.txt?rcl=faee8bc70570192d82d2978a71e2a615788597d1)
            for a list of supported timezone IDs. Defaults to the system timezone.
        user_agent : Union[str, None]
            Specific user agent to use in this context.
        viewport : Union[{width: int, height: int}, None]
            Sets a consistent viewport for each page. Defaults to an 1280x720 viewport. `no_viewport` disables the fixed
            viewport. Learn more about [viewport emulation](../emulation.md#viewport).

        Returns
        -------
        Page
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.new_page(
                    acceptDownloads=accept_downloads,
                    baseURL=base_url,
                    bypassCSP=bypass_csp,
                    clientCertificates=mapping.to_impl(client_certificates),
                    colorScheme=color_scheme,
                    contrast=contrast,
                    defaultBrowserType=default_browser_type,
                    deviceScaleFactor=device_scale_factor,
                    extraHTTPHeaders=mapping.to_impl(extra_http_headers),
                    forcedColors=forced_colors,
                    geolocation=geolocation,
                    hasTouch=has_touch,
                    httpCredentials=mapping.to_impl(http_credentials),
                    ignoreHTTPSErrors=ignore_https_errors,
                    isMobile=is_mobile,
                    javaScriptEnabled=java_script_enabled,
                    locale=locale,
                    noViewport=no_viewport,
                    offline=offline,
                    permissions=mapping.to_impl(permissions),
                    proxy=proxy,
                    recordHarContent=record_har_content,
                    recordHarMode=record_har_mode,
                    recordHarOmitContent=record_har_omit_content,
                    recordHarPath=record_har_path,
                    recordHarUrlFilter=record_har_url_filter,
                    recordVideoDir=record_video_dir,
                    recordVideoFps=record_video_fps,
                    recordVideoSize=record_video_size,
                    reducedMotion=reduced_motion,
                    screen=screen,
                    serviceWorkers=service_workers,
                    storageState=storage_state,
                    strictSelectors=strict_selectors,
                    timezoneId=timezone_id,
                    userAgent=user_agent,
                    viewport=viewport,
                )
            )
        )

    @typing.overload
    def on(
        self, event: Literal["context"], f: typing.Callable[["BrowserContext"], "None"]
    ) -> None:
        """
        Emitted when a new browser context is created."""

    @typing.overload
    def on(
        self, event: Literal["disconnected"], f: typing.Callable[["Browser"], "None"]
    ) -> None:
        """
        Emitted when Browser gets disconnected from the browser application. This might happen because of one of the
        following:
        - Browser application is closed or crashed.
        - The `browser.close()` method was called."""

    def on(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().on(event=event, f=f)

    @typing.overload
    def once(
        self, event: Literal["context"], f: typing.Callable[["BrowserContext"], "None"]
    ) -> None:
        """
        Emitted when a new browser context is created."""

    @typing.overload
    def once(
        self, event: Literal["disconnected"], f: typing.Callable[["Browser"], "None"]
    ) -> None:
        """
        Emitted when Browser gets disconnected from the browser application. This might happen because of one of the
        following:
        - Browser application is closed or crashed.
        - The `browser.close()` method was called."""

    def once(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().once(event=event, f=f)

    def start_tracing(
        self,
        *,
        categories: typing.Optional[typing.Sequence[str]] = None,
        page: typing.Optional["Page"] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        screenshots: typing.Optional[bool] = None,
    ) -> None:
        """Browser.start_tracing

        **NOTE** This API controls
        [Chromium Tracing](https://www.chromium.org/developers/how-tos/trace-event-profiling-tool) which is a low-level
        chromium-specific debugging tool. API to control [Playwright Tracing](https://playwright.dev/python/docs/trace-viewer) could be found
        [here](https://playwright.dev/python/docs/api/class-tracing).

        You can use `browser.start_tracing()` and `browser.stop_tracing()` to create a trace file that can be opened in
        Chrome DevTools performance panel.

        **Usage**

        ```py
        browser.start_tracing(page, path=\"trace.json\")
        page.goto(\"https://www.google.com\")
        browser.stop_tracing()
        ```

        Parameters
        ----------
        categories : Union[Sequence[str], None]
            specify custom categories to use instead of default.
        page : Union[Page, None]
            Optional, if specified, tracing includes screenshots of the given page.
        path : Union[pathlib.Path, str, None]
            A path to write the trace file to.
        screenshots : Union[bool, None]
            captures screenshots in the trace.
        """

        self._sync(
            self._impl_obj.start_tracing(
                categories=mapping.to_impl(categories),
                page=page._impl_obj if page else None,
                path=path,
                screenshots=screenshots,
            )
        )

    def stop_tracing(self) -> bytes:
        """Browser.stop_tracing

        **NOTE** This API controls
        [Chromium Tracing](https://www.chromium.org/developers/how-tos/trace-event-profiling-tool) which is a low-level
        chromium-specific debugging tool. API to control [Playwright Tracing](https://playwright.dev/python/docs/trace-viewer) could be found
        [here](https://playwright.dev/python/docs/api/class-tracing).

        Returns the buffer with trace data.

        Returns
        -------
        bytes
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.stop_tracing()))

    def unbind(self) -> None:
        """Browser.unbind

        Unbinds the browser server previously bound with `browser.bind()`.
        """

        self._sync(self._impl_obj.unbind())

    @property
    def version(self) -> str:
        """Browser.version

        Returns the browser version.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.version)


mapping.register(BrowserImpl, Browser)


class BrowserContext(SyncContextManager):
    _impl_obj: BrowserContextImpl

    def add_cookies(self, cookies: typing.Sequence[SetCookieParam]) -> None:
        """BrowserContext.add_cookies

        Adds cookies into this browser context. All pages within this context will have these cookies installed. Cookies
        can be obtained via `browser_context.cookies()`.

        **Usage**

        ```py
        browser_context.add_cookies([cookie_object1, cookie_object2])
        ```

        Parameters
        ----------
        cookies : Sequence[{name: str, value: str, url: Union[str, None], domain: Union[str, None], path: Union[str, None], expires: Union[float, None], httpOnly: Union[bool, None], secure: Union[bool, None], sameSite: Union["Lax", "None", "Strict", None], partitionKey: Union[str, None]}]
        """

        self._sync(self._impl_obj.add_cookies(cookies=mapping.to_impl(cookies)))

    def add_init_script(
        self,
        script: typing.Optional[str] = None,
        *,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
    ) -> "SyncContextManager":
        """BrowserContext.add_init_script

        Adds a script which would be evaluated in one of the following scenarios:
        - Whenever a page is created in the browser context or is navigated.
        - Whenever a child frame is attached or navigated in any page in the browser context. In this case, the script is
          evaluated in the context of the newly attached frame.

        The script is evaluated after the document was created but before any of its scripts were run. This is useful to
        amend the JavaScript environment, e.g. to seed `Math.random`.

        **Usage**

        An example of overriding `Math.random` before the page loads:

        ```py
        # in your playwright script, assuming the preload.js file is in same directory.
        browser_context.add_init_script(path=\"preload.js\")
        ```

        **NOTE** The order of evaluation of multiple scripts installed via `browser_context.add_init_script()` and
        `page.add_init_script()` is not defined.

        Parameters
        ----------
        script : Union[str, None]
            Script to be evaluated in all pages in the browser context. Optional.
        path : Union[pathlib.Path, str, None]
            Path to the JavaScript file. If `path` is a relative path, then it is resolved relative to the current working
            directory. Optional.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(self._impl_obj.add_init_script(script=script, path=path))
        )

    @property
    def background_pages(self) -> typing.List["Page"]:
        """BrowserContext.background_pages

        Returns an empty list.

        Returns
        -------
        List[Page]
        """
        return mapping.from_impl_list(self._impl_obj.background_pages)

    @property
    def browser(self) -> typing.Optional["Browser"]:
        """BrowserContext.browser

        Gets the browser instance that owns the context. Returns `null` if the context is created outside of normal
        browser, e.g. Android or Electron.

        Returns
        -------
        Union[Browser, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.browser)

    def clear_cookies(
        self,
        *,
        domain: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        name: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        path: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> None:
        """BrowserContext.clear_cookies

        Removes cookies from context. Accepts optional filter.

        **Usage**

        ```py
        context.clear_cookies()
        context.clear_cookies(name=\"session-id\")
        context.clear_cookies(domain=\"my-origin.com\")
        context.clear_cookies(path=\"/api/v1\")
        context.clear_cookies(name=\"session-id\", domain=\"my-origin.com\")
        ```

        Parameters
        ----------
        domain : Union[Pattern[str], str, None]
            Only removes cookies with the given domain.
        name : Union[Pattern[str], str, None]
            Only removes cookies with the given name.
        path : Union[Pattern[str], str, None]
            Only removes cookies with the given path.
        """

        self._sync(self._impl_obj.clear_cookies(domain=domain, name=name, path=path))

    def clear_permissions(self) -> None:
        """BrowserContext.clear_permissions

        Clears all permission overrides for the browser context.

        **Usage**

        ```py
        context = browser.new_context()
        context.grant_permissions([\"clipboard-read\"])
        # do stuff ..
        context.clear_permissions()
        ```
        """

        self._sync(self._impl_obj.clear_permissions())

    @property
    def clock(self) -> "Clock":
        """BrowserContext.clock

        Playwright has ability to mock clock and passage of time.

        Returns
        -------
        Clock
        """
        return mapping.from_impl(self._impl_obj.clock)

    def close(self, *, reason: typing.Optional[str] = None) -> None:
        """BrowserContext.close

        Closes the browser context. All the pages that belong to the browser context will be closed.

        **NOTE** The default browser context cannot be closed.

        Parameters
        ----------
        reason : Union[str, None]
            The reason to be reported to the operations interrupted by the context closure.
        """

        self._sync(self._impl_obj.close(reason=reason))

    def cookies(
        self, urls: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None
    ) -> typing.List[Cookie]:
        """BrowserContext.cookies

        If no URLs are specified, this method returns all cookies. If URLs are specified, only cookies that affect those
        URLs are returned.

        Parameters
        ----------
        urls : Union[Sequence[str], str, None]
            Optional list of URLs.

        Returns
        -------
        List[{name: str, value: str, domain: str, path: str, expires: float, httpOnly: bool, secure: bool, sameSite: Union["Lax", "None", "Strict"], partitionKey: Union[str, None]}]
        """

        return mapping.from_impl_list(
            self._sync(self._impl_obj.cookies(urls=mapping.to_impl(urls)))
        )

    @property
    def credentials(self) -> "Credentials":
        """BrowserContext.credentials

        Virtual WebAuthn authenticator for this context. Lets tests seed credentials and intercept
        `navigator.credentials.create()` / `navigator.credentials.get()` ceremonies.

        Returns
        -------
        Credentials
        """
        return mapping.from_impl(self._impl_obj.credentials)

    @property
    def debugger(self) -> "Debugger":
        """BrowserContext.debugger

        Debugger allows to pause and resume the execution.

        Returns
        -------
        Debugger
        """
        return mapping.from_impl(self._impl_obj.debugger)

    def expect_console_message(
        self,
        predicate: typing.Optional[typing.Callable[["ConsoleMessage"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["ConsoleMessage"]:
        """BrowserContext.expect_console_message

        Performs action and waits for a `ConsoleMessage` to be logged by in the pages in the context. If predicate is
        provided, it passes `ConsoleMessage` value into the `predicate` function and waits for `predicate(message)` to
        return a truthy value. Will throw an error if the page is closed before the `browser_context.on('console')` event
        is fired.

        Parameters
        ----------
        predicate : Union[Callable[[ConsoleMessage], bool], None]
            Receives the `ConsoleMessage` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[ConsoleMessage]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_console_message(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["backgroundpage"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["close"],
        predicate: typing.Optional[typing.Callable[["BrowserContext"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["BrowserContext"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["console"],
        predicate: typing.Optional[typing.Callable[["ConsoleMessage"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["ConsoleMessage"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["dialog"],
        predicate: typing.Optional[typing.Callable[["Dialog"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Dialog"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["dialogclosed"],
        predicate: typing.Optional[typing.Callable[["Dialog"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Dialog"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["download"],
        predicate: typing.Optional[typing.Callable[["Download"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Download"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["frameattached"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Frame"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["framedetached"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Frame"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["framenavigated"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Frame"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["page"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["pageclose"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["pageload"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["request"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Request"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["requestfailed"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Request"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["requestfinished"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Request"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["response"],
        predicate: typing.Optional[typing.Callable[["Response"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Response"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["serviceworker"],
        predicate: typing.Optional[typing.Callable[["Worker"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Worker"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["weberror"],
        predicate: typing.Optional[typing.Callable[["WebError"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["WebError"]: ...

    @typing.overload
    def expect_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable[..., bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager[typing.Any]: ...

    def expect_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager:
        """BrowserContext.expect_event

        Waits for event to fire and passes its value into the predicate function. Returns when the predicate returns truthy
        value. Will throw an error if the context closes before the event is fired. Returns the event data value.

        **Usage**

        ```py
        with context.expect_event(\"page\") as event_info:
            page.get_by_role(\"button\").click()
        page = event_info.value
        ```

        Parameters
        ----------
        event : str
            Event name, same one would pass into `browserContext.on(event)`.
        predicate : Union[Callable, None]
            Receives the event data and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_event(
                event=event,
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_page(
        self,
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["Page"]:
        """BrowserContext.expect_page

        Performs action and waits for a new `Page` to be created in the context. If predicate is provided, it passes `Page`
        value into the `predicate` function and waits for `predicate(event)` to return a truthy value. Will throw an error
        if the context closes before new `Page` is created.

        Parameters
        ----------
        predicate : Union[Callable[[Page], bool], None]
            Receives the `Page` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[Page]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_page(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expose_binding(
        self, name: str, callback: typing.Callable
    ) -> "SyncContextManager":
        """BrowserContext.expose_binding

        The method adds a function called `name` on the `window` object of every frame in every page in the context. When
        called, the function executes `callback` and returns a [Promise] which resolves to the return value of `callback`.
        If the `callback` returns a [Promise], it will be awaited.

        The first argument of the `callback` function contains information about the caller: `{ browserContext:
        BrowserContext, page: Page, frame: Frame }`.

        See `page.expose_binding()` for page-only version.

        **Usage**

        An example of exposing page URL to all frames in all pages in the context:

        ```py
        from playwright.sync_api import sync_playwright, Playwright

        def run(playwright: Playwright):
            webkit = playwright.webkit
            browser = webkit.launch(headless=False)
            context = browser.new_context()
            context.expose_binding(\"pageURL\", lambda source: source[\"page\"].url)
            page = context.new_page()
            page.set_content(\"\"\"
            <script>
              async function onClick() {
                document.querySelector('div').textContent = await window.pageURL();
              }
            </script>
            <button onclick=\"onClick()\">Click me</button>
            <div></div>
            \"\"\")
            page.get_by_role(\"button\").click()

        with sync_playwright() as playwright:
            run(playwright)
        ```

        Parameters
        ----------
        name : str
            Name of the function on the window object.
        callback : Callable
            Callback function that will be called in the Playwright's context.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.expose_binding(
                    name=name, callback=self._wrap_handler(callback)
                )
            )
        )

    def expose_function(
        self, name: str, callback: typing.Callable
    ) -> "SyncContextManager":
        """BrowserContext.expose_function

        The method adds a function called `name` on the `window` object of every frame in every page in the context. When
        called, the function executes `callback` and returns a [Promise] which resolves to the return value of `callback`.

        If the `callback` returns a [Promise], it will be awaited.

        See `page.expose_function()` for page-only version.

        **Usage**

        An example of adding a `sha256` function to all pages in the context:

        ```py
        import hashlib
        from playwright.sync_api import sync_playwright

        def sha256(text: str) -> str:
            m = hashlib.sha256()
            m.update(bytes(text, \"utf8\"))
            return m.hexdigest()

        def run(playwright: Playwright):
            webkit = playwright.webkit
            browser = webkit.launch(headless=False)
            context = browser.new_context()
            context.expose_function(\"sha256\", sha256)
            page = context.new_page()
            page.set_content(\"\"\"
                <script>
                  async function onClick() {
                    document.querySelector('div').textContent = await window.sha256('PLAYWRIGHT');
                  }
                </script>
                <button onclick=\"onClick()\">Click me</button>
                <div></div>
            \"\"\")
            page.get_by_role(\"button\").click()

        with sync_playwright() as playwright:
            run(playwright)
        ```

        Parameters
        ----------
        name : str
            Name of the function on the window object.
        callback : Callable
            Callback function that will be called in the Playwright's context.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.expose_function(
                    name=name, callback=self._wrap_handler(callback)
                )
            )
        )

    def grant_permissions(
        self, permissions: typing.Sequence[str], *, origin: typing.Optional[str] = None
    ) -> None:
        """BrowserContext.grant_permissions

        Grants specified permissions to the browser context. Only grants corresponding permissions to the given origin if
        specified.

        Parameters
        ----------
        permissions : Sequence[str]
            A list of permissions to grant.

            **NOTE** Supported permissions differ between browsers, and even between different versions of the same browser.
            Any permission may stop working after an update.

            Here are some permissions that may be supported by some browsers:
            - `'accelerometer'`
            - `'ambient-light-sensor'`
            - `'background-sync'`
            - `'camera'`
            - `'clipboard-read'`
            - `'clipboard-write'`
            - `'geolocation'`
            - `'gyroscope'`
            - `'local-fonts'`
            - `'local-network-access'`
            - `'magnetometer'`
            - `'microphone'`
            - `'midi-sysex'` (system-exclusive midi)
            - `'midi'`
            - `'notifications'`
            - `'payment-handler'`
            - `'storage-access'`
            - `'screen-wake-lock'`
        origin : Union[str, None]
            The [origin] to grant permissions to, e.g. "https://example.com".
        """

        self._sync(
            self._impl_obj.grant_permissions(
                permissions=mapping.to_impl(permissions), origin=origin
            )
        )

    def is_closed(self) -> bool:
        """BrowserContext.is_closed

        Indicates that the browser context is in the process of closing or has already been closed.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._impl_obj.is_closed())

    def new_cdp_session(self, page: typing.Union["Page", "Frame"]) -> "CDPSession":
        """BrowserContext.new_cdp_session

        **NOTE** CDP sessions are only supported on Chromium-based browsers.

        Returns the newly created session.

        Parameters
        ----------
        page : Union[Frame, Page]
            Target to create new session for. For backwards-compatibility, this parameter is named `page`, but it can be a
            `Page` or `Frame` type.

        Returns
        -------
        CDPSession
        """

        return mapping.from_impl(
            self._sync(self._impl_obj.new_cdp_session(page=mapping.to_impl(page)))
        )

    def new_page(self) -> "Page":
        """BrowserContext.new_page

        Creates a new page in the browser context.

        Returns
        -------
        Page
        """

        return mapping.from_impl(self._sync(self._impl_obj.new_page()))

    @typing.overload
    def on(
        self, event: Literal["backgroundpage"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        This event is not emitted."""

    @typing.overload
    def on(
        self, event: Literal["close"], f: typing.Callable[["BrowserContext"], "None"]
    ) -> None:
        """
        Emitted when Browser context gets closed. This might happen because of one of the following:
        - Browser context is closed.
        - Browser application is closed or crashed.
        - The `browser.close()` method was called."""

    @typing.overload
    def on(
        self, event: Literal["console"], f: typing.Callable[["ConsoleMessage"], "None"]
    ) -> None:
        """
        Emitted when JavaScript within the page calls one of console API methods, e.g. `console.log` or `console.dir`.

        The arguments passed into `console.log` and the page are available on the `ConsoleMessage` event handler argument.

        **Usage**

        ```py
        def print_args(msg):
            for arg in msg.args:
                print(arg.json_value())

        context.on(\"console\", print_args)
        page.evaluate(\"console.log('hello', 5, { foo: 'bar' })\")
        ```"""

    @typing.overload
    def on(
        self, event: Literal["dialog"], f: typing.Callable[["Dialog"], "None"]
    ) -> None:
        """
        Emitted when a JavaScript dialog appears, such as `alert`, `prompt`, `confirm` or `beforeunload`. Listener **must**
        either `dialog.accept()` or `dialog.dismiss()` the dialog - otherwise the page will
        [freeze](https://developer.mozilla.org/en-US/docs/Web/JavaScript/EventLoop#never_blocking) waiting for the dialog,
        and actions like click will never finish.

        **Usage**

        ```python
        context.on(\"dialog\", lambda dialog: dialog.accept())
        ```

        **NOTE** When no `page.on('dialog')` or `browser_context.on('dialog')` listeners are present, all dialogs are
        automatically dismissed."""

    @typing.overload
    def on(
        self, event: Literal["dialogclosed"], f: typing.Callable[["Dialog"], "None"]
    ) -> None:
        """
        Emitted when a JavaScript dialog in any page belonging to this context has been closed, either by
        `dialog.accept()`, by `dialog.dismiss()`, or manually by the user in the headed browser.
        """

    @typing.overload
    def on(
        self, event: Literal["download"], f: typing.Callable[["Download"], "None"]
    ) -> None:
        """
        Emitted when attachment download started in any page belonging to this context. User can access basic file
        operations on downloaded content via the passed `Download` instance. See also `page.on('download')` to receive
        events about a specific page."""

    @typing.overload
    def on(
        self, event: Literal["frameattached"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is attached in any page belonging to this context. See also `page.on('frameattached')` to
        receive events about a specific page."""

    @typing.overload
    def on(
        self, event: Literal["framedetached"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is detached in any page belonging to this context. See also `page.on('framedetached')` to
        receive events about a specific page."""

    @typing.overload
    def on(
        self, event: Literal["framenavigated"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is navigated to a new url in any page belonging to this context. See also
        `page.on('framenavigated')` to receive events about navigations in a specific page.
        """

    @typing.overload
    def on(self, event: Literal["page"], f: typing.Callable[["Page"], "None"]) -> None:
        """
        The event is emitted when a new Page is created in the BrowserContext. The page may still be loading. The event
        will also fire for popup pages. See also `page.on('popup')` to receive events about popups relevant to a specific
        page.

        The earliest moment that page is available is when it has navigated to the initial url. For example, when opening a
        popup with `window.open('http://example.com')`, this event will fire when the network request to
        \"http://example.com\" is done and its response has started loading in the popup. If you would like to route/listen
        to this network request, use `browser_context.route()` and `browser_context.on('request')` respectively instead of
        similar methods on the `Page`.

        ```py
        with context.expect_page() as page_info:
            page.get_by_text(\"open new page\").click(),
        page = page_info.value
        print(page.evaluate(\"location.href\"))
        ```

        **NOTE** Use `page.wait_for_load_state()` to wait until the page gets to a particular state (you should not need it
        in most cases)."""

    @typing.overload
    def on(
        self, event: Literal["pageclose"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when a page in this context is closed. See also `page.on('close')` to receive events about a specific page.
        """

    @typing.overload
    def on(
        self, event: Literal["pageload"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when the JavaScript [`load`](https://developer.mozilla.org/en-US/docs/Web/Events/load) event is dispatched
        in any page belonging to this context. See also `page.on('load')` to receive events about a specific page.
        """

    @typing.overload
    def on(
        self, event: Literal["request"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request is issued from any pages created through this context. The [request] object is read-only. To
        only listen for requests from a particular page, use `page.on('request')`.

        In order to intercept and mutate requests, see `browser_context.route()` or `page.route()`.
        """

    @typing.overload
    def on(
        self, event: Literal["requestfailed"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request fails, for example by timing out. To only listen for failed requests from a particular page,
        use `page.on('requestfailed')`.

        **NOTE** HTTP Error responses, such as 404 or 503, are still successful responses from HTTP standpoint, so request
        will complete with `browser_context.on('requestfinished')` event and not with
        `browser_context.on('requestfailed')`."""

    @typing.overload
    def on(
        self, event: Literal["requestfinished"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request finishes successfully after downloading the response body. For a successful response, the
        sequence of events is `request`, `response` and `requestfinished`. To listen for successful requests from a
        particular page, use `page.on('requestfinished')`."""

    @typing.overload
    def on(
        self, event: Literal["response"], f: typing.Callable[["Response"], "None"]
    ) -> None:
        """
        Emitted when [response] status and headers are received for a request. For a successful response, the sequence of
        events is `request`, `response` and `requestfinished`. To listen for response events from a particular page, use
        `page.on('response')`."""

    @typing.overload
    def on(
        self, event: Literal["serviceworker"], f: typing.Callable[["Worker"], "None"]
    ) -> None:
        """
        **NOTE** Service workers are only supported on Chromium-based browsers.

        Emitted when new service worker is created in the context."""

    @typing.overload
    def on(
        self, event: Literal["weberror"], f: typing.Callable[["WebError"], "None"]
    ) -> None:
        """
        Emitted when exception is unhandled in any of the pages in this context. To listen for errors from a particular
        page, use `page.on('pageerror')` instead."""

    def on(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().on(event=event, f=f)

    @typing.overload
    def once(
        self, event: Literal["backgroundpage"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        This event is not emitted."""

    @typing.overload
    def once(
        self, event: Literal["close"], f: typing.Callable[["BrowserContext"], "None"]
    ) -> None:
        """
        Emitted when Browser context gets closed. This might happen because of one of the following:
        - Browser context is closed.
        - Browser application is closed or crashed.
        - The `browser.close()` method was called."""

    @typing.overload
    def once(
        self, event: Literal["console"], f: typing.Callable[["ConsoleMessage"], "None"]
    ) -> None:
        """
        Emitted when JavaScript within the page calls one of console API methods, e.g. `console.log` or `console.dir`.

        The arguments passed into `console.log` and the page are available on the `ConsoleMessage` event handler argument.

        **Usage**

        ```py
        def print_args(msg):
            for arg in msg.args:
                print(arg.json_value())

        context.on(\"console\", print_args)
        page.evaluate(\"console.log('hello', 5, { foo: 'bar' })\")
        ```"""

    @typing.overload
    def once(
        self, event: Literal["dialog"], f: typing.Callable[["Dialog"], "None"]
    ) -> None:
        """
        Emitted when a JavaScript dialog appears, such as `alert`, `prompt`, `confirm` or `beforeunload`. Listener **must**
        either `dialog.accept()` or `dialog.dismiss()` the dialog - otherwise the page will
        [freeze](https://developer.mozilla.org/en-US/docs/Web/JavaScript/EventLoop#never_blocking) waiting for the dialog,
        and actions like click will never finish.

        **Usage**

        ```python
        context.on(\"dialog\", lambda dialog: dialog.accept())
        ```

        **NOTE** When no `page.on('dialog')` or `browser_context.on('dialog')` listeners are present, all dialogs are
        automatically dismissed."""

    @typing.overload
    def once(
        self, event: Literal["dialogclosed"], f: typing.Callable[["Dialog"], "None"]
    ) -> None:
        """
        Emitted when a JavaScript dialog in any page belonging to this context has been closed, either by
        `dialog.accept()`, by `dialog.dismiss()`, or manually by the user in the headed browser.
        """

    @typing.overload
    def once(
        self, event: Literal["download"], f: typing.Callable[["Download"], "None"]
    ) -> None:
        """
        Emitted when attachment download started in any page belonging to this context. User can access basic file
        operations on downloaded content via the passed `Download` instance. See also `page.on('download')` to receive
        events about a specific page."""

    @typing.overload
    def once(
        self, event: Literal["frameattached"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is attached in any page belonging to this context. See also `page.on('frameattached')` to
        receive events about a specific page."""

    @typing.overload
    def once(
        self, event: Literal["framedetached"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is detached in any page belonging to this context. See also `page.on('framedetached')` to
        receive events about a specific page."""

    @typing.overload
    def once(
        self, event: Literal["framenavigated"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is navigated to a new url in any page belonging to this context. See also
        `page.on('framenavigated')` to receive events about navigations in a specific page.
        """

    @typing.overload
    def once(
        self, event: Literal["page"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        The event is emitted when a new Page is created in the BrowserContext. The page may still be loading. The event
        will also fire for popup pages. See also `page.on('popup')` to receive events about popups relevant to a specific
        page.

        The earliest moment that page is available is when it has navigated to the initial url. For example, when opening a
        popup with `window.open('http://example.com')`, this event will fire when the network request to
        \"http://example.com\" is done and its response has started loading in the popup. If you would like to route/listen
        to this network request, use `browser_context.route()` and `browser_context.on('request')` respectively instead of
        similar methods on the `Page`.

        ```py
        with context.expect_page() as page_info:
            page.get_by_text(\"open new page\").click(),
        page = page_info.value
        print(page.evaluate(\"location.href\"))
        ```

        **NOTE** Use `page.wait_for_load_state()` to wait until the page gets to a particular state (you should not need it
        in most cases)."""

    @typing.overload
    def once(
        self, event: Literal["pageclose"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when a page in this context is closed. See also `page.on('close')` to receive events about a specific page.
        """

    @typing.overload
    def once(
        self, event: Literal["pageload"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when the JavaScript [`load`](https://developer.mozilla.org/en-US/docs/Web/Events/load) event is dispatched
        in any page belonging to this context. See also `page.on('load')` to receive events about a specific page.
        """

    @typing.overload
    def once(
        self, event: Literal["request"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request is issued from any pages created through this context. The [request] object is read-only. To
        only listen for requests from a particular page, use `page.on('request')`.

        In order to intercept and mutate requests, see `browser_context.route()` or `page.route()`.
        """

    @typing.overload
    def once(
        self, event: Literal["requestfailed"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request fails, for example by timing out. To only listen for failed requests from a particular page,
        use `page.on('requestfailed')`.

        **NOTE** HTTP Error responses, such as 404 or 503, are still successful responses from HTTP standpoint, so request
        will complete with `browser_context.on('requestfinished')` event and not with
        `browser_context.on('requestfailed')`."""

    @typing.overload
    def once(
        self, event: Literal["requestfinished"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request finishes successfully after downloading the response body. For a successful response, the
        sequence of events is `request`, `response` and `requestfinished`. To listen for successful requests from a
        particular page, use `page.on('requestfinished')`."""

    @typing.overload
    def once(
        self, event: Literal["response"], f: typing.Callable[["Response"], "None"]
    ) -> None:
        """
        Emitted when [response] status and headers are received for a request. For a successful response, the sequence of
        events is `request`, `response` and `requestfinished`. To listen for response events from a particular page, use
        `page.on('response')`."""

    @typing.overload
    def once(
        self, event: Literal["serviceworker"], f: typing.Callable[["Worker"], "None"]
    ) -> None:
        """
        **NOTE** Service workers are only supported on Chromium-based browsers.

        Emitted when new service worker is created in the context."""

    @typing.overload
    def once(
        self, event: Literal["weberror"], f: typing.Callable[["WebError"], "None"]
    ) -> None:
        """
        Emitted when exception is unhandled in any of the pages in this context. To listen for errors from a particular
        page, use `page.on('pageerror')` instead."""

    def once(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().once(event=event, f=f)

    @property
    def pages(self) -> typing.List["Page"]:
        """BrowserContext.pages

        Returns all open pages in the context.

        Returns
        -------
        List[Page]
        """
        return mapping.from_impl_list(self._impl_obj.pages)

    @property
    def request(self) -> "APIRequestContext":
        """BrowserContext.request

        API testing helper associated with this context. Requests made with this API will use context cookies.

        Returns
        -------
        APIRequestContext
        """
        return mapping.from_impl(self._impl_obj.request)

    def route(
        self,
        url: typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]],
        handler: typing.Union[
            typing.Callable[["Route"], typing.Any],
            typing.Callable[["Route", "Request"], typing.Any],
        ],
        *,
        times: typing.Optional[int] = None,
    ) -> "SyncContextManager":
        """BrowserContext.route

        Routing provides the capability to modify network requests that are made by any page in the browser context. Once
        route is enabled, every request matching the url pattern will stall unless it's continued, fulfilled or aborted.

        **NOTE** `browser_context.route()` will not intercept requests intercepted by Service Worker. See
        [this](https://github.com/microsoft/playwright/issues/1090) issue. We recommend disabling Service Workers when
        using request interception by setting `service_workers` to `'block'`.

        **Usage**

        An example of a naive handler that aborts all image requests:

        ```py
        context = browser.new_context()
        page = context.new_page()
        context.route(\"**/*.{png,jpg,jpeg}\", lambda route: route.abort())
        page.goto(\"https://example.com\")
        browser.close()
        ```

        or the same snippet using a regex pattern instead:

        ```py
        context = browser.new_context()
        page = context.new_page()
        context.route(re.compile(r\"(\\.png$)|(\\.jpg$)\"), lambda route: route.abort())
        page = await context.new_page()
        page = context.new_page()
        page.goto(\"https://example.com\")
        browser.close()
        ```

        It is possible to examine the request to decide the route action. For example, mocking all requests that contain
        some post data, and leaving all other requests as is:

        ```py
        def handle_route(route: Route):
          if (\"my-string\" in route.request.post_data):
            route.fulfill(body=\"mocked-data\")
          else:
            route.continue_()
        context.route(\"/api/**\", handle_route)
        ```

        Page routes (set up with `page.route()`) take precedence over browser context routes when request matches both
        handlers.

        To remove a route with its handler you can use `browser_context.unroute()`.

        **NOTE** Enabling routing disables http cache.

        Parameters
        ----------
        url : Union[Callable[[str], bool], Pattern[str], str]
            A glob pattern, regex pattern, or predicate that receives a [URL] to match during routing. If `base_url` is set in
            the context options and the provided URL is a string that does not start with `*`, it is resolved using the
            [`new URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor.
        handler : Union[Callable[[Route, Request], Any], Callable[[Route], Any]]
            handler function to route the request.
        times : Union[int, None]
            How often a route should be used. By default it will be used every time.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.route(
                    url=self._wrap_handler(url),
                    handler=self._wrap_handler(handler),
                    times=times,
                )
            )
        )

    def route_from_har(
        self,
        har: typing.Union[str, pathlib.Path],
        *,
        not_found: typing.Optional[Literal["abort", "fallback"]] = None,
        update: typing.Optional[bool] = None,
        update_content: typing.Optional[Literal["attach", "embed"]] = None,
        update_mode: typing.Optional[Literal["full", "minimal"]] = None,
        url: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> None:
        """BrowserContext.route_from_har

        If specified the network requests that are made in the context will be served from the HAR file. Read more about
        [Replaying from HAR](https://playwright.dev/python/docs/mock#replaying-from-har).

        Playwright will not serve requests intercepted by Service Worker from the HAR file. See
        [this](https://github.com/microsoft/playwright/issues/1090) issue. We recommend disabling Service Workers when
        using request interception by setting `service_workers` to `'block'`.

        Parameters
        ----------
        har : Union[pathlib.Path, str]
            Path to a [HAR](http://www.softwareishard.com/blog/har-12-spec) file with prerecorded network data. If `path` is a
            relative path, then it is resolved relative to the current working directory.
        not_found : Union["abort", "fallback", None]
            - If set to 'abort' any request not found in the HAR file will be aborted.
            - If set to 'fallback' falls through to the next route handler in the handler chain.

            Defaults to abort.
        update : Union[bool, None]
            If specified, updates the given HAR with the actual network information instead of serving from file. The file is
            written to disk when `browser_context.close()` is called.
        update_content : Union["attach", "embed", None]
            Optional setting to control resource content management. If `attach` is specified, resources are persisted as
            separate files or entries in the ZIP archive. If `embed` is specified, content is stored inline the HAR file.
        update_mode : Union["full", "minimal", None]
            When set to `minimal`, only record information necessary for routing from HAR. This omits sizes, timing, page,
            cookies, security and other types of HAR information that are not used when replaying from HAR. Defaults to
            `minimal`.
        url : Union[Pattern[str], str, None]
            A glob pattern, regular expression or predicate to match the request URL. Only requests with URL matching the
            pattern will be served from the HAR file. If not specified, all requests are served from the HAR file.
        """

        self._sync(
            self._impl_obj.route_from_har(
                har=har,
                notFound=not_found,
                update=update,
                updateContent=update_content,
                updateMode=update_mode,
                url=url,
            )
        )

    def route_web_socket(
        self,
        url: typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]],
        handler: typing.Callable[["WebSocketRoute"], typing.Any],
    ) -> None:
        """BrowserContext.route_web_socket

        This method allows to modify websocket connections that are made by any page in the browser context.

        Note that only `WebSocket`s created after this method was called will be routed. It is recommended to call this
        method before creating any pages.

        **Usage**

        Below is an example of a simple handler that blocks some websocket messages. See `WebSocketRoute` for more details
        and examples.

        ```py
        def message_handler(ws: WebSocketRoute, message: Union[str, bytes]):
          if message == \"to-be-blocked\":
            return
          ws.send(message)

        def handler(ws: WebSocketRoute):
          ws.route_send(lambda message: message_handler(ws, message))
          ws.connect()

        context.route_web_socket(\"/ws\", handler)
        ```

        Parameters
        ----------
        url : Union[Callable[[str], bool], Pattern[str], str]
            Only WebSockets with the url matching this pattern will be routed. A string pattern can be relative to the
            `base_url` context option.
        handler : Callable[[WebSocketRoute], Any]
            Handler function to route the WebSocket.
        """

        self._sync(
            self._impl_obj.route_web_socket(
                url=self._wrap_handler(url), handler=self._wrap_handler(handler)
            )
        )

    @property
    def service_workers(self) -> typing.List["Worker"]:
        """BrowserContext.service_workers

        **NOTE** Service workers are only supported on Chromium-based browsers.

        All existing service workers in the context.

        Returns
        -------
        List[Worker]
        """
        return mapping.from_impl_list(self._impl_obj.service_workers)

    def set_default_navigation_timeout(
        self, timeout: typing.Union[float, datetime.timedelta]
    ) -> None:
        """BrowserContext.set_default_navigation_timeout

        This setting will change the default maximum navigation time for the following methods and related shortcuts:
        - `page.go_back()`
        - `page.go_forward()`
        - `page.goto()`
        - `page.reload()`
        - `page.set_content()`
        - `page.expect_navigation()`

        **NOTE** `page.set_default_navigation_timeout()` and `page.set_default_timeout()` take priority over
        `browser_context.set_default_navigation_timeout()`.

        Parameters
        ----------
        timeout : float
            Maximum navigation time in milliseconds
        """

        self._impl_obj.set_default_navigation_timeout(timeout=to_milliseconds(timeout))

    def set_default_timeout(
        self, timeout: typing.Union[float, datetime.timedelta]
    ) -> None:
        """BrowserContext.set_default_timeout

        This setting will change the default maximum time for all the methods accepting `timeout` option.

        **NOTE** `page.set_default_navigation_timeout()`, `page.set_default_timeout()` and
        `browser_context.set_default_navigation_timeout()` take priority over `browser_context.set_default_timeout()`.

        Parameters
        ----------
        timeout : float
            Maximum time in milliseconds. Pass `0` to disable timeout.
        """

        self._impl_obj.set_default_timeout(timeout=to_milliseconds(timeout))

    def set_extra_http_headers(self, headers: typing.Dict[str, str]) -> None:
        """BrowserContext.set_extra_http_headers

        The extra HTTP headers will be sent with every request initiated by any page in the context. These headers are
        merged with page-specific extra HTTP headers set with `page.set_extra_http_headers()`. If page overrides a
        particular header, page-specific header value will be used instead of the browser context header value.

        **NOTE** `browser_context.set_extra_http_headers()` does not guarantee the order of headers in the outgoing
        requests.

        Parameters
        ----------
        headers : Dict[str, str]
            An object containing additional HTTP headers to be sent with every request. All header values must be strings.
        """

        self._sync(
            self._impl_obj.set_extra_http_headers(headers=mapping.to_impl(headers))
        )

    def set_geolocation(self, geolocation: typing.Optional[Geolocation] = None) -> None:
        """BrowserContext.set_geolocation

        Sets the context's geolocation. Passing `null` or `undefined` emulates position unavailable.

        **Usage**

        ```py
        browser_context.set_geolocation({\"latitude\": 59.95, \"longitude\": 30.31667})
        ```

        **NOTE** Consider using `browser_context.grant_permissions()` to grant permissions for the browser context pages to
        read its geolocation.

        Parameters
        ----------
        geolocation : Union[{latitude: float, longitude: float, accuracy: Union[float, None]}, None]
        """

        self._sync(self._impl_obj.set_geolocation(geolocation=geolocation))

    def set_offline(self, offline: bool) -> None:
        """BrowserContext.set_offline

        Parameters
        ----------
        offline : bool
            Whether to emulate network being offline for the browser context.

            **NOTE** Offline emulation only affects requests that go through the browser's regular network stack, such as page
            navigations, `fetch()`, `XMLHttpRequest` and WebSockets. It does not affect WebRTC traffic: established
            `RTCPeerConnection`s keep sending and receiving media over UDP. To test WebRTC connection loss, interrupt the
            connection outside the browser, for example by stopping the TURN server or using an OS-level firewall.

        """

        self._sync(self._impl_obj.set_offline(offline=offline))

    def set_storage_state(
        self, storage_state: typing.Union[str, pathlib.Path, StorageState]
    ) -> None:
        """BrowserContext.set_storage_state

        Clears the existing cookies, local storage, IndexedDB entries, origin private file system entries and virtual
        WebAuthn credentials, and sets the new storage state. When the storage state contains credentials, the virtual
        WebAuthn authenticator is installed (equivalent to `credentials.install()`), preventing all real authenticators
        from working in this context.

        **Usage**

        ```py
        # Load storage state from a file and apply it to the context.
        context.set_storage_state(\"state.json\")
        ```

        Parameters
        ----------
        storage_state : Union[pathlib.Path, str, {cookies: Sequence[{name: str, value: str, domain: str, path: str, expires: float, httpOnly: bool, secure: bool, sameSite: Union["Lax", "None", "Strict"]}], origins: Sequence[{origin: str, localStorage: Sequence[{name: str, value: str}]}]}]
            Learn more about [storage state and auth](../auth.md).

            Populates context with given storage state. This option can be used to initialize context with logged-in
            information obtained via `browser_context.storage_state()`.
        """

        self._sync(self._impl_obj.set_storage_state(storageState=storage_state))

    def storage_state(
        self,
        *,
        credentials: typing.Optional[bool] = None,
        indexed_db: typing.Optional[bool] = None,
        opfs: typing.Optional[bool] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
    ) -> StorageState:
        """BrowserContext.storage_state

        Returns storage state for this browser context, contains current cookies, local storage snapshot, IndexedDB
        snapshot, origin private file system snapshot and virtual WebAuthn credentials.

        Parameters
        ----------
        credentials : Union[bool, None]
            Set to `true` to include the context's virtual WebAuthn `browser_context.credentials` (passkeys) in the storage
            state snapshot. The captured credentials carry their private keys and signature counters, so they can be re-seeded
            into a later context via the `storage_state` option or `browser_context.set_storage_state()`. Note that restoring
            the storage state that contains credentials will automatically install the virtual WebAuthn authenticator (see
            `credentials.install()`), and prevent all real authenticators from working in this context.
        indexed_db : Union[bool, None]
            Set to `true` to include [IndexedDB](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API) in the storage
            state snapshot. If your application uses IndexedDB to store authentication tokens, like Firebase Authentication,
            enable this.
        opfs : Union[bool, None]
            Set to `true` to include the
            [origin private file system](https://developer.mozilla.org/en-US/docs/Web/API/File_System_API/Origin_private_file_system)
            in the storage state snapshot.

            **NOTE** OPFS is currently not supported in ephemeral WebKit contexts.

        path : Union[pathlib.Path, str, None]
            The file path to save the storage state to. If `path` is a relative path, then it is resolved relative to current
            working directory. If no path is provided, storage state is still returned, but won't be saved to the disk.

        Returns
        -------
        {cookies: List[{name: str, value: str, domain: str, path: str, expires: float, httpOnly: bool, secure: bool, sameSite: Union["Lax", "None", "Strict"]}], origins: List[{origin: str, localStorage: List[{name: str, value: str}]}]}
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.storage_state(
                    credentials=credentials, indexedDB=indexed_db, opfs=opfs, path=path
                )
            )
        )

    @property
    def tracing(self) -> "Tracing":
        """BrowserContext.tracing

        Returns
        -------
        Tracing
        """
        return mapping.from_impl(self._impl_obj.tracing)

    def unroute(
        self,
        url: typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]],
        handler: typing.Optional[
            typing.Union[
                typing.Callable[["Route"], typing.Any],
                typing.Callable[["Route", "Request"], typing.Any],
            ]
        ] = None,
    ) -> None:
        """BrowserContext.unroute

        Removes a route created with `browser_context.route()`. When `handler` is not specified, removes all routes for the
        `url`.

        Parameters
        ----------
        url : Union[Callable[[str], bool], Pattern[str], str]
            A glob pattern, regex pattern, or predicate receiving [URL] used to register a routing with
            `browser_context.route()`.
        handler : Union[Callable[[Route, Request], Any], Callable[[Route], Any], None]
            Optional handler function used to register a routing with `browser_context.route()`.
        """

        self._sync(
            self._impl_obj.unroute(
                url=self._wrap_handler(url), handler=self._wrap_handler(handler)
            )
        )

    def unroute_all(
        self,
        *,
        behavior: typing.Optional[Literal["default", "ignoreErrors", "wait"]] = None,
    ) -> None:
        """BrowserContext.unroute_all

        Removes all routes created with `browser_context.route()` and `browser_context.route_from_har()`.

        Parameters
        ----------
        behavior : Union["default", "ignoreErrors", "wait", None]
            Specifies whether to wait for already running handlers and what to do if they throw errors:
            - `'default'` - do not wait for current handler calls (if any) to finish, if unrouted handler throws, it may
              result in unhandled error
            - `'wait'` - wait for current handler calls (if any) to finish
            - `'ignoreErrors'` - do not wait for current handler calls (if any) to finish, all errors thrown by the handlers
              after unrouting are silently caught
        """

        self._sync(self._impl_obj.unroute_all(behavior=behavior))

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["backgroundpage"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["close"],
        predicate: typing.Optional[typing.Callable[["BrowserContext"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "BrowserContext": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["console"],
        predicate: typing.Optional[typing.Callable[["ConsoleMessage"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "ConsoleMessage": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["dialog"],
        predicate: typing.Optional[typing.Callable[["Dialog"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Dialog": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["dialogclosed"],
        predicate: typing.Optional[typing.Callable[["Dialog"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Dialog": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["download"],
        predicate: typing.Optional[typing.Callable[["Download"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Download": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["frameattached"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Frame": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["framedetached"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Frame": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["framenavigated"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Frame": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["page"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["pageclose"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["pageload"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["request"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Request": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["requestfailed"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Request": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["requestfinished"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Request": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["response"],
        predicate: typing.Optional[typing.Callable[["Response"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Response": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["serviceworker"],
        predicate: typing.Optional[typing.Callable[["Worker"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Worker": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["weberror"],
        predicate: typing.Optional[typing.Callable[["WebError"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "WebError": ...

    @typing.overload
    def wait_for_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable[..., bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> typing.Any: ...

    def wait_for_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Any:
        """BrowserContext.wait_for_event

        **NOTE** In most cases, you should use `browser_context.expect_event()`.

        Waits for given `event` to fire. If predicate is provided, it passes event's value into the `predicate` function
        and waits for `predicate(event)` to return a truthy value. Will throw an error if the browser context is closed
        before the `event` is fired.

        Parameters
        ----------
        event : str
            Event name, same one typically passed into `*.on(event)`.
        predicate : Union[Callable, None]
            Receives the event data and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.wait_for_event(
                    event=event,
                    predicate=self._wrap_handler(predicate),
                    timeout=to_milliseconds(timeout),
                )
            )
        )


mapping.register(BrowserContextImpl, BrowserContext)


class BrowserType(SyncBase):
    _impl_obj: BrowserTypeImpl

    def connect(
        self,
        endpoint: str,
        *,
        expose_network: typing.Optional[str] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        slow_mo: typing.Optional[float] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "Browser":
        """BrowserType.connect

        This method attaches Playwright to an existing browser instance created via `BrowserType.launchServer` in Node.js.

        **NOTE** The major and minor version of the Playwright instance that connects needs to match the version of
        Playwright that launches the browser (1.2.3 → is compatible with 1.2.x).

        Parameters
        ----------
        endpoint : str
            A Playwright browser websocket endpoint to connect to. You obtain this endpoint via `BrowserServer.wsEndpoint`.
        expose_network : Union[str, None]
            This option exposes network available on the connecting client to the browser being connected to. Consists of a
            list of rules separated by comma.

            Available rules:
            1. Hostname pattern, for example: `example.com`, `*.org:99`, `x.*.y.com`, `*foo.org`.
            1. IP literal, for example: `127.0.0.1`, `0.0.0.0:99`, `[::1]`, `[0:0::1]:99`.
            1. `<loopback>` that matches local loopback interfaces: `localhost`, `*.localhost`, `127.0.0.1`, `[::1]`.

            Some common examples:
            1. `"*"` to expose all network.
            1. `"<loopback>"` to expose localhost network.
            1. `"*.test.internal-domain,*.staging.internal-domain,<loopback>"` to expose test/staging deployments and
               localhost.
        headers : Union[Dict[str, str], None]
            Additional HTTP headers to be sent with web socket connect request. Optional.
        slow_mo : Union[float, None]
            Slows down Playwright operations by the specified amount of milliseconds. Useful so that you can see what is going
            on. Defaults to 0.
        timeout : Union[float, None]
            Maximum time in milliseconds to wait for the connection to be established. Defaults to `0` (no timeout).

        Returns
        -------
        Browser
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.connect(
                    endpoint=endpoint,
                    exposeNetwork=expose_network,
                    headers=mapping.to_impl(headers),
                    slowMo=slow_mo,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def connect_over_cdp(
        self,
        endpoint_url: str,
        *,
        artifacts_dir: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        is_local: typing.Optional[bool] = None,
        no_defaults: typing.Optional[bool] = None,
        slow_mo: typing.Optional[float] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "Browser":
        """BrowserType.connect_over_cdp

        This method attaches Playwright to an existing browser instance using the Chrome DevTools Protocol.

        The default browser context is accessible via `browser.contexts`.

        **NOTE** Connecting over the Chrome DevTools Protocol is only supported for Chromium-based browsers.

        **NOTE** This connection is significantly lower fidelity than the Playwright protocol connection via
        `browser_type.connect()`. If you are experiencing issues or attempting to use advanced functionality, you probably
        want to use `browser_type.connect()`.

        **NOTE** Playwright maintains a curated list of arguments for launching the browser. If you launch the browser
        without Playwright and do not pass the exact same arguments, some of Playwright functionality may be broken upon
        connecting to the browser.

        **Usage**

        ```py
        browser = playwright.chromium.connect_over_cdp(\"http://localhost:9222\")
        default_context = browser.contexts[0]
        page = default_context.pages[0]
        ```

        Parameters
        ----------
        endpoint_url : str
            A CDP websocket endpoint or http url to connect to. For example `http://localhost:9222/` or
            `ws://127.0.0.1:9222/devtools/browser/387adf4c-243f-4051-a181-46798f4a46f4`.
        artifacts_dir : Union[pathlib.Path, str, None]
            If specified, browser artifacts (such as traces and downloads) are saved into this directory.
        headers : Union[Dict[str, str], None]
            Additional HTTP headers to be sent with connect request. Optional.
        is_local : Union[bool, None]
            Tells Playwright that it runs on the same host as the CDP server. It will enable certain optimizations that rely
            upon the file system being the same between Playwright and the Browser.
        no_defaults : Union[bool, None]
            When true, Playwright will not apply its default overrides to the existing default browser context. Specifically,
            `accept_downloads` is left at the browser's setting, focus emulation is not enabled, and media emulation options
            (such as `color_scheme`, `reduced_motion`, `forced_colors`, and `contrast`) are not applied. Useful when attaching
            to a user's daily-driver browser where these overrides would interfere with existing browser state. New contexts
            created via `browser.new_context()` are not affected. Defaults to `false`.
        slow_mo : Union[float, None]
            Slows down Playwright operations by the specified amount of milliseconds. Useful so that you can see what is going
            on. Defaults to 0.
        timeout : Union[float, None]
            Maximum time in milliseconds to wait for the connection to be established. Defaults to `30000` (30 seconds). Pass
            `0` to disable timeout.

        Returns
        -------
        Browser
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.connect_over_cdp(
                    endpointURL=endpoint_url,
                    artifactsDir=artifacts_dir,
                    headers=mapping.to_impl(headers),
                    isLocal=is_local,
                    noDefaults=no_defaults,
                    slowMo=slow_mo,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    @property
    def executable_path(self) -> str:
        """BrowserType.executable_path

        A path where Playwright expects to find a bundled browser executable.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.executable_path)

    def launch(
        self,
        *,
        args: typing.Optional[typing.Sequence[str]] = None,
        artifacts_dir: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        channel: typing.Optional[str] = None,
        chromium_sandbox: typing.Optional[bool] = None,
        downloads_path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        env: typing.Optional[typing.Dict[str, typing.Union[str, float, bool]]] = None,
        executable_path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        firefox_user_prefs: typing.Optional[
            typing.Dict[str, typing.Union[str, float, bool]]
        ] = None,
        handle_sighup: typing.Optional[bool] = None,
        handle_sigint: typing.Optional[bool] = None,
        handle_sigterm: typing.Optional[bool] = None,
        headless: typing.Optional[bool] = None,
        ignore_default_args: typing.Optional[
            typing.Union[bool, typing.Sequence[str]]
        ] = None,
        proxy: typing.Optional[ProxySettings] = None,
        slow_mo: typing.Optional[float] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        traces_dir: typing.Optional[typing.Union[str, pathlib.Path]] = None,
    ) -> "Browser":
        """BrowserType.launch

        Returns the browser instance.

        **Usage**

        You can use `ignore_default_args` to filter out `--mute-audio` from default arguments:

        ```py
        browser = playwright.chromium.launch( # or \"firefox\" or \"webkit\".
            ignore_default_args=[\"--mute-audio\"]
        )
        ```

        > **Chromium-only** Playwright can also be used to control the Google Chrome or Microsoft Edge browsers, but it
        works best with the version of Chromium it is bundled with. There is no guarantee it will work with any other
        version. Use `executable_path` option with extreme caution.
        >
        > If Google Chrome (rather than Chromium) is preferred, a
        [Chrome Canary](https://www.google.com/chrome/browser/canary.html) or
        [Dev Channel](https://www.chromium.org/getting-involved/dev-channel) build is suggested.
        >
        > Stock browsers like Google Chrome and Microsoft Edge are suitable for tests that require proprietary media codecs
        for video playback. See
        [this article](https://www.howtogeek.com/202825/what%E2%80%99s-the-difference-between-chromium-and-chrome/) for
        other differences between Chromium and Chrome.
        [This article](https://chromium.googlesource.com/chromium/src/+/lkgr/docs/chromium_browser_vs_google_chrome.md)
        describes some differences for Linux users.

        Parameters
        ----------
        args : Union[Sequence[str], None]
            **NOTE** Use custom browser args at your own risk, as some of them may break Playwright functionality.

            Additional arguments to pass to the browser instance. The list of Chromium flags can be found
            [here](https://peter.sh/experiments/chromium-command-line-switches/).
        artifacts_dir : Union[pathlib.Path, str, None]
            If specified, artifacts (traces, videos, downloads, HAR files, etc.) are saved into this directory. The directory
            is not cleaned up when the browser closes. If not specified, a temporary directory is used and cleaned up when the
            browser closes.
        channel : Union[str, None]
            Browser distribution channel.

            Use "chromium" to [opt in to new headless mode](../browsers.md#chromium-new-headless-mode).

            Use "chrome", "chrome-beta", "chrome-dev", "chrome-canary", "msedge", "msedge-beta", "msedge-dev", or
            "msedge-canary" to use branded [Google Chrome and Microsoft Edge](../browsers.md#google-chrome--microsoft-edge).
        chromium_sandbox : Union[bool, None]
            Enable Chromium sandboxing. Defaults to `false`.
        downloads_path : Union[pathlib.Path, str, None]
            If specified, accepted downloads are downloaded into this directory. Otherwise, temporary directory is created and
            is deleted when browser is closed. In either case, the downloads are deleted when the browser context they were
            created in is closed.
        env : Union[Dict[str, Union[bool, float, str]], None]
            Specify environment variables that will be visible to the browser. Defaults to `process.env`.
        executable_path : Union[pathlib.Path, str, None]
            Path to a browser executable to run instead of the bundled one. If `executable_path` is a relative path, then it is
            resolved relative to the current working directory. Note that Playwright only works with the bundled Chromium,
            Firefox or WebKit, use at your own risk.
        firefox_user_prefs : Union[Dict[str, Union[bool, float, str]], None]
            Firefox user preferences. Learn more about the Firefox user preferences at
            [`about:config`](https://support.mozilla.org/en-US/kb/about-config-editor-firefox).

            You can also provide a path to a custom [`policies.json` file](https://mozilla.github.io/policy-templates/) via
            `PLAYWRIGHT_FIREFOX_POLICIES_JSON` environment variable.
        handle_sighup : Union[bool, None]
            Close the browser process on SIGHUP. Defaults to `true`.
        handle_sigint : Union[bool, None]
            Close the browser process on Ctrl-C. Defaults to `true`.
        handle_sigterm : Union[bool, None]
            Close the browser process on SIGTERM. Defaults to `true`.
        headless : Union[bool, None]
            Whether to run browser in headless mode. More details for
            [Chromium](https://developers.google.com/web/updates/2017/04/headless-chrome) and
            [Firefox](https://hacks.mozilla.org/2017/12/using-headless-mode-in-firefox/). Defaults to `true`.
        ignore_default_args : Union[Sequence[str], bool, None]
            If `true`, Playwright does not pass its own configurations args and only uses the ones from `args`. If an array is
            given, then filters out the given default arguments. Dangerous option; use with care. Defaults to `false`.
        proxy : Union[{server: str, bypass: Union[str, None], username: Union[str, None], password: Union[str, None]}, None]
            Network proxy settings.
        slow_mo : Union[float, None]
            Slows down Playwright operations by the specified amount of milliseconds. Useful so that you can see what is going
            on.
        timeout : Union[float, None]
            Maximum time in milliseconds to wait for the browser instance to start. Defaults to `180000` (3 minutes). Pass `0`
            to disable timeout.
        traces_dir : Union[pathlib.Path, str, None]
            If specified, traces are saved into this directory.

        Returns
        -------
        Browser
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.launch(
                    args=mapping.to_impl(args),
                    artifactsDir=artifacts_dir,
                    channel=channel,
                    chromiumSandbox=chromium_sandbox,
                    downloadsPath=downloads_path,
                    env=mapping.to_impl(env),
                    executablePath=executable_path,
                    firefoxUserPrefs=mapping.to_impl(firefox_user_prefs),
                    handleSIGHUP=handle_sighup,
                    handleSIGINT=handle_sigint,
                    handleSIGTERM=handle_sigterm,
                    headless=headless,
                    ignoreDefaultArgs=mapping.to_impl(ignore_default_args),
                    proxy=proxy,
                    slowMo=slow_mo,
                    timeout=to_milliseconds(timeout),
                    tracesDir=traces_dir,
                )
            )
        )

    def launch_persistent_context(
        self,
        user_data_dir: typing.Union[str, pathlib.Path],
        *,
        accept_downloads: typing.Optional[bool] = None,
        args: typing.Optional[typing.Sequence[str]] = None,
        artifacts_dir: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        base_url: typing.Optional[str] = None,
        bypass_csp: typing.Optional[bool] = None,
        channel: typing.Optional[str] = None,
        chromium_sandbox: typing.Optional[bool] = None,
        client_certificates: typing.Optional[typing.Sequence[ClientCertificate]] = None,
        color_scheme: typing.Optional[
            Literal["dark", "light", "no-preference", "null"]
        ] = None,
        contrast: typing.Optional[Literal["more", "no-preference", "null"]] = None,
        device_scale_factor: typing.Optional[float] = None,
        downloads_path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        env: typing.Optional[typing.Dict[str, typing.Union[str, float, bool]]] = None,
        executable_path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        extra_http_headers: typing.Optional[typing.Dict[str, str]] = None,
        firefox_user_prefs: typing.Optional[
            typing.Dict[str, typing.Union[str, float, bool]]
        ] = None,
        forced_colors: typing.Optional[Literal["active", "none", "null"]] = None,
        geolocation: typing.Optional[Geolocation] = None,
        handle_sighup: typing.Optional[bool] = None,
        handle_sigint: typing.Optional[bool] = None,
        handle_sigterm: typing.Optional[bool] = None,
        has_touch: typing.Optional[bool] = None,
        headless: typing.Optional[bool] = None,
        http_credentials: typing.Optional[
            typing.Union[HttpCredentials, typing.Sequence[HttpCredentials]]
        ] = None,
        ignore_default_args: typing.Optional[
            typing.Union[bool, typing.Sequence[str]]
        ] = None,
        ignore_https_errors: typing.Optional[bool] = None,
        is_mobile: typing.Optional[bool] = None,
        java_script_enabled: typing.Optional[bool] = None,
        locale: typing.Optional[str] = None,
        no_viewport: typing.Optional[bool] = None,
        offline: typing.Optional[bool] = None,
        permissions: typing.Optional[typing.Sequence[str]] = None,
        proxy: typing.Optional[ProxySettings] = None,
        record_har_content: typing.Optional[Literal["attach", "embed", "omit"]] = None,
        record_har_mode: typing.Optional[Literal["full", "minimal"]] = None,
        record_har_omit_content: typing.Optional[bool] = None,
        record_har_path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        record_har_url_filter: typing.Optional[
            typing.Union[str, typing.Pattern[str]]
        ] = None,
        record_video_dir: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        record_video_fps: typing.Optional[int] = None,
        record_video_size: typing.Optional[ViewportSize] = None,
        reduced_motion: typing.Optional[
            Literal["no-preference", "null", "reduce"]
        ] = None,
        screen: typing.Optional[ViewportSize] = None,
        service_workers: typing.Optional[Literal["allow", "block"]] = None,
        slow_mo: typing.Optional[float] = None,
        strict_selectors: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        timezone_id: typing.Optional[str] = None,
        traces_dir: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        user_agent: typing.Optional[str] = None,
        viewport: typing.Optional[ViewportSize] = None,
    ) -> "BrowserContext":
        """BrowserType.launch_persistent_context

        Returns the persistent browser context instance.

        Launches browser that uses persistent storage located at `user_data_dir` and returns the only context. Closing this
        context will automatically close the browser.

        Parameters
        ----------
        user_data_dir : Union[pathlib.Path, str]
            Path to a User Data Directory, which stores browser session data like cookies and local storage. Pass an empty
            string to create a temporary directory.

            More details for
            [Chromium](https://chromium.googlesource.com/chromium/src/+/master/docs/user_data_dir.md#introduction) and
            [Firefox](https://wiki.mozilla.org/Firefox/CommandLineOptions#User_profile). Chromium's user data directory is the
            **parent** directory of the "Profile Path" seen at `chrome://version`.

            Note that browsers do not allow launching multiple instances with the same User Data Directory.

            **NOTE** Chromium/Chrome: Due to recent Chrome policy changes, automating the default Chrome user profile is not
            supported. Pointing `userDataDir` to Chrome's main "User Data" directory (the profile used for your regular
            browsing) may result in pages not loading or the browser exiting. Create and use a separate directory (for example,
            an empty folder) as your automation profile instead. See https://developer.chrome.com/blog/remote-debugging-port
            for details.

        accept_downloads : Union[bool, None]
            Whether to automatically download all the attachments. Defaults to `true` where all the downloads are accepted.
        args : Union[Sequence[str], None]
            **NOTE** Use custom browser args at your own risk, as some of them may break Playwright functionality.

            Additional arguments to pass to the browser instance. The list of Chromium flags can be found
            [here](https://peter.sh/experiments/chromium-command-line-switches/).
        artifacts_dir : Union[pathlib.Path, str, None]
            If specified, artifacts (traces, videos, downloads, HAR files, etc.) are saved into this directory. The directory
            is not cleaned up when the browser closes. If not specified, a temporary directory is used and cleaned up when the
            browser closes.
        base_url : Union[str, None]
            When using `page.goto()`, `page.route()`, `page.wait_for_url()`, `page.expect_request()`, or
            `page.expect_response()` it takes the base URL in consideration by using the
            [`URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor for building the corresponding URL.
            Unset by default. Examples:
            - baseURL: `http://localhost:3000` and navigating to `/bar.html` results in `http://localhost:3000/bar.html`
            - baseURL: `http://localhost:3000/foo/` and navigating to `./bar.html` results in
              `http://localhost:3000/foo/bar.html`
            - baseURL: `http://localhost:3000/foo` (without trailing slash) and navigating to `./bar.html` results in
              `http://localhost:3000/bar.html`
        bypass_csp : Union[bool, None]
            Toggles bypassing page's Content-Security-Policy. Defaults to `false`.
        channel : Union[str, None]
            Browser distribution channel.

            Use "chromium" to [opt in to new headless mode](../browsers.md#chromium-new-headless-mode).

            Use "chrome", "chrome-beta", "chrome-dev", "chrome-canary", "msedge", "msedge-beta", "msedge-dev", or
            "msedge-canary" to use branded [Google Chrome and Microsoft Edge](../browsers.md#google-chrome--microsoft-edge).
        chromium_sandbox : Union[bool, None]
            Enable Chromium sandboxing. Defaults to `false`.
        client_certificates : Union[Sequence[{origin: str, certPath: Union[pathlib.Path, str, None], cert: Union[bytes, None], keyPath: Union[pathlib.Path, str, None], key: Union[bytes, None], pfxPath: Union[pathlib.Path, str, None], pfx: Union[bytes, None], passphrase: Union[str, None]}], None]
            TLS Client Authentication allows the server to request a client certificate and verify it.

            **Details**

            An array of client certificates to be used. Each certificate object must have either both `certPath` and `keyPath`,
            a single `pfxPath`, or their corresponding direct value equivalents (`cert` and `key`, or `pfx`). Optionally,
            `passphrase` property should be provided if the certificate is encrypted. The `origin` property should be provided
            with an exact match to the request origin that the certificate is valid for.

            Client certificate authentication is only active when at least one client certificate is provided. If you want to
            reject all client certificates sent by the server, you need to provide a client certificate with an `origin` that
            does not match any of the domains you plan to visit.

            **NOTE** When using WebKit on macOS, accessing `localhost` will not pick up client certificates. You can make it
            work by replacing `localhost` with `local.playwright`.

        color_scheme : Union["dark", "light", "no-preference", "null", None]
            Emulates [prefers-colors-scheme](https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-color-scheme)
            media feature, supported values are `'light'` and `'dark'`. See `page.emulate_media()` for more details. Passing
            `'null'` resets emulation to system defaults. Defaults to `'light'`.
        contrast : Union["more", "no-preference", "null", None]
            Emulates `'prefers-contrast'` media feature, supported values are `'no-preference'`, `'more'`. See
            `page.emulate_media()` for more details. Passing `'null'` resets emulation to system defaults. Defaults to
            `'no-preference'`.
        device_scale_factor : Union[float, None]
            Specify device scale factor (can be thought of as dpr). Defaults to `1`. Learn more about
            [emulating devices with device scale factor](../emulation.md#devices).
        downloads_path : Union[pathlib.Path, str, None]
            If specified, accepted downloads are downloaded into this directory. Otherwise, temporary directory is created and
            is deleted when browser is closed. In either case, the downloads are deleted when the browser context they were
            created in is closed.
        env : Union[Dict[str, Union[bool, float, str]], None]
            Specify environment variables that will be visible to the browser. Defaults to `process.env`.
        executable_path : Union[pathlib.Path, str, None]
            Path to a browser executable to run instead of the bundled one. If `executable_path` is a relative path, then it is
            resolved relative to the current working directory. Note that Playwright only works with the bundled Chromium,
            Firefox or WebKit, use at your own risk.
        extra_http_headers : Union[Dict[str, str], None]
            An object containing additional HTTP headers to be sent with every request. Defaults to none.
        firefox_user_prefs : Union[Dict[str, Union[bool, float, str]], None]
            Firefox user preferences. Learn more about the Firefox user preferences at
            [`about:config`](https://support.mozilla.org/en-US/kb/about-config-editor-firefox).

            You can also provide a path to a custom [`policies.json` file](https://mozilla.github.io/policy-templates/) via
            `PLAYWRIGHT_FIREFOX_POLICIES_JSON` environment variable.
        forced_colors : Union["active", "none", "null", None]
            Emulates `'forced-colors'` media feature, supported values are `'active'`, `'none'`. See `page.emulate_media()` for
            more details. Passing `'null'` resets emulation to system defaults. Defaults to `'none'`.
        geolocation : Union[{latitude: float, longitude: float, accuracy: Union[float, None]}, None]
        handle_sighup : Union[bool, None]
            Close the browser process on SIGHUP. Defaults to `true`.
        handle_sigint : Union[bool, None]
            Close the browser process on Ctrl-C. Defaults to `true`.
        handle_sigterm : Union[bool, None]
            Close the browser process on SIGTERM. Defaults to `true`.
        has_touch : Union[bool, None]
            Specifies if viewport supports touch events. Defaults to false. Learn more about
            [mobile emulation](../emulation.md#devices).
        headless : Union[bool, None]
            Whether to run browser in headless mode. More details for
            [Chromium](https://developers.google.com/web/updates/2017/04/headless-chrome) and
            [Firefox](https://hacks.mozilla.org/2017/12/using-headless-mode-in-firefox/). Defaults to `true`.
        http_credentials : Union[Sequence[{username: str, password: str, origin: Union[str, None], send: Union["always", "unauthorized", None]}], {username: str, password: str, origin: Union[str, None], send: Union["always", "unauthorized", None]}, None]
            Credentials for [HTTP authentication](https://developer.mozilla.org/en-US/docs/Web/HTTP/Authentication). If no
            origin is specified, the username and password are sent to any servers upon unauthorized responses.

            Pass an array to use different credentials for different origins. The first entry that matches the request origin
            is used, and entries with no origin match any request.
        ignore_default_args : Union[Sequence[str], bool, None]
            If `true`, Playwright does not pass its own configurations args and only uses the ones from `args`. If an array is
            given, then filters out the given default arguments. Dangerous option; use with care. Defaults to `false`.
        ignore_https_errors : Union[bool, None]
            Whether to ignore HTTPS errors when sending network requests. Defaults to `false`.
        is_mobile : Union[bool, None]
            Whether the `meta viewport` tag is taken into account and touch events are enabled. isMobile is a part of device,
            so you don't actually need to set it manually. Defaults to `false`. Learn more about
            [mobile emulation](../emulation.md#ismobile).
        java_script_enabled : Union[bool, None]
            Whether or not to enable JavaScript in the context. Defaults to `true`. Learn more about
            [disabling JavaScript](../emulation.md#javascript-enabled).
        locale : Union[str, None]
            Specify user locale, for example `en-GB`, `de-DE`, etc. Locale will affect `navigator.language` value,
            `Accept-Language` request header value as well as number and date formatting rules. Defaults to the system default
            locale. Learn more about emulation in our [emulation guide](../emulation.md#locale--timezone).
        no_viewport : Union[bool, None]
            Does not enforce fixed viewport, allows resizing window in the headed mode.
        offline : Union[bool, None]
            Whether to emulate network being offline. Defaults to `false`. Learn more about
            [network emulation](../emulation.md#offline).
        permissions : Union[Sequence[str], None]
            A list of permissions to grant to all pages in this context. See `browser_context.grant_permissions()` for more
            details. Defaults to none.
        proxy : Union[{server: str, bypass: Union[str, None], username: Union[str, None], password: Union[str, None]}, None]
            Network proxy settings.
        record_har_content : Union["attach", "embed", "omit", None]
            Optional setting to control resource content management. If `omit` is specified, content is not persisted. If
            `attach` is specified, resources are persisted as separate files and all of these files are archived along with the
            HAR file. Defaults to `embed`, which stores content inline the HAR file as per HAR specification.
        record_har_mode : Union["full", "minimal", None]
            When set to `minimal`, only record information necessary for routing from HAR. This omits sizes, timing, page,
            cookies, security and other types of HAR information that are not used when replaying from HAR. Defaults to `full`.
        record_har_omit_content : Union[bool, None]
            Optional setting to control whether to omit request content from the HAR. Defaults to `false`.
        record_har_path : Union[pathlib.Path, str, None]
            Enables [HAR](http://www.softwareishard.com/blog/har-12-spec) recording for all pages into the specified HAR file
            on the filesystem. If not specified, the HAR is not recorded. Make sure to call `browser_context.close()` for the
            HAR to be saved.
        record_har_url_filter : Union[Pattern[str], str, None]
        record_video_dir : Union[pathlib.Path, str, None]
            Enables video recording for all pages into the specified directory. If not specified videos are not recorded. Make
            sure to call `browser_context.close()` for videos to be saved.
        record_video_fps : Union[int, None]
            Frame rate of the recorded videos in frames per second. Defaults to `25`. Firefox and WebKit currently capture up
            to 25 frames per second.
        record_video_size : Union[{width: int, height: int}, None]
            Dimensions of the recorded videos. If not specified the size will be equal to `viewport` scaled down to fit into
            800x800. If `viewport` is not configured explicitly the video size defaults to 800x450. Actual picture of each page
            will be scaled down if necessary to fit the specified size.
        reduced_motion : Union["no-preference", "null", "reduce", None]
            Emulates `'prefers-reduced-motion'` media feature, supported values are `'reduce'`, `'no-preference'`. See
            `page.emulate_media()` for more details. Passing `'null'` resets emulation to system defaults. Defaults to
            `'no-preference'`.
        screen : Union[{width: int, height: int}, None]
            Emulates consistent window screen size available inside web page via `window.screen`. Is only used when the
            `viewport` is set.
        service_workers : Union["allow", "block", None]
            Whether to allow sites to register Service workers. Defaults to `'allow'`.
            - `'allow'`: [Service Workers](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API) can be
              registered.
            - `'block'`: Playwright will block all registration of Service Workers.
        slow_mo : Union[float, None]
            Slows down Playwright operations by the specified amount of milliseconds. Useful so that you can see what is going
            on.
        strict_selectors : Union[bool, None]
            If set to true, enables strict selectors mode for this context. In the strict selectors mode all operations on
            selectors that imply single target DOM element will throw when more than one element matches the selector. This
            option does not affect any Locator APIs (Locators are always strict). Defaults to `false`. See `Locator` to learn
            more about the strict mode.
        timeout : Union[float, None]
            Maximum time in milliseconds to wait for the browser instance to start. Defaults to `180000` (3 minutes). Pass `0`
            to disable timeout.
        timezone_id : Union[str, None]
            Changes the timezone of the context. See
            [ICU's metaZones.txt](https://cs.chromium.org/chromium/src/third_party/icu/source/data/misc/metaZones.txt?rcl=faee8bc70570192d82d2978a71e2a615788597d1)
            for a list of supported timezone IDs. Defaults to the system timezone.
        traces_dir : Union[pathlib.Path, str, None]
            If specified, traces are saved into this directory.
        user_agent : Union[str, None]
            Specific user agent to use in this context.
        viewport : Union[{width: int, height: int}, None]
            Sets a consistent viewport for each page. Defaults to an 1280x720 viewport. `no_viewport` disables the fixed
            viewport. Learn more about [viewport emulation](../emulation.md#viewport).

        Returns
        -------
        BrowserContext
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.launch_persistent_context(
                    userDataDir=user_data_dir,
                    acceptDownloads=accept_downloads,
                    args=mapping.to_impl(args),
                    artifactsDir=artifacts_dir,
                    baseURL=base_url,
                    bypassCSP=bypass_csp,
                    channel=channel,
                    chromiumSandbox=chromium_sandbox,
                    clientCertificates=mapping.to_impl(client_certificates),
                    colorScheme=color_scheme,
                    contrast=contrast,
                    deviceScaleFactor=device_scale_factor,
                    downloadsPath=downloads_path,
                    env=mapping.to_impl(env),
                    executablePath=executable_path,
                    extraHTTPHeaders=mapping.to_impl(extra_http_headers),
                    firefoxUserPrefs=mapping.to_impl(firefox_user_prefs),
                    forcedColors=forced_colors,
                    geolocation=geolocation,
                    handleSIGHUP=handle_sighup,
                    handleSIGINT=handle_sigint,
                    handleSIGTERM=handle_sigterm,
                    hasTouch=has_touch,
                    headless=headless,
                    httpCredentials=mapping.to_impl(http_credentials),
                    ignoreDefaultArgs=mapping.to_impl(ignore_default_args),
                    ignoreHTTPSErrors=ignore_https_errors,
                    isMobile=is_mobile,
                    javaScriptEnabled=java_script_enabled,
                    locale=locale,
                    noViewport=no_viewport,
                    offline=offline,
                    permissions=mapping.to_impl(permissions),
                    proxy=proxy,
                    recordHarContent=record_har_content,
                    recordHarMode=record_har_mode,
                    recordHarOmitContent=record_har_omit_content,
                    recordHarPath=record_har_path,
                    recordHarUrlFilter=record_har_url_filter,
                    recordVideoDir=record_video_dir,
                    recordVideoFps=record_video_fps,
                    recordVideoSize=record_video_size,
                    reducedMotion=reduced_motion,
                    screen=screen,
                    serviceWorkers=service_workers,
                    slowMo=slow_mo,
                    strictSelectors=strict_selectors,
                    timeout=to_milliseconds(timeout),
                    timezoneId=timezone_id,
                    tracesDir=traces_dir,
                    userAgent=user_agent,
                    viewport=viewport,
                )
            )
        )

    @property
    def name(self) -> str:
        """BrowserType.name

        Returns browser name. For example: `'chromium'`, `'webkit'` or `'firefox'`.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.name)


mapping.register(BrowserTypeImpl, BrowserType)


class CDPSession(SyncBase):
    _impl_obj: CDPSessionImpl

    def detach(self) -> None:
        """CDPSession.detach

        Detaches the CDPSession from the target. Once detached, the CDPSession object won't emit any events and can't be
        used to send messages.
        """

        self._sync(self._impl_obj.detach())

    @typing.overload
    def on(
        self, event: Literal["close"], f: typing.Callable[["CDPSession"], "None"]
    ) -> None:
        """
        Emitted when the session is closed, either because the target was closed or `session.detach()` was called.
        """

    @typing.overload
    def on(self, event: str, f: typing.Callable[..., None]) -> None: ...

    def on(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().on(event=event, f=f)

    @typing.overload
    def once(
        self, event: Literal["close"], f: typing.Callable[["CDPSession"], "None"]
    ) -> None:
        """
        Emitted when the session is closed, either because the target was closed or `session.detach()` was called.
        """

    @typing.overload
    def once(self, event: str, f: typing.Callable[..., None]) -> None: ...

    def once(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().once(event=event, f=f)

    def send(
        self, method: str, params: typing.Optional[typing.Dict] = None
    ) -> typing.Dict:
        """CDPSession.send

        Parameters
        ----------
        method : str
            Protocol method name.
        params : Union[Dict, None]
            Optional method parameters.

        Returns
        -------
        Dict
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.send(method=method, params=mapping.to_impl(params))
            )
        )


mapping.register(CDPSessionImpl, CDPSession)


class Clock(SyncBase):
    _impl_obj: ClockImpl

    def fast_forward(self, ticks: typing.Union[int, str]) -> None:
        """Clock.fast_forward

        Advance the clock by jumping forward in time. Only fires due timers at most once. This is equivalent to user
        closing the laptop lid for a while and reopening it later, after given time.

        **Usage**

        ```py
        page.clock.fast_forward(1000)
        page.clock.fast_forward(\"30:00\")
        ```

        Parameters
        ----------
        ticks : Union[int, str]
            Time may be the number of milliseconds to advance the clock by or a human-readable string. Valid string formats are
            "08" for eight seconds, "01:00" for one minute and "02:34:10" for two hours, 34 minutes and ten seconds.
        """

        self._sync(self._impl_obj.fast_forward(ticks=ticks))

    def install(
        self,
        *,
        time: typing.Optional[typing.Union[float, str, datetime.datetime]] = None,
    ) -> None:
        """Clock.install

        Install fake implementations for the following time-related functions:
        - `Date`
        - `Temporal.Now`
        - `setTimeout`
        - `clearTimeout`
        - `setInterval`
        - `clearInterval`
        - `requestAnimationFrame`
        - `cancelAnimationFrame`
        - `requestIdleCallback`
        - `cancelIdleCallback`
        - `performance`

        Fake timers are used to manually control the flow of time in tests. They allow you to advance time, fire timers,
        and control the behavior of time-dependent functions. See `clock.run_for()` and `clock.fast_forward()` for more
        information.

        Parameters
        ----------
        time : Union[datetime.datetime, float, str, None]
            Time to initialize with, current system time by default. Numeric values are Unix time in seconds.
        """

        self._sync(self._impl_obj.install(time=time))

    def pause_at(self, time: typing.Union[float, str, datetime.datetime]) -> None:
        """Clock.pause_at

        Advance the clock by jumping forward in time and pause the time. Once this method is called, no timers are fired
        unless `clock.run_for()`, `clock.fast_forward()`, `clock.pause_at()` or `clock.resume()` is called.

        Only fires due timers at most once. This is equivalent to user closing the laptop lid for a while and reopening it
        at the specified time and pausing.

        **Usage**

        ```py
        page.clock.pause_at(datetime.datetime(2020, 2, 2))
        page.clock.pause_at(\"2020-02-02\")
        ```

        For best results, install the clock before navigating the page and set it to a time slightly before the intended
        test time. This ensures that all timers run normally during page loading, preventing the page from getting stuck.
        Once the page has fully loaded, you can safely use `clock.pause_at()` to pause the clock.

        ```py
        # Initialize clock with some time before the test time and let the page load
        # naturally. `Date.now` will progress as the timers fire.
        page.clock.install(time=datetime.datetime(2024, 12, 10, 8, 0, 0))
        page.goto(\"http://localhost:3333\")
        page.clock.pause_at(datetime.datetime(2024, 12, 10, 10, 0, 0))
        ```

        Parameters
        ----------
        time : Union[datetime.datetime, float, str]
            Time to pause at. Numeric values are Unix time in seconds.
        """

        self._sync(self._impl_obj.pause_at(time=time))

    def resume(self) -> None:
        """Clock.resume

        Resumes timers. Once this method is called, time resumes flowing, timers are fired as usual.
        """

        self._sync(self._impl_obj.resume())

    def run_for(self, ticks: typing.Union[int, str]) -> None:
        """Clock.run_for

        Advance the clock, firing all the time-related callbacks.

        **Usage**

        ```py
        page.clock.run_for(1000);
        page.clock.run_for(\"30:00\")
        ```

        Parameters
        ----------
        ticks : Union[int, str]
            Time may be the number of milliseconds to advance the clock by or a human-readable string. Valid string formats are
            "08" for eight seconds, "01:00" for one minute and "02:34:10" for two hours, 34 minutes and ten seconds.
        """

        self._sync(self._impl_obj.run_for(ticks=ticks))

    def set_fixed_time(self, time: typing.Union[float, str, datetime.datetime]) -> None:
        """Clock.set_fixed_time

        Makes `Date.now` and `new Date()` return fixed fake time at all times, keeps all the timers running.

        Use this method for simple scenarios where you only need to test with a predefined time. For more advanced
        scenarios, use `clock.install()` instead. Read docs on [clock emulation](https://playwright.dev/python/docs/clock) to learn more.

        **Usage**

        ```py
        page.clock.set_fixed_time(datetime.datetime.now())
        page.clock.set_fixed_time(datetime.datetime(2020, 2, 2))
        page.clock.set_fixed_time(\"2020-02-02\")
        ```

        Parameters
        ----------
        time : Union[datetime.datetime, float, str]
            Time to be set. Numeric values are Unix time in seconds.
        """

        self._sync(self._impl_obj.set_fixed_time(time=time))

    def set_system_time(
        self, time: typing.Union[float, str, datetime.datetime]
    ) -> None:
        """Clock.set_system_time

        Sets system time, but does not trigger any timers. Use this to test how the web page reacts to a time shift, for
        example switching from summer to winter time, or changing time zones.

        **Usage**

        ```py
        page.clock.set_system_time(datetime.datetime.now())
        page.clock.set_system_time(datetime.datetime(2020, 2, 2))
        page.clock.set_system_time(\"2020-02-02\")
        ```

        Parameters
        ----------
        time : Union[datetime.datetime, float, str]
            Time to be set. Numeric values are Unix time in seconds.
        """

        self._sync(self._impl_obj.set_system_time(time=time))


mapping.register(ClockImpl, Clock)


class ConsoleMessage(SyncBase):
    _impl_obj: ConsoleMessageImpl

    @property
    def args(self) -> typing.List["JSHandle"]:
        """ConsoleMessage.args

        List of arguments passed to a `console` function call. See also `page.on('console')`.

        Returns
        -------
        List[JSHandle]
        """
        return mapping.from_impl_list(self._impl_obj.args)

    @property
    def location(self) -> SourceLocation:
        """ConsoleMessage.location

        Returns
        -------
        {url: str, line: int, column: int, lineNumber: int, columnNumber: int}
        """
        return mapping.from_impl(self._impl_obj.location)

    @property
    def page(self) -> typing.Optional["Page"]:
        """ConsoleMessage.page

        The page that produced this console message, if any.

        Returns
        -------
        Union[Page, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.page)

    @property
    def text(self) -> str:
        """ConsoleMessage.text

        The text of the console message.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.text)

    @property
    def timestamp(self) -> float:
        """ConsoleMessage.timestamp

        The timestamp of the console message in milliseconds since the Unix epoch.

        Returns
        -------
        float
        """
        return mapping.from_maybe_impl(self._impl_obj.timestamp)

    @property
    def type(
        self,
    ) -> Literal[
        "assert",
        "clear",
        "count",
        "debug",
        "dir",
        "dirxml",
        "endGroup",
        "error",
        "info",
        "log",
        "profile",
        "profileEnd",
        "startGroup",
        "startGroupCollapsed",
        "table",
        "time",
        "timeEnd",
        "trace",
        "warning",
    ]:
        """ConsoleMessage.type

        Returns
        -------
        Union["assert", "clear", "count", "debug", "dir", "dirxml", "endGroup", "error", "info", "log", "profile", "profileEnd", "startGroup", "startGroupCollapsed", "table", "time", "timeEnd", "trace", "warning"]
        """
        return mapping.from_maybe_impl(self._impl_obj.type)

    @property
    def worker(self) -> typing.Optional["Worker"]:
        """ConsoleMessage.worker

        The web worker or service worker that produced this console message, if any. Note that console messages from web
        workers also have non-null `console_message.page`.

        Returns
        -------
        Union[Worker, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.worker)


mapping.register(ConsoleMessageImpl, ConsoleMessage)


class Credentials(SyncBase):
    _impl_obj: CredentialsImpl

    def create(
        self,
        rp_id: str,
        *,
        id: typing.Optional[str] = None,
        private_key: typing.Optional[str] = None,
        public_key: typing.Optional[str] = None,
        sign_count: typing.Optional[int] = None,
        user_handle: typing.Optional[str] = None,
    ) -> VirtualCredential:
        """Credentials.create

        Seeds a virtual WebAuthn credential and returns it.

        With only `rp_id`, generates a fresh **ECDSA P-256** keypair, credential id and user handle. The seeded credential
        is discoverable (resident), so the page can resolve it from both username-then-passkey and usernameless passkey
        flows. The returned object carries the private and public keys, so it can be persisted to disk and re-seeded in a
        later test.

        To **import a known credential**, supply all four of `id`, `user_handle`, `private_key` and `public_key` together.
        Pass `sign_count` as well to continue from the signature counter the relying party has already seen.

        Call `credentials.install()` before navigating to a page that uses WebAuthn.

        Parameters
        ----------
        rp_id : str
            Relying party id (typically the site's effective domain).
        id : Union[str, None]
            Base64url-encoded credential id. Auto-generated if omitted.
        private_key : Union[str, None]
            Base64url-encoded PKCS#8 (DER) private key. Auto-generated if omitted.
        public_key : Union[str, None]
            Base64url-encoded SPKI (DER) public key. Auto-generated if omitted.
        sign_count : Union[int, None]
            Initial value of the [signature counter](https://www.w3.org/TR/webauthn-2/#signature-counter). The counter is
            incremented by one on every successful `navigator.credentials.get()` assertion, so the first assertion reports
            `signCount + 1`. Defaults to `0`.
        user_handle : Union[str, None]
            Base64url-encoded user handle. Auto-generated if omitted.

        Returns
        -------
        {id: str, rpId: str, userHandle: str, privateKey: str, publicKey: str, signCount: int}
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.create(
                    rpId=rp_id,
                    id=id,
                    privateKey=private_key,
                    publicKey=public_key,
                    signCount=sign_count,
                    userHandle=user_handle,
                )
            )
        )

    def delete(self, id: str) -> None:
        """Credentials.delete

        Removes a credential from the authenticator by its id. Works for any credential currently held — both those seeded
        with `credentials.create()` and those the page registered itself by calling `navigator.credentials.create()`.

        Parameters
        ----------
        id : str
            Base64url-encoded credential id.
        """

        self._sync(self._impl_obj.delete(id=id))

    def get(
        self, *, id: typing.Optional[str] = None, rp_id: typing.Optional[str] = None
    ) -> typing.List[VirtualCredential]:
        """Credentials.get

        Returns every credential currently held by the authenticator, optionally filtered by `rp_id` or `id`. This includes
        both credentials seeded with `credentials.create()` and credentials the page registered itself by calling
        `navigator.credentials.create()`.

        Each returned credential includes its private and public keys and the current signature counter, so a passkey the
        app just registered can be saved and re-seeded into a later test with `credentials.create()` — see the second
        example in the class overview.

        Parameters
        ----------
        id : Union[str, None]
            Only return the credential with this base64url-encoded id.
        rp_id : Union[str, None]
            Only return credentials for this relying party id.

        Returns
        -------
        List[{id: str, rpId: str, userHandle: str, privateKey: str, publicKey: str, signCount: int}]
        """

        return mapping.from_impl_list(self._sync(self._impl_obj.get(id=id, rpId=rp_id)))

    def install(self) -> None:
        """Credentials.install

        Installs the virtual WebAuthn authenticator into the context, overriding `navigator.credentials.create()` and
        `navigator.credentials.get()` in all current and future pages. Call this before the page first touches
        `navigator.credentials`.

        Required: until `credentials.install()` is called, no interception is in place and the page sees the platform's
        native (or absent) WebAuthn behaviour. Seeding credentials with `credentials.create()` without installing populates
        the authenticator, but the page will never see those credentials.
        """

        self._sync(self._impl_obj.install())


mapping.register(CredentialsImpl, Credentials)


class Debugger(SyncBase):
    _impl_obj: DebuggerImpl

    def next(self) -> None:
        """Debugger.next

        Resumes script execution and pauses again before the next action. Throws if the debugger is not paused.
        """

        self._sync(self._impl_obj.next())

    @typing.overload
    def on(
        self, event: Literal["pausedstatechanged"], f: typing.Callable[["None"], "None"]
    ) -> None:
        """
        Emitted when the debugger pauses or resumes."""

    @typing.overload
    def on(self, event: str, f: typing.Callable[..., None]) -> None: ...

    def on(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().on(event=event, f=f)

    @typing.overload
    def once(
        self, event: Literal["pausedstatechanged"], f: typing.Callable[["None"], "None"]
    ) -> None:
        """
        Emitted when the debugger pauses or resumes."""

    @typing.overload
    def once(self, event: str, f: typing.Callable[..., None]) -> None: ...

    def once(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().once(event=event, f=f)

    @property
    def paused_details(self) -> typing.Optional[DebuggerPausedDetails]:
        """Debugger.paused_details

        Returns details about the currently paused call. Returns `null` if the debugger is not paused.

        Returns
        -------
        Union[{location: {file: str, line: Union[int, None], column: Union[int, None]}, title: str}, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.paused_details)

    def request_pause(self) -> None:
        """Debugger.request_pause

        Configures the debugger to pause before the next action is executed.

        Throws if the debugger is already paused. Use `debugger.next()` or `debugger.run_to()` to step while paused.

        Note that `page.pause()` is equivalent to a \"debugger\" statement — it pauses execution at the call site
        immediately. On the contrary, `debugger.request_pause()` is equivalent to \"pause on next statement\" — it configures
        the debugger to pause before the next action is executed.
        """

        self._sync(self._impl_obj.request_pause())

    def resume(self) -> None:
        """Debugger.resume

        Resumes script execution. Throws if the debugger is not paused.
        """

        self._sync(self._impl_obj.resume())

    def run_to(self, location: DebuggerLocation) -> None:
        """Debugger.run_to

        Resumes script execution and pauses when an action originates from the given source location. Throws if the
        debugger is not paused.

        Parameters
        ----------
        location : {file: str, line: Union[int, None], column: Union[int, None]}
            The source location to pause at.
        """

        self._sync(self._impl_obj.run_to(location=location))


mapping.register(DebuggerImpl, Debugger)


class Dialog(SyncBase):
    _impl_obj: DialogImpl

    def accept(self, prompt_text: typing.Optional[str] = None) -> None:
        """Dialog.accept

        Returns when the dialog has been accepted.

        Parameters
        ----------
        prompt_text : Union[str, None]
            A text to enter in prompt. Does not cause any effects if the dialog's `type` is not prompt. Optional.
        """

        self._sync(self._impl_obj.accept(promptText=prompt_text))

    @property
    def default_value(self) -> str:
        """Dialog.default_value

        If dialog is prompt, returns default prompt value. Otherwise, returns empty string.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.default_value)

    def dismiss(self) -> None:
        """Dialog.dismiss

        Returns when the dialog has been dismissed.
        """

        self._sync(self._impl_obj.dismiss())

    @property
    def message(self) -> str:
        """Dialog.message

        A message displayed in the dialog.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.message)

    @property
    def page(self) -> typing.Optional["Page"]:
        """Dialog.page

        The page that initiated this dialog, if available.

        Returns
        -------
        Union[Page, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.page)

    @property
    def type(self) -> str:
        """Dialog.type

        Returns dialog's type, can be one of `alert`, `beforeunload`, `confirm` or `prompt`.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.type)


mapping.register(DialogImpl, Dialog)


class Disposable(SyncContextManager):
    _impl_obj: DisposableImpl

    def close(self) -> None:

        self._sync(self._impl_obj.close())

    def dispose(self) -> None:
        """Disposable.dispose

        Removes the associated resource. For example, removes the init script installed via `page.add_init_script()` or
        `browser_context.add_init_script()`.
        """

        self._sync(self._impl_obj.dispose())


mapping.register(DisposableImpl, Disposable)


class Download(SyncBase):
    _impl_obj: DownloadImpl

    def cancel(self) -> None:
        """Download.cancel

        Cancels a download. Will not fail if the download is already finished or canceled. Upon successful cancellations,
        `download.failure()` would resolve to `'canceled'`.
        """

        self._sync(self._impl_obj.cancel())

    def delete(self) -> None:
        """Download.delete

        Deletes the downloaded file. Will wait for the download to finish if necessary.
        """

        self._sync(self._impl_obj.delete())

    def failure(self) -> typing.Optional[str]:
        """Download.failure

        Returns download error if any. Will wait for the download to finish if necessary.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.failure()))

    @property
    def page(self) -> "Page":
        """Download.page

        Get the page that the download belongs to.

        Returns
        -------
        Page
        """
        return mapping.from_impl(self._impl_obj.page)

    def path(self) -> pathlib.Path:
        """Download.path

        Returns path to the downloaded file for a successful download, or throws for a failed/canceled download. The method
        will wait for the download to finish if necessary. The method throws when connected remotely.

        Note that the download's file name is a random GUID, use `download.suggested_filename` to get suggested file name.

        Returns
        -------
        pathlib.Path
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.path()))

    def save_as(self, path: typing.Union[str, pathlib.Path]) -> None:
        """Download.save_as

        Copy the download to a user-specified path. It is safe to call this method while the download is still in progress.
        Will wait for the download to finish if necessary.

        **Usage**

        ```py
        download.save_as(\"/path/to/save/at/\" + download.suggested_filename)
        ```

        Parameters
        ----------
        path : Union[pathlib.Path, str]
            Path where the download should be copied.
        """

        self._sync(self._impl_obj.save_as(path=path))

    @property
    def suggested_filename(self) -> str:
        """Download.suggested_filename

        Returns suggested filename for this download. It is typically computed by the browser from the
        [`Content-Disposition`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Disposition) response
        header or the `download` attribute. See the spec on [whatwg](https://html.spec.whatwg.org/#downloading-resources).
        Different browsers can use different logic for computing it.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.suggested_filename)

    @property
    def url(self) -> str:
        """Download.url

        Returns downloaded url.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)


mapping.register(DownloadImpl, Download)


class JSHandle(SyncBase):
    _impl_obj: JSHandleImpl

    def as_element(self) -> typing.Optional["ElementHandle"]:
        """JSHandle.as_element

        Returns either `null` or the object handle itself, if the object handle is an instance of `ElementHandle`.

        Returns
        -------
        Union[ElementHandle, None]
        """

        return mapping.from_impl_nullable(self._impl_obj.as_element())

    def dispose(self) -> None:
        """JSHandle.dispose

        The `jsHandle.dispose` method stops referencing the element handle.
        """

        self._sync(self._impl_obj.dispose())

    def evaluate(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """JSHandle.evaluate

        Returns the return value of `expression`.

        This method passes this handle as the first argument to `expression`.

        If `expression` returns a [Promise], then `handle.evaluate` would wait for the promise to resolve and return its
        value.

        **Usage**

        ```py
        tweet_handle = page.query_selector(\".tweet .retweets\")
        assert tweet_handle.evaluate(\"node => node.innerText\") == \"10 retweets\"
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.evaluate(expression=expression, arg=mapping.to_impl(arg))
            )
        )

    def evaluate_handle(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> "JSHandle":
        """JSHandle.evaluate_handle

        Returns the return value of `expression` as a `JSHandle`.

        This method passes this handle as the first argument to `expression`.

        The only difference between `jsHandle.evaluate` and `jsHandle.evaluateHandle` is that `jsHandle.evaluateHandle`
        returns `JSHandle`.

        If the function passed to the `jsHandle.evaluateHandle` returns a [Promise], then `jsHandle.evaluateHandle` would
        wait for the promise to resolve and return its value.

        See `page.evaluate_handle()` for more details.

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        JSHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.evaluate_handle(
                    expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    def get_properties(self) -> typing.Dict[str, "JSHandle"]:
        """JSHandle.get_properties

        The method returns a map with **own property names** as keys and JSHandle instances for the property values.

        **Usage**

        ```py
        handle = page.evaluate_handle(\"({ window, document })\")
        properties = handle.get_properties()
        window_handle = properties.get(\"window\")
        document_handle = properties.get(\"document\")
        handle.dispose()
        ```

        Returns
        -------
        Dict[str, JSHandle]
        """

        return mapping.from_impl_dict(self._sync(self._impl_obj.get_properties()))

    def get_property(self, property_name: str) -> "JSHandle":
        """JSHandle.get_property

        Fetches a single property from the referenced object.

        Parameters
        ----------
        property_name : str
            property to get

        Returns
        -------
        JSHandle
        """

        return mapping.from_impl(
            self._sync(self._impl_obj.get_property(propertyName=property_name))
        )

    def json_value(self) -> typing.Any:
        """JSHandle.json_value

        Returns a JSON representation of the object. If the object has a `toJSON` function, it **will not be called**.

        **NOTE** The method will return an empty JSON object if the referenced object is not stringifiable. It will throw
        an error if the object has circular references.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.json_value()))


mapping.register(JSHandleImpl, JSHandle)


class ElementHandle(JSHandle):
    _impl_obj: ElementHandleImpl

    def bounding_box(self) -> typing.Optional[FloatRect]:
        """ElementHandle.bounding_box

        This method returns the bounding box of the element, or `null` if the element is not visible. The bounding box is
        calculated relative to the main frame viewport - which is usually the same as the browser window.

        Scrolling affects the returned bounding box, similarly to
        [Element.getBoundingClientRect](https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect).
        That means `x` and/or `y` may be negative.

        Elements from child frames return the bounding box relative to the main frame, unlike the
        [Element.getBoundingClientRect](https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect).

        Assuming the page is static, it is safe to use bounding box coordinates to perform input. For example, the
        following snippet should click the center of the element.

        **Usage**

        ```py
        box = element_handle.bounding_box()
        page.mouse.click(box[\"x\"] + box[\"width\"] / 2, box[\"y\"] + box[\"height\"] / 2)
        ```

        Returns
        -------
        Union[{x: float, y: float, width: float, height: float}, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.bounding_box()))

    def check(
        self,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """ElementHandle.check

        This method checks the element by performing the following steps:
        1. Ensure that element is a checkbox or a radio input. If not, this method throws. If the element is already
           checked, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now checked. If not, this method throws.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.check(
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def click(
        self,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        click_count: typing.Optional[int] = None,
        delay: typing.Optional[float] = None,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        steps: typing.Optional[int] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """ElementHandle.click

        This method clicks the element by performing the following steps:
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element, or the specified `position`.
        1. Wait for initiated navigations to either succeed or fail, unless `no_wait_after` option is set.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        click_count : Union[int, None]
            defaults to 1. See [UIEvent.detail].
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            Actions that initiate navigations are waiting for these navigations to happen and for pages to start loading. You
            can opt out of waiting via setting this flag. You would only need this option in the exceptional cases such as
            navigating to inaccessible pages. Defaults to `false`.
            Deprecated: This option will default to `true` in the future.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        steps : Union[int, None]
            Defaults to 1. Sends `n` interpolated `mousemove` events to represent travel between Playwright's current cursor
            position and the provided destination. When set to 1, emits a single `mousemove` event at the destination location.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.click(
                button=button,
                clickCount=click_count,
                delay=delay,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                steps=steps,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def content_frame(self) -> typing.Optional["Frame"]:
        """ElementHandle.content_frame

        Returns the content frame for element handles referencing iframe nodes, or `null` otherwise

        Returns
        -------
        Union[Frame, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.content_frame()))

    def dblclick(
        self,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        delay: typing.Optional[float] = None,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        steps: typing.Optional[int] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """ElementHandle.dblclick

        This method double clicks the element by performing the following steps:
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to double click in the center of the element, or the specified `position`.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **NOTE** `elementHandle.dblclick()` dispatches two `click` events and a single `dblclick` event.

        Parameters
        ----------
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        steps : Union[int, None]
            Defaults to 1. Sends `n` interpolated `mousemove` events to represent travel between Playwright's current cursor
            position and the provided destination. When set to 1, emits a single `mousemove` event at the destination location.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.dblclick(
                button=button,
                delay=delay,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                steps=steps,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def dispatch_event(
        self, type: str, event_init: typing.Optional[typing.Dict] = None
    ) -> None:
        """ElementHandle.dispatch_event

        The snippet below dispatches the `click` event on the element. Regardless of the visibility state of the element,
        `click` is dispatched. This is equivalent to calling
        [element.click()](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/click).

        **Usage**

        ```py
        element_handle.dispatch_event(\"click\")
        ```

        Under the hood, it creates an instance of an event based on the given `type`, initializes it with `event_init`
        properties and dispatches it on the element. Events are `composed`, `cancelable` and bubble by default.

        Since `event_init` is event-specific, please refer to the events documentation for the lists of initial properties:
        - [DeviceMotionEvent](https://developer.mozilla.org/en-US/docs/Web/API/DeviceMotionEvent/DeviceMotionEvent)
        - [DeviceOrientationEvent](https://developer.mozilla.org/en-US/docs/Web/API/DeviceOrientationEvent/DeviceOrientationEvent)
        - [DragEvent](https://developer.mozilla.org/en-US/docs/Web/API/DragEvent/DragEvent)
        - [Event](https://developer.mozilla.org/en-US/docs/Web/API/Event/Event)
        - [FocusEvent](https://developer.mozilla.org/en-US/docs/Web/API/FocusEvent/FocusEvent)
        - [KeyboardEvent](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/KeyboardEvent)
        - [MouseEvent](https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/MouseEvent)
        - [PointerEvent](https://developer.mozilla.org/en-US/docs/Web/API/PointerEvent/PointerEvent)
        - [TouchEvent](https://developer.mozilla.org/en-US/docs/Web/API/TouchEvent/TouchEvent)
        - [WheelEvent](https://developer.mozilla.org/en-US/docs/Web/API/WheelEvent/WheelEvent)

        You can also specify `JSHandle` as the property value if you want live objects to be passed into the event:

        ```py
        # note you can only create data_transfer in chromium and firefox
        data_transfer = page.evaluate_handle(\"new DataTransfer()\")
        element_handle.dispatch_event(\"#source\", \"dragstart\", {\"dataTransfer\": data_transfer})
        ```

        Parameters
        ----------
        type : str
            DOM event type: `"click"`, `"dragstart"`, etc.
        event_init : Union[Dict, None]
            Optional event-specific initialization properties.
        """

        self._sync(
            self._impl_obj.dispatch_event(
                type=type, eventInit=mapping.to_impl(event_init)
            )
        )

    def eval_on_selector(
        self, selector: str, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """ElementHandle.eval_on_selector

        Returns the return value of `expression`.

        The method finds an element matching the specified selector in the `ElementHandle`s subtree and passes it as a
        first argument to `expression`. If no elements match the selector, the method throws an error.

        If `expression` returns a [Promise], then `element_handle.eval_on_selector()` would wait for the promise to resolve
        and return its value.

        **Usage**

        ```py
        tweet_handle = page.query_selector(\".tweet\")
        assert tweet_handle.eval_on_selector(\".like\", \"node => node.innerText\") == \"100\"
        assert tweet_handle.eval_on_selector(\".retweets\", \"node => node.innerText\") == \"10\"
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.eval_on_selector(
                    selector=selector, expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    def eval_on_selector_all(
        self, selector: str, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """ElementHandle.eval_on_selector_all

        Returns the return value of `expression`.

        The method finds all elements matching the specified selector in the `ElementHandle`'s subtree and passes an array
        of matched elements as a first argument to `expression`.

        If `expression` returns a [Promise], then `element_handle.eval_on_selector_all()` would wait for the promise to
        resolve and return its value.

        **Usage**

        ```html
        <div class=\"feed\">
          <div class=\"tweet\">Hello!</div>
          <div class=\"tweet\">Hi!</div>
        </div>
        ```

        ```py
        feed_handle = page.query_selector(\".feed\")
        assert feed_handle.eval_on_selector_all(\".tweet\", \"nodes => nodes.map(n => n.innerText)\") == [\"hello!\", \"hi!\"]
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.eval_on_selector_all(
                    selector=selector, expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    def fill(
        self,
        value: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """ElementHandle.fill

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, focuses the element, fills it and triggers an
        `input` event after filling. Note that you can pass an empty string to clear the input field.

        If the target element is not an `<input>`, `<textarea>` or `[contenteditable]` element, this method throws an
        error. However, if the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be filled
        instead.

        To send fine-grained keyboard events, use `locator.press_sequentially()`.

        Parameters
        ----------
        value : str
            Value to set for the `<input>`, `<textarea>` or `[contenteditable]` element.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.fill(
                value=value,
                force=force,
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def focus(self) -> None:
        """ElementHandle.focus

        Calls [focus](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/focus) on the element.
        """

        self._sync(self._impl_obj.focus())

    def get_attribute(self, name: str) -> typing.Optional[str]:
        """ElementHandle.get_attribute

        Returns element attribute value.

        Parameters
        ----------
        name : str
            Attribute name to get the value for.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.get_attribute(name=name))
        )

    def hover(
        self,
        *,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """ElementHandle.hover

        This method hovers over the element by performing the following steps:
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to hover over the center of the element, or the specified `position`.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.hover(
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def inner_html(self) -> str:
        """ElementHandle.inner_html

        Returns the `element.innerHTML`.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.inner_html()))

    def inner_text(self) -> str:
        """ElementHandle.inner_text

        Returns the `element.innerText`.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.inner_text()))

    def input_value(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """ElementHandle.input_value

        Returns `input.value` for the selected `<input>` or `<textarea>` or `<select>` element.

        Throws for non-input elements. However, if the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), returns the value of the
        control.

        Parameters
        ----------
        timeout : Union[float, None]
            Deprecated: This option is ignored. The value is returned immediately.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.input_value(timeout=to_milliseconds(timeout)))
        )

    def is_checked(self) -> bool:
        """ElementHandle.is_checked

        Returns whether the element is checked. Throws if the element is not a checkbox or radio input.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.is_checked()))

    def is_disabled(self) -> bool:
        """ElementHandle.is_disabled

        Returns whether the element is disabled, the opposite of [enabled](https://playwright.dev/python/docs/actionability#enabled).

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.is_disabled()))

    def is_editable(self) -> bool:
        """ElementHandle.is_editable

        Returns whether the element is [editable](https://playwright.dev/python/docs/actionability#editable).

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.is_editable()))

    def is_enabled(self) -> bool:
        """ElementHandle.is_enabled

        Returns whether the element is [enabled](https://playwright.dev/python/docs/actionability#enabled).

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.is_enabled()))

    def is_hidden(self) -> bool:
        """ElementHandle.is_hidden

        Returns whether the element is hidden, the opposite of [visible](https://playwright.dev/python/docs/actionability#visible).

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.is_hidden()))

    def is_visible(self) -> bool:
        """ElementHandle.is_visible

        Returns whether the element is [visible](https://playwright.dev/python/docs/actionability#visible).

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.is_visible()))

    def owner_frame(self) -> typing.Optional["Frame"]:
        """ElementHandle.owner_frame

        Returns the frame containing the given element.

        Returns
        -------
        Union[Frame, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.owner_frame()))

    def press(
        self,
        key: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """ElementHandle.press

        Focuses the element, and then uses `keyboard.down()` and `keyboard.up()`.

        `key` can specify the intended
        [keyboardEvent.key](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key) value or a single character
        to generate the text for. A superset of the `key` values can be found
        [here](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values). Examples of the keys are:

        `F1` - `F12`, `Digit0`- `Digit9`, `KeyA`- `KeyZ`, `Backquote`, `Minus`, `Equal`, `Backslash`, `Backspace`, `Tab`,
        `Delete`, `Escape`, `ArrowDown`, `End`, `Enter`, `Home`, `Insert`, `PageDown`, `PageUp`, `ArrowRight`, `ArrowUp`,
        etc.

        Following modification shortcuts are also supported: `Shift`, `Control`, `Alt`, `Meta`, `ShiftLeft`,
        `ControlOrMeta`.

        Holding down `Shift` will type the text that corresponds to the `key` in the upper case.

        If `key` is a single character, it is case-sensitive, so the values `a` and `A` will generate different respective
        texts.

        Shortcuts such as `key: \"Control+o\"`, `key: \"Control++` or `key: \"Control+Shift+T\"` are supported as well. When
        specified with the modifier, modifier is pressed and being held while the subsequent key is being pressed.

        Parameters
        ----------
        key : str
            Name of the key to press or a character to generate, such as `ArrowLeft` or `a`.
        delay : Union[float, None]
            Time to wait between `keydown` and `keyup` in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            Actions that initiate navigations are waiting for these navigations to happen and for pages to start loading. You
            can opt out of waiting via setting this flag. You would only need this option in the exceptional cases such as
            navigating to inaccessible pages. Defaults to `false`.
            Deprecated: This option will default to `true` in the future.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.press(
                key=key,
                delay=delay,
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def query_selector(self, selector: str) -> typing.Optional["ElementHandle"]:
        """ElementHandle.query_selector

        The method finds an element matching the specified selector in the `ElementHandle`'s subtree. If no elements match
        the selector, returns `null`.

        Parameters
        ----------
        selector : str
            A selector to query for.

        Returns
        -------
        Union[ElementHandle, None]
        """

        return mapping.from_impl_nullable(
            self._sync(self._impl_obj.query_selector(selector=selector))
        )

    def query_selector_all(self, selector: str) -> typing.List["ElementHandle"]:
        """ElementHandle.query_selector_all

        The method finds all elements matching the specified selector in the `ElementHandle`s subtree. If no elements match
        the selector, returns empty array.

        Parameters
        ----------
        selector : str
            A selector to query for.

        Returns
        -------
        List[ElementHandle]
        """

        return mapping.from_impl_list(
            self._sync(self._impl_obj.query_selector_all(selector=selector))
        )

    def screenshot(
        self,
        *,
        animations: typing.Optional[Literal["allow", "disabled"]] = None,
        caret: typing.Optional[Literal["hide", "initial"]] = None,
        mask: typing.Optional[typing.Sequence["Locator"]] = None,
        mask_color: typing.Optional[str] = None,
        omit_background: typing.Optional[bool] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        quality: typing.Optional[int] = None,
        scale: typing.Optional[Literal["css", "device"]] = None,
        style: typing.Optional[str] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        type: typing.Optional[Literal["jpeg", "png", "webp"]] = None,
    ) -> bytes:
        """ElementHandle.screenshot

        This method captures a screenshot of the page, clipped to the size and position of this particular element. If the
        element is covered by other elements, it will not be actually visible on the screenshot. If the element is a
        scrollable container, only the currently scrolled content will be visible on the screenshot.

        This method waits for the [actionability](https://playwright.dev/python/docs/actionability) checks, then scrolls element into view before taking
        a screenshot. If the element is detached from DOM, the method throws an error.

        Returns the buffer with the captured screenshot.

        Parameters
        ----------
        animations : Union["allow", "disabled", None]
            When set to `"disabled"`, stops CSS animations, CSS transitions and Web Animations. Animations get different
            treatment depending on their duration:
            - finite animations are fast-forwarded to completion, so they'll fire `transitionend` event.
            - infinite animations are canceled to initial state, and then played over after the screenshot.

            Defaults to `"allow"` that leaves animations untouched.
        caret : Union["hide", "initial", None]
            When set to `"hide"`, screenshot will hide text caret. When set to `"initial"`, text caret behavior will not be
            changed.  Defaults to `"hide"`.
        mask : Union[Sequence[Locator], None]
            Specify locators that should be masked when the screenshot is taken. Masked elements will be overlaid with a pink
            box `#FF00FF` (customized by `mask_color`) that completely covers its bounding box. The mask is also applied to
            invisible elements, see [Matching only visible elements](../locators.md#matching-only-visible-elements) to disable
            that.
        mask_color : Union[str, None]
            Specify the color of the overlay box for masked elements, in
            [CSS color format](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value). Default color is pink `#FF00FF`.
        omit_background : Union[bool, None]
            Hides default white background and allows capturing screenshots with transparency. Not applicable to `jpeg` images.
            Defaults to `false`.
        path : Union[pathlib.Path, str, None]
            The file path to save the image to. The screenshot type will be inferred from file extension. If `path` is a
            relative path, then it is resolved relative to the current working directory. If no path is provided, the image
            won't be saved to the disk.
        quality : Union[int, None]
            The quality of the image, between 0-100. Not applicable to `png` images. For `jpeg` the default is `80`. For
            `webp`, a quality of `100` (the default) produces a lossless image, while lower values use lossy compression.
        scale : Union["css", "device", None]
            When set to `"css"`, screenshot will have a single pixel per each css pixel on the page. For high-dpi devices, this
            will keep screenshots small. Using `"device"` option will produce a single pixel per each device pixel, so
            screenshots of high-dpi devices will be twice as large or even larger.

            Defaults to `"device"`.
        style : Union[str, None]
            Text of the stylesheet to apply while making the screenshot. This is where you can hide dynamic elements, make
            elements invisible or change their properties to help you creating repeatable screenshots. This stylesheet pierces
            the Shadow DOM and applies to the inner frames.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        type : Union["jpeg", "png", "webp", None]
            Specify screenshot type, defaults to `png`.

        Returns
        -------
        bytes
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.screenshot(
                    animations=animations,
                    caret=caret,
                    mask=mapping.to_impl(mask),
                    maskColor=mask_color,
                    omitBackground=omit_background,
                    path=path,
                    quality=quality,
                    scale=scale,
                    style=style,
                    timeout=to_milliseconds(timeout),
                    type=type,
                )
            )
        )

    def scroll_into_view_if_needed(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """ElementHandle.scroll_into_view_if_needed

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, then tries to scroll element into view, unless
        it is completely visible as defined by
        [IntersectionObserver](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API)'s `ratio`.

        Throws when `elementHandle` does not point to an element
        [connected](https://developer.mozilla.org/en-US/docs/Web/API/Node/isConnected) to a Document or a ShadowRoot.

        See [scrolling](https://playwright.dev/python/docs/input#scrolling) for alternative ways to scroll.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.scroll_into_view_if_needed(timeout=to_milliseconds(timeout))
        )

    def select_option(
        self,
        value: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None,
        *,
        element: typing.Optional[
            typing.Union["ElementHandle", typing.Sequence["ElementHandle"]]
        ] = None,
        force: typing.Optional[bool] = None,
        index: typing.Optional[typing.Union[int, typing.Sequence[int]]] = None,
        label: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.List[str]:
        """ElementHandle.select_option

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, waits until all specified options are present in
        the `<select>` element and selects these options.

        If the target element is not a `<select>` element, this method throws an error. However, if the element is inside
        the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be used
        instead.

        Returns the array of option values that have been successfully selected.

        Triggers a `change` and `input` event once all the provided options have been selected.

        **Usage**

        ```py
        # Single selection matching the value or label
        handle.select_option(\"blue\")
        # single selection matching both the label
        handle.select_option(label=\"blue\")
        # multiple selection
        handle.select_option(value=[\"red\", \"green\", \"blue\"])
        ```

        Parameters
        ----------
        value : Union[Sequence[str], str, None]
            Options to select by value. If the `<select>` has the `multiple` attribute, all given options are selected,
            otherwise only the first option matching one of the passed options is selected. Optional.
        element : Union[ElementHandle, Sequence[ElementHandle], None]
            Option elements to select. Optional.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        index : Union[Sequence[int], int, None]
            Options to select by index. Optional.
        label : Union[Sequence[str], str, None]
            Options to select by label. If the `<select>` has the `multiple` attribute, all given options are selected,
            otherwise only the first option matching one of the passed options is selected. Optional.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        List[str]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.select_option(
                    value=mapping.to_impl(value),
                    element=mapping.to_impl(element),
                    force=force,
                    index=mapping.to_impl(index),
                    label=mapping.to_impl(label),
                    noWaitAfter=no_wait_after,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def select_text(
        self,
        *,
        force: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """ElementHandle.select_text

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, then focuses the element and selects all its
        text content.

        If the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), focuses and selects text in
        the control instead.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.select_text(force=force, timeout=to_milliseconds(timeout))
        )

    def set_checked(
        self,
        checked: bool,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """ElementHandle.set_checked

        This method checks or unchecks an element by performing the following steps:
        1. Ensure that element is a checkbox or a radio input. If not, this method throws.
        1. If the element already has the right checked state, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now checked or unchecked. If not, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        checked : bool
            Whether to check or uncheck the checkbox.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.set_checked(
                checked=checked,
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def set_input_files(
        self,
        files: typing.Union[
            str,
            pathlib.Path,
            typing.Sequence[typing.Union[str, pathlib.Path]],
            FilePayload,
            typing.Sequence[FilePayload],
        ],
        *,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """ElementHandle.set_input_files

        Sets the value of the file input to these file paths or files. If some of the `filePaths` are relative paths, then
        they are resolved relative to the current working directory. For empty array, clears the selected files. For inputs
        with a `[webkitdirectory]` attribute, only a single directory path is supported.

        This method expects `ElementHandle` to point to an
        [input element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input). However, if the element is inside
        the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), targets the control instead.

        Parameters
        ----------
        files : Union[Sequence[Union[pathlib.Path, str]], Sequence[{name: str, mimeType: str, buffer: bytes}], pathlib.Path, str, {name: str, mimeType: str, buffer: bytes}]
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.set_input_files(
                files=mapping.to_impl(files),
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def tap(
        self,
        *,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """ElementHandle.tap

        This method taps the element by performing the following steps:
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.touchscreen` to tap the center of the element, or the specified `position`.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **NOTE** `elementHandle.tap()` requires that the `hasTouch` option of the browser context be set to true.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.tap(
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def text_content(self) -> typing.Optional[str]:
        """ElementHandle.text_content

        Returns the `node.textContent`.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.text_content()))

    def type(
        self,
        text: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """ElementHandle.type

        Focuses the element, and then sends a `keydown`, `keypress`/`input`, and `keyup` event for each character in the
        text.

        To press a special key, like `Control` or `ArrowDown`, use `element_handle.press()`.

        **Usage**

        Parameters
        ----------
        text : str
            A text to type into a focused element.
        delay : Union[float, None]
            Time to wait between key presses in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.type(
                text=text,
                delay=delay,
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def uncheck(
        self,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """ElementHandle.uncheck

        This method checks the element by performing the following steps:
        1. Ensure that element is a checkbox or a radio input. If not, this method throws. If the element is already
           unchecked, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now unchecked. If not, this method throws.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.uncheck(
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def wait_for_element_state(
        self,
        state: Literal[
            "disabled", "editable", "enabled", "hidden", "stable", "visible"
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """ElementHandle.wait_for_element_state

        Returns when the element satisfies the `state`.

        Depending on the `state` parameter, this method waits for one of the [actionability](https://playwright.dev/python/docs/actionability) checks to
        pass. This method throws when the element is detached while waiting, unless waiting for the `\"hidden\"` state.
        - `\"visible\"` Wait until the element is [visible](https://playwright.dev/python/docs/actionability#visible).
        - `\"hidden\"` Wait until the element is [not visible](https://playwright.dev/python/docs/actionability#visible) or not attached. Note that
          waiting for hidden does not throw when the element detaches.
        - `\"stable\"` Wait until the element is both [visible](https://playwright.dev/python/docs/actionability#visible) and
          [stable](https://playwright.dev/python/docs/actionability#stable).
        - `\"enabled\"` Wait until the element is [enabled](https://playwright.dev/python/docs/actionability#enabled).
        - `\"disabled\"` Wait until the element is [not enabled](https://playwright.dev/python/docs/actionability#enabled).
        - `\"editable\"` Wait until the element is [editable](https://playwright.dev/python/docs/actionability#editable).

        If the element does not satisfy the condition for the `timeout` milliseconds, this method will throw.

        Parameters
        ----------
        state : Union["disabled", "editable", "enabled", "hidden", "stable", "visible"]
            A state to wait for, see below for more details.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.wait_for_element_state(
                state=state, timeout=to_milliseconds(timeout)
            )
        )

    def wait_for_selector(
        self,
        selector: str,
        *,
        state: typing.Optional[
            Literal["attached", "detached", "hidden", "visible"]
        ] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional["ElementHandle"]:
        """ElementHandle.wait_for_selector

        Returns element specified by selector when it satisfies `state` option. Returns `null` if waiting for `hidden` or
        `detached`.

        Wait for the `selector` relative to the element handle to satisfy `state` option (either appear/disappear from dom,
        or become visible/hidden). If at the moment of calling the method `selector` already satisfies the condition, the
        method will return immediately. If the selector doesn't satisfy the condition for the `timeout` milliseconds, the
        function will throw.

        **Usage**

        ```py
        page.set_content(\"<div><span></span></div>\")
        div = page.query_selector(\"div\")
        # waiting for the \"span\" selector relative to the div.
        span = div.wait_for_selector(\"span\", state=\"attached\")
        ```

        **NOTE** This method does not work across navigations, use `page.wait_for_selector()` instead.

        Parameters
        ----------
        selector : str
            A selector to query for.
        state : Union["attached", "detached", "hidden", "visible", None]
            Defaults to `'visible'`. Can be either:
            - `'attached'` - wait for element to be present in DOM.
            - `'detached'` - wait for element to not be present in DOM.
            - `'visible'` - wait for element to have non-empty bounding box and no `visibility:hidden`. Note that element
              without any content or with `display:none` has an empty bounding box and is not considered visible.
            - `'hidden'` - wait for element to be either detached from DOM, or have an empty bounding box or
              `visibility:hidden`. This is opposite to the `'visible'` option.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[ElementHandle, None]
        """

        return mapping.from_impl_nullable(
            self._sync(
                self._impl_obj.wait_for_selector(
                    selector=selector,
                    state=state,
                    strict=strict,
                    timeout=to_milliseconds(timeout),
                )
            )
        )


mapping.register(ElementHandleImpl, ElementHandle)


class FileChooser(SyncBase):
    _impl_obj: FileChooserImpl

    @property
    def element(self) -> "ElementHandle":
        """FileChooser.element

        Returns input element associated with this file chooser.

        Returns
        -------
        ElementHandle
        """
        return mapping.from_impl(self._impl_obj.element)

    def is_multiple(self) -> bool:
        """FileChooser.is_multiple

        Returns whether this file chooser accepts multiple files.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._impl_obj.is_multiple())

    @property
    def page(self) -> "Page":
        """FileChooser.page

        Returns page this file chooser belongs to.

        Returns
        -------
        Page
        """
        return mapping.from_impl(self._impl_obj.page)

    def set_files(
        self,
        files: typing.Union[
            str,
            pathlib.Path,
            typing.Sequence[typing.Union[str, pathlib.Path]],
            FilePayload,
            typing.Sequence[FilePayload],
        ],
        *,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """FileChooser.set_files

        Sets the value of the file input this chooser is associated with. If some of the `filePaths` are relative paths,
        then they are resolved relative to the current working directory. For empty array, clears the selected files.

        Parameters
        ----------
        files : Union[Sequence[Union[pathlib.Path, str]], Sequence[{name: str, mimeType: str, buffer: bytes}], pathlib.Path, str, {name: str, mimeType: str, buffer: bytes}]
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.set_files(
                files=mapping.to_impl(files),
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )


mapping.register(FileChooserImpl, FileChooser)


class Frame(SyncBase):
    _impl_obj: FrameImpl

    def add_script_tag(
        self,
        *,
        content: typing.Optional[str] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        type: typing.Optional[str] = None,
        url: typing.Optional[str] = None,
    ) -> "ElementHandle":
        """Frame.add_script_tag

        Returns the added tag when the script's onload fires or when the script content was injected into frame.

        Adds a `<script>` tag into the page with the desired url or content.

        Parameters
        ----------
        content : Union[str, None]
            Raw JavaScript content to be injected into frame.
        path : Union[pathlib.Path, str, None]
            Path to the JavaScript file to be injected into frame. If `path` is a relative path, then it is resolved relative
            to the current working directory.
        type : Union[str, None]
            Script type. Use 'module' in order to load a JavaScript ES6 module. See
            [script](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script) for more details.
        url : Union[str, None]
            URL of a script to be added.

        Returns
        -------
        ElementHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.add_script_tag(
                    content=content, path=path, type=type, url=url
                )
            )
        )

    def add_style_tag(
        self,
        *,
        content: typing.Optional[str] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        url: typing.Optional[str] = None,
    ) -> "ElementHandle":
        """Frame.add_style_tag

        Returns the added tag when the stylesheet's onload fires or when the CSS content was injected into frame.

        Adds a `<link rel=\"stylesheet\">` tag into the page with the desired url or a `<style type=\"text/css\">` tag with the
        content.

        Parameters
        ----------
        content : Union[str, None]
            Raw CSS content to be injected into frame.
        path : Union[pathlib.Path, str, None]
            Path to the CSS file to be injected into frame. If `path` is a relative path, then it is resolved relative to the
            current working directory.
        url : Union[str, None]
            URL of the `<link>` tag.

        Returns
        -------
        ElementHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.add_style_tag(content=content, path=path, url=url)
            )
        )

    def check(
        self,
        selector: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Frame.check

        This method checks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Ensure that matched element is a checkbox or a radio input. If not, this method throws. If the element is
           already checked, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now checked. If not, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.check(
                selector=selector,
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    @property
    def child_frames(self) -> typing.List["Frame"]:
        """Frame.child_frames

        Returns
        -------
        List[Frame]
        """
        return mapping.from_impl_list(self._impl_obj.child_frames)

    def click(
        self,
        selector: str,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        click_count: typing.Optional[int] = None,
        delay: typing.Optional[float] = None,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Frame.click

        This method clicks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element, or the specified `position`.
        1. Wait for initiated navigations to either succeed or fail, unless `no_wait_after` option is set.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        click_count : Union[int, None]
            defaults to 1. See [UIEvent.detail].
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            Actions that initiate navigations are waiting for these navigations to happen and for pages to start loading. You
            can opt out of waiting via setting this flag. You would only need this option in the exceptional cases such as
            navigating to inaccessible pages. Defaults to `false`.
            Deprecated: This option will default to `true` in the future.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.click(
                selector=selector,
                button=button,
                clickCount=click_count,
                delay=delay,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def content(self, *, include_shadow: typing.Optional[bool] = None) -> str:
        """Frame.content

        Gets the full HTML contents of the frame, including the doctype.

        Parameters
        ----------
        include_shadow : Union[bool, None]
            When true, contents of open shadow roots are included as
            [declarative shadow DOM](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_shadow_DOM#declaratively_with_html),
            i.e. `<template shadowrootmode="open">` elements nested inside their host elements. Closed shadow roots are never
            included. Defaults to `false`.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.content(includeShadow=include_shadow))
        )

    def dblclick(
        self,
        selector: str,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        delay: typing.Optional[float] = None,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Frame.dblclick

        This method double clicks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to double click in the center of the element, or the specified `position`. if the first
           click of the `dblclick()` triggers a navigation event, this method will throw.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **NOTE** `frame.dblclick()` dispatches two `click` events and a single `dblclick` event.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.dblclick(
                selector=selector,
                button=button,
                delay=delay,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def dispatch_event(
        self,
        selector: str,
        type: str,
        event_init: typing.Optional[typing.Dict] = None,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Frame.dispatch_event

        The snippet below dispatches the `click` event on the element. Regardless of the visibility state of the element,
        `click` is dispatched. This is equivalent to calling
        [element.click()](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/click).

        **Usage**

        ```py
        frame.dispatch_event(\"button#submit\", \"click\")
        ```

        Under the hood, it creates an instance of an event based on the given `type`, initializes it with `event_init`
        properties and dispatches it on the element. Events are `composed`, `cancelable` and bubble by default.

        Since `event_init` is event-specific, please refer to the events documentation for the lists of initial properties:
        - [DeviceMotionEvent](https://developer.mozilla.org/en-US/docs/Web/API/DeviceMotionEvent/DeviceMotionEvent)
        - [DeviceOrientationEvent](https://developer.mozilla.org/en-US/docs/Web/API/DeviceOrientationEvent/DeviceOrientationEvent)
        - [DragEvent](https://developer.mozilla.org/en-US/docs/Web/API/DragEvent/DragEvent)
        - [Event](https://developer.mozilla.org/en-US/docs/Web/API/Event/Event)
        - [FocusEvent](https://developer.mozilla.org/en-US/docs/Web/API/FocusEvent/FocusEvent)
        - [KeyboardEvent](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/KeyboardEvent)
        - [MouseEvent](https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/MouseEvent)
        - [PointerEvent](https://developer.mozilla.org/en-US/docs/Web/API/PointerEvent/PointerEvent)
        - [TouchEvent](https://developer.mozilla.org/en-US/docs/Web/API/TouchEvent/TouchEvent)
        - [WheelEvent](https://developer.mozilla.org/en-US/docs/Web/API/WheelEvent/WheelEvent)

        You can also specify `JSHandle` as the property value if you want live objects to be passed into the event:

        ```py
        # note you can only create data_transfer in chromium and firefox
        data_transfer = frame.evaluate_handle(\"new DataTransfer()\")
        frame.dispatch_event(\"#source\", \"dragstart\", { \"dataTransfer\": data_transfer })
        ```

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        type : str
            DOM event type: `"click"`, `"dragstart"`, etc.
        event_init : Union[Dict, None]
            Optional event-specific initialization properties.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.dispatch_event(
                selector=selector,
                type=type,
                eventInit=mapping.to_impl(event_init),
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def drag_and_drop(
        self,
        source: str,
        target: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        source_position: typing.Optional[Position] = None,
        steps: typing.Optional[int] = None,
        strict: typing.Optional[bool] = None,
        target_position: typing.Optional[Position] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Frame.drag_and_drop

        Parameters
        ----------
        source : str
            A selector to search for an element to drag. If there are multiple elements satisfying the selector, the first will
            be used.
        target : str
            A selector to search for an element to drop onto. If there are multiple elements satisfying the selector, the first
            will be used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        source_position : Union[{x: float, y: float}, None]
            Clicks on the source element at this point relative to the top-left corner of the element's padding box. If not
            specified, some visible point of the element is used.
        steps : Union[int, None]
            Defaults to 1. Sends `n` interpolated `mousemove` events to represent travel between the `mousedown` and `mouseup`
            of the drag. When set to 1, emits a single `mousemove` event at the destination location.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        target_position : Union[{x: float, y: float}, None]
            Drops on the target element at this point relative to the top-left corner of the element's padding box. If not
            specified, some visible point of the element is used.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.drag_and_drop(
                source=source,
                target=target,
                force=force,
                noWaitAfter=no_wait_after,
                scroll=scroll,
                sourcePosition=source_position,
                steps=steps,
                strict=strict,
                targetPosition=target_position,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def eval_on_selector(
        self,
        selector: str,
        expression: str,
        arg: typing.Optional[typing.Any] = None,
        *,
        strict: typing.Optional[bool] = None,
    ) -> typing.Any:
        """Frame.eval_on_selector

        Returns the return value of `expression`.

        The method finds an element matching the specified selector within the frame and passes it as a first argument to
        `expression`. If no elements match the selector, the method throws an error.

        If `expression` returns a [Promise], then `frame.eval_on_selector()` would wait for the promise to resolve and
        return its value.

        **Usage**

        ```py
        search_value = frame.eval_on_selector(\"#search\", \"el => el.value\")
        preload_href = frame.eval_on_selector(\"link[rel=preload]\", \"el => el.href\")
        html = frame.eval_on_selector(\".main-container\", \"(e, suffix) => e.outerHTML + suffix\", \"hello\")
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.eval_on_selector(
                    selector=selector,
                    expression=expression,
                    arg=mapping.to_impl(arg),
                    strict=strict,
                )
            )
        )

    def eval_on_selector_all(
        self, selector: str, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """Frame.eval_on_selector_all

        Returns the return value of `expression`.

        The method finds all elements matching the specified selector within the frame and passes an array of matched
        elements as a first argument to `expression`.

        If `expression` returns a [Promise], then `frame.eval_on_selector_all()` would wait for the promise to resolve and
        return its value.

        **Usage**

        ```py
        divs_counts = frame.eval_on_selector_all(\"div\", \"(divs, min) => divs.length >= min\", 10)
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.eval_on_selector_all(
                    selector=selector, expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    def evaluate(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """Frame.evaluate

        Returns the return value of `expression`.

        If the function passed to the `frame.evaluate()` returns a [Promise], then `frame.evaluate()` would wait for the
        promise to resolve and return its value.

        If the function passed to the `frame.evaluate()` returns a non-[Serializable] value, then `frame.evaluate()`
        returns `undefined`. Playwright also supports transferring some additional values that are not serializable by
        `JSON`: `-0`, `NaN`, `Infinity`, `-Infinity`.

        **Usage**

        ```py
        result = frame.evaluate(\"([x, y]) => Promise.resolve(x * y)\", [7, 8])
        print(result) # prints \"56\"
        ```

        A string can also be passed in instead of a function.

        ```py
        print(frame.evaluate(\"1 + 2\")) # prints \"3\"
        x = 10
        print(frame.evaluate(f\"1 + {x}\")) # prints \"11\"
        ```

        `ElementHandle` instances can be passed as an argument to the `frame.evaluate()`:

        ```py
        body_handle = frame.evaluate_handle(\"document.body\")
        html = frame.evaluate(\"([body, suffix]) => body.innerHTML + suffix\", [body_handle, \"hello\"])
        body_handle.dispose()
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.evaluate(expression=expression, arg=mapping.to_impl(arg))
            )
        )

    def evaluate_handle(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> "JSHandle":
        """Frame.evaluate_handle

        Returns the return value of `expression` as a `JSHandle`.

        The only difference between `frame.evaluate()` and `frame.evaluate_handle()` is that `frame.evaluate_handle()`
        returns `JSHandle`.

        If the function, passed to the `frame.evaluate_handle()`, returns a [Promise], then `frame.evaluate_handle()` would
        wait for the promise to resolve and return its value.

        **Usage**

        ```py
        a_window_handle = frame.evaluate_handle(\"Promise.resolve(window)\")
        a_window_handle # handle for the window object.
        ```

        A string can also be passed in instead of a function.

        ```py
        a_handle = frame.evaluate_handle(\"document\") # handle for the \"document\"
        ```

        `JSHandle` instances can be passed as an argument to the `frame.evaluate_handle()`:

        ```py
        a_handle = frame.evaluate_handle(\"document.body\")
        result_handle = frame.evaluate_handle(\"body => body.innerHTML\", a_handle)
        print(result_handle.json_value())
        result_handle.dispose()
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        JSHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.evaluate_handle(
                    expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    def expect_navigation(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        url: typing.Optional[
            typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]]
        ] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> EventContextManager["Response"]:
        """Frame.expect_navigation

        Waits for the frame navigation and returns the main resource response. In case of multiple redirects, the
        navigation will resolve with the response of the last redirect. In case of navigation to a different anchor or
        navigation due to History API usage, the navigation will resolve with `null`.

        **Usage**

        This method waits for the frame to navigate to a new URL. It is useful for when you run code which will indirectly
        cause the frame to navigate. Consider this example:

        ```py
        with frame.expect_navigation():
            frame.click(\"a.delayed-navigation\") # clicking the link will indirectly cause a navigation
        # Resolves after navigation has finished
        ```

        **NOTE** Usage of the [History API](https://developer.mozilla.org/en-US/docs/Web/API/History_API) to change the URL
        is considered a navigation.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        url : Union[Callable[[str], bool], Pattern[str], str, None]
            A glob pattern, regex pattern, or predicate receiving [URL] to match while waiting for the navigation. Note that if
            the parameter is a string without wildcard characters, the method will wait for navigation to URL that is exactly
            equal to the string.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.

        Returns
        -------
        EventContextManager[Response]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_navigation(
                timeout=to_milliseconds(timeout),
                url=self._wrap_handler(url),
                waitUntil=wait_until,
            ).future,
        )

    def fill(
        self,
        selector: str,
        value: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Frame.fill

        This method waits for an element matching `selector`, waits for [actionability](https://playwright.dev/python/docs/actionability) checks,
        focuses the element, fills it and triggers an `input` event after filling. Note that you can pass an empty string
        to clear the input field.

        If the target element is not an `<input>`, `<textarea>` or `[contenteditable]` element, this method throws an
        error. However, if the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be filled
        instead.

        To send fine-grained keyboard events, use `locator.press_sequentially()`.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        value : str
            Value to fill for the `<input>`, `<textarea>` or `[contenteditable]` element.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.fill(
                selector=selector,
                value=value,
                force=force,
                noWaitAfter=no_wait_after,
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def focus(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Frame.focus

        This method fetches an element with `selector` and focuses it. If there's no element matching `selector`, the
        method waits until a matching element appears in the DOM.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.focus(
                selector=selector, strict=strict, timeout=to_milliseconds(timeout)
            )
        )

    def frame_element(self) -> "ElementHandle":
        """Frame.frame_element

        Returns the `frame` or `iframe` element handle which corresponds to this frame.

        This is an inverse of `element_handle.content_frame()`. Note that returned handle actually belongs to the parent
        frame.

        This method throws an error if the frame has been detached before `frameElement()` returns.

        **Usage**

        ```py
        frame_element = frame.frame_element()
        content_frame = frame_element.content_frame()
        assert frame == content_frame
        ```

        Returns
        -------
        ElementHandle
        """

        return mapping.from_impl(self._sync(self._impl_obj.frame_element()))

    def frame_locator(self, selector: typing.Optional[str] = None) -> "FrameLocator":
        """Frame.frame_locator

        When working with iframes, you can create a frame locator that will enter the iframe and allow selecting elements
        in that iframe.

        When called without `selector`, the search starts in this frame or in any of the iframes inside it, so that you
        don't need to locate each iframe first. Note that the rest of the locator is resolved inside a single frame, just
        like any other locator. If it matches elements inside multiple frames, an error is thrown.

        **Usage**

        Following snippet locates element with text \"Submit\" in the iframe with id `my-frame`, like `<iframe
        id=\"my-frame\">`:

        ```py
        locator = frame.frame_locator(\"#my-iframe\").get_by_text(\"Submit\")
        locator.click()
        ```

        Following snippet locates a button, either in the frame or in one of the iframes inside it:

        ```py
        locator = frame.frame_locator().get_by_role(\"button\")
        locator.click()
        ```

        Parameters
        ----------
        selector : Union[str, None]
            A selector that matches the frame element. When not specified, locator is matched in this frame or in any of the
            iframes inside it.

        Returns
        -------
        FrameLocator
        """

        return mapping.from_impl(self._impl_obj.frame_locator(selector=selector))

    def get_attribute(
        self,
        selector: str,
        name: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional[str]:
        """Frame.get_attribute

        Returns element attribute value.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        name : str
            Attribute name to get the value for.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.get_attribute(
                    selector=selector,
                    name=name,
                    strict=strict,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def get_by_alt_text(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Frame.get_by_alt_text

        Allows locating elements by their alt text.

        **Usage**

        For example, this method will find the image by alt text \"Playwright logo\":

        ```html
        <img alt='Playwright logo'>
        ```

        ```py
        page.get_by_alt_text(\"Playwright logo\").click()
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_alt_text(text=text, exact=exact))

    def get_by_label(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Frame.get_by_label

        Allows locating input elements by the text of the associated `<label>` or `aria-labelledby` element, or by the
        `aria-label` attribute.

        **Usage**

        For example, this method will find inputs by label \"Username\" and \"Password\" in the following DOM:

        ```html
        <input aria-label=\"Username\">
        <label for=\"password-input\">Password:</label>
        <input id=\"password-input\">
        ```

        ```py
        page.get_by_label(\"Username\").fill(\"john\")
        page.get_by_label(\"Password\").fill(\"secret\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_label(text=text, exact=exact))

    def get_by_placeholder(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Frame.get_by_placeholder

        Allows locating input elements by the placeholder text.

        **Usage**

        For example, consider the following DOM structure.

        ```html
        <input type=\"email\" placeholder=\"name@example.com\" />
        ```

        You can fill the input after locating it by the placeholder text:

        ```py
        page.get_by_placeholder(\"name@example.com\").fill(\"playwright@microsoft.com\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.get_by_placeholder(text=text, exact=exact)
        )

    def get_by_role(
        self,
        role: Literal[
            "alert",
            "alertdialog",
            "application",
            "article",
            "banner",
            "blockquote",
            "button",
            "caption",
            "cell",
            "checkbox",
            "code",
            "columnheader",
            "combobox",
            "complementary",
            "contentinfo",
            "definition",
            "deletion",
            "dialog",
            "directory",
            "document",
            "emphasis",
            "feed",
            "figure",
            "form",
            "generic",
            "grid",
            "gridcell",
            "group",
            "heading",
            "img",
            "insertion",
            "link",
            "list",
            "listbox",
            "listitem",
            "log",
            "main",
            "marquee",
            "math",
            "menu",
            "menubar",
            "menuitem",
            "menuitemcheckbox",
            "menuitemradio",
            "meter",
            "navigation",
            "none",
            "note",
            "option",
            "paragraph",
            "presentation",
            "progressbar",
            "radio",
            "radiogroup",
            "region",
            "row",
            "rowgroup",
            "rowheader",
            "scrollbar",
            "search",
            "searchbox",
            "separator",
            "slider",
            "spinbutton",
            "status",
            "strong",
            "subscript",
            "superscript",
            "switch",
            "tab",
            "table",
            "tablist",
            "tabpanel",
            "term",
            "textbox",
            "time",
            "timer",
            "toolbar",
            "tooltip",
            "tree",
            "treegrid",
            "treeitem",
        ],
        *,
        checked: typing.Optional[bool] = None,
        description: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        disabled: typing.Optional[bool] = None,
        exact: typing.Optional[bool] = None,
        expanded: typing.Optional[bool] = None,
        include_hidden: typing.Optional[bool] = None,
        level: typing.Optional[int] = None,
        name: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        pressed: typing.Optional[bool] = None,
        selected: typing.Optional[bool] = None,
    ) -> "Locator":
        """Frame.get_by_role

        Allows locating elements by their [ARIA role](https://www.w3.org/TR/wai-aria-1.2/#roles),
        [ARIA attributes](https://www.w3.org/TR/wai-aria-1.2/#aria-attributes) and
        [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).

        **Usage**

        Consider the following DOM structure.

        ```html
        <h3>Sign up</h3>
        <label>
          <input type=\"checkbox\" /> Subscribe
        </label>
        <br/>
        <button>Submit</button>
        ```

        You can locate each element by its implicit role:

        ```py
        expect(page.get_by_role(\"heading\", name=\"Sign up\")).to_be_visible()

        page.get_by_role(\"checkbox\", name=\"Subscribe\").check()

        page.get_by_role(\"button\", name=re.compile(\"submit\", re.IGNORECASE)).click()
        ```

        **Details**

        Role selector **does not replace** accessibility audits and conformance tests, but rather gives early feedback
        about the ARIA guidelines.

        Many html elements have an implicitly [defined role](https://w3c.github.io/html-aam/#html-element-role-mappings)
        that is recognized by the role selector. You can find all the
        [supported roles here](https://www.w3.org/TR/wai-aria-1.2/#role_definitions). ARIA guidelines **do not recommend**
        duplicating implicit roles and attributes by setting `role` and/or `aria-*` attributes to default values.

        Parameters
        ----------
        role : Union["alert", "alertdialog", "application", "article", "banner", "blockquote", "button", "caption", "cell", "checkbox", "code", "columnheader", "combobox", "complementary", "contentinfo", "definition", "deletion", "dialog", "directory", "document", "emphasis", "feed", "figure", "form", "generic", "grid", "gridcell", "group", "heading", "img", "insertion", "link", "list", "listbox", "listitem", "log", "main", "marquee", "math", "menu", "menubar", "menuitem", "menuitemcheckbox", "menuitemradio", "meter", "navigation", "none", "note", "option", "paragraph", "presentation", "progressbar", "radio", "radiogroup", "region", "row", "rowgroup", "rowheader", "scrollbar", "search", "searchbox", "separator", "slider", "spinbutton", "status", "strong", "subscript", "superscript", "switch", "tab", "table", "tablist", "tabpanel", "term", "textbox", "time", "timer", "toolbar", "tooltip", "tree", "treegrid", "treeitem"]
            Required aria role.
        checked : Union[bool, None]
            An attribute that is usually set by `aria-checked` or native `<input type=checkbox>` controls.

            Learn more about [`aria-checked`](https://www.w3.org/TR/wai-aria-1.2/#aria-checked).
        description : Union[Pattern[str], str, None]
            Option to match the [accessible description](https://w3c.github.io/accname/#dfn-accessible-description). By
            default, matching is case-insensitive and searches for a substring, use `exact` to control this behavior.

            Learn more about [accessible description](https://w3c.github.io/accname/#dfn-accessible-description).
        disabled : Union[bool, None]
            An attribute that is usually set by `aria-disabled` or `disabled`.

            **NOTE** Unlike most other attributes, `disabled` is inherited through the DOM hierarchy. Learn more about
            [`aria-disabled`](https://www.w3.org/TR/wai-aria-1.2/#aria-disabled).

        exact : Union[bool, None]
            Whether `name` and `description` are matched exactly: case-sensitive and whole-string. Defaults to false. Ignored
            when the value is a regular expression. Note that exact match still trims whitespace.
        expanded : Union[bool, None]
            An attribute that is usually set by `aria-expanded`.

            Learn more about [`aria-expanded`](https://www.w3.org/TR/wai-aria-1.2/#aria-expanded).
        include_hidden : Union[bool, None]
            Option that controls whether hidden elements are matched. By default, only non-hidden elements, as
            [defined by ARIA](https://www.w3.org/TR/wai-aria-1.2/#tree_exclusion), are matched by role selector.

            Learn more about [`aria-hidden`](https://www.w3.org/TR/wai-aria-1.2/#aria-hidden).
        level : Union[int, None]
            A number attribute that is usually present for roles `heading`, `listitem`, `row`, `treeitem`, with default values
            for `<h1>-<h6>` elements.

            Learn more about [`aria-level`](https://www.w3.org/TR/wai-aria-1.2/#aria-level).
        name : Union[Pattern[str], str, None]
            Option to match the [accessible name](https://w3c.github.io/accname/#dfn-accessible-name). By default, matching is
            case-insensitive and searches for a substring, use `exact` to control this behavior.

            Learn more about [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).
        pressed : Union[bool, None]
            An attribute that is usually set by `aria-pressed`.

            Learn more about [`aria-pressed`](https://www.w3.org/TR/wai-aria-1.2/#aria-pressed).
        selected : Union[bool, None]
            An attribute that is usually set by `aria-selected`.

            Learn more about [`aria-selected`](https://www.w3.org/TR/wai-aria-1.2/#aria-selected).

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.get_by_role(
                role=role,
                checked=checked,
                description=description,
                disabled=disabled,
                exact=exact,
                expanded=expanded,
                includeHidden=include_hidden,
                level=level,
                name=name,
                pressed=pressed,
                selected=selected,
            )
        )

    def get_by_test_id(
        self, test_id: typing.Union[str, typing.Pattern[str]]
    ) -> "Locator":
        """Frame.get_by_test_id

        Locate element by the test id.

        **Usage**

        Consider the following DOM structure.

        ```html
        <button data-testid=\"directions\">Itinéraire</button>
        ```

        You can locate the element by its test id:

        ```py
        page.get_by_test_id(\"directions\").click()
        ```

        **Details**

        By default, the `data-testid` attribute is used as a test id. Use `selectors.set_test_id_attribute()` to configure
        a different test id attribute if necessary.

        Parameters
        ----------
        test_id : Union[Pattern[str], str]
            Id to locate the element by.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_test_id(testId=test_id))

    def get_by_text(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Frame.get_by_text

        Allows locating elements that contain given text.

        See also `locator.filter()` that allows to match by another criteria, like an accessible role, and then filter by
        the text content.

        **Usage**

        Consider the following DOM structure:

        ```html
        <div>Hello <span>world</span></div>
        <div>Hello</div>
        ```

        You can locate by text substring, exact string, or a regular expression:

        ```py
        # Matches <span>
        page.get_by_text(\"world\")

        # Matches first <div>
        page.get_by_text(\"Hello world\")

        # Matches second <div>
        page.get_by_text(\"Hello\", exact=True)

        # Matches both <div>s
        page.get_by_text(re.compile(\"Hello\"))

        # Matches second <div>
        page.get_by_text(re.compile(\"^hello$\", re.IGNORECASE))
        ```

        **Details**

        Matching by text always normalizes whitespace, even with exact match. For example, it turns multiple spaces into
        one, turns line breaks into spaces and ignores leading and trailing whitespace.

        Input elements of the type `button` and `submit` are matched by their `value` instead of the text content. For
        example, locating by text `\"Log in\"` matches `<input type=button value=\"Log in\">`.

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_text(text=text, exact=exact))

    def get_by_title(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Frame.get_by_title

        Allows locating elements by their title attribute.

        **Usage**

        Consider the following DOM structure.

        ```html
        <span title='Issues count'>25 issues</span>
        ```

        You can check the issues count after locating it by the title text:

        ```py
        expect(page.get_by_title(\"Issues count\")).to_have_text(\"25 issues\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_title(text=text, exact=exact))

    def goto(
        self,
        url: str,
        *,
        referer: typing.Optional[str] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> typing.Optional["Response"]:
        """Frame.goto

        Returns the main resource response. In case of multiple redirects, the navigation will resolve with the response of
        the last redirect.

        The method will throw an error if:
        - there's an SSL error (e.g. in case of self-signed certificates).
        - target URL is invalid.
        - the `timeout` is exceeded during navigation.
        - the remote server does not respond or is unreachable.
        - the main resource failed to load.

        The method will not throw an error when any valid HTTP status code is returned by the remote server, including 404
        \"Not Found\" and 500 \"Internal Server Error\".  The status code for such responses can be retrieved by calling
        `response.status`.

        **NOTE** The method either throws an error or returns a main resource response. The only exceptions are navigation
        to `about:blank` or navigation to the same URL with a different hash, which would succeed and return `null`.

        **NOTE** Headless mode doesn't support navigation to a PDF document. See the
        [upstream issue](https://bugs.chromium.org/p/chromium/issues/detail?id=761295).

        Parameters
        ----------
        url : str
            URL to navigate frame to. The url should include scheme, e.g. `https://`.
        referer : Union[str, None]
            Referer header value. If provided it will take preference over the referer header value set by
            `page.set_extra_http_headers()`.
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.

        Returns
        -------
        Union[Response, None]
        """

        return mapping.from_impl_nullable(
            self._sync(
                self._impl_obj.goto(
                    url=url,
                    referer=referer,
                    timeout=to_milliseconds(timeout),
                    waitUntil=wait_until,
                )
            )
        )

    def hover(
        self,
        selector: str,
        *,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Frame.hover

        This method hovers over an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to hover over the center of the element, or the specified `position`.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.hover(
                selector=selector,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def inner_html(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Frame.inner_html

        Returns `element.innerHTML`.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.inner_html(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def inner_text(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Frame.inner_text

        Returns `element.innerText`.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.inner_text(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def input_value(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Frame.input_value

        Returns `input.value` for the selected `<input>` or `<textarea>` or `<select>` element.

        Throws for non-input elements. However, if the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), returns the value of the
        control.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.input_value(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_checked(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Frame.is_checked

        Returns whether the element is checked. Throws if the element is not a checkbox or radio input.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_checked(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_detached(self) -> bool:
        """Frame.is_detached

        Returns `true` if the frame has been detached, or `false` otherwise.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._impl_obj.is_detached())

    def is_disabled(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Frame.is_disabled

        Returns whether the element is disabled, the opposite of [enabled](https://playwright.dev/python/docs/actionability#enabled).

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_disabled(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_editable(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Frame.is_editable

        Returns whether the element is [editable](https://playwright.dev/python/docs/actionability#editable).

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_editable(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_enabled(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Frame.is_enabled

        Returns whether the element is [enabled](https://playwright.dev/python/docs/actionability#enabled).

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_enabled(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_hidden(self, selector: str, *, strict: typing.Optional[bool] = None) -> bool:
        """Frame.is_hidden

        Returns whether the element is hidden, the opposite of [visible](https://playwright.dev/python/docs/actionability#visible).  `selector` that
        does not match any elements is considered hidden.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.is_hidden(selector=selector, strict=strict))
        )

    def is_visible(
        self, selector: str, *, strict: typing.Optional[bool] = None
    ) -> bool:
        """Frame.is_visible

        Returns whether the element is [visible](https://playwright.dev/python/docs/actionability#visible). `selector` that does not match any elements
        is considered not visible.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.is_visible(selector=selector, strict=strict))
        )

    def locator(
        self,
        selector: str,
        *,
        has: typing.Optional["Locator"] = None,
        has_not: typing.Optional["Locator"] = None,
        has_not_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        has_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> "Locator":
        """Frame.locator

        The method returns an element locator that can be used to perform actions on this page / frame. Locator is resolved
        to the element immediately before performing an action, so a series of actions on the same locator can in fact be
        performed on different DOM elements. That would happen if the DOM structure between those actions has changed.

        [Learn more about locators](https://playwright.dev/python/docs/locators).

        [Learn more about locators](https://playwright.dev/python/docs/locators).

        Parameters
        ----------
        selector : str
            A selector to use when resolving DOM element.
        has : Union[Locator, None]
            Narrows down the results of the method to those which contain elements matching this relative locator. For example,
            `article` that has `text=Playwright` matches `<article><div>Playwright</div></article>`.

            Inner locator **must be relative** to the outer locator and is queried starting with the outer locator match, not
            the document root. For example, you can find `content` that has `div` in
            `<article><content><div>Playwright</div></content></article>`. However, looking for `content` that has `article
            div` will fail, because the inner locator must be relative and should not use any elements outside the `content`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not : Union[Locator, None]
            Matches elements that do not contain an element that matches an inner locator. Inner locator is queried against the
            outer one. For example, `article` that does not have `div` matches `<article><span>Playwright</span></article>`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not_text : Union[Pattern[str], str, None]
            Matches elements that do not contain specified text somewhere inside, possibly in a child or a descendant element.
            When passed a [string], matching is case-insensitive and searches for a substring.
        has_text : Union[Pattern[str], str, None]
            Matches elements containing specified text somewhere inside, possibly in a child or a descendant element. When
            passed a [string], matching is case-insensitive and searches for a substring. For example, `"Playwright"` matches
            `<article><div>Playwright</div></article>`.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.locator(
                selector=selector,
                has=has._impl_obj if has else None,
                hasNot=has_not._impl_obj if has_not else None,
                hasNotText=has_not_text,
                hasText=has_text,
            )
        )

    @property
    def name(self) -> str:
        """Frame.name

        Returns frame's name attribute as specified in the tag.

        If the name is empty, returns the id attribute instead.

        **NOTE** This value is calculated once when the frame is created, and will not update if the attribute is changed
        later.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.name)

    @property
    def page(self) -> "Page":
        """Frame.page

        Returns the page containing this frame.

        Returns
        -------
        Page
        """
        return mapping.from_impl(self._impl_obj.page)

    @property
    def parent_frame(self) -> typing.Optional["Frame"]:
        """Frame.parent_frame

        Parent frame, if any. Detached frames and main frames return `null`.

        Returns
        -------
        Union[Frame, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.parent_frame)

    def press(
        self,
        selector: str,
        key: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Frame.press

        `key` can specify the intended
        [keyboardEvent.key](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key) value or a single character
        to generate the text for. A superset of the `key` values can be found
        [here](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values). Examples of the keys are:

        `F1` - `F12`, `Digit0`- `Digit9`, `KeyA`- `KeyZ`, `Backquote`, `Minus`, `Equal`, `Backslash`, `Backspace`, `Tab`,
        `Delete`, `Escape`, `ArrowDown`, `End`, `Enter`, `Home`, `Insert`, `PageDown`, `PageUp`, `ArrowRight`, `ArrowUp`,
        etc.

        Following modification shortcuts are also supported: `Shift`, `Control`, `Alt`, `Meta`, `ShiftLeft`,
        `ControlOrMeta`. `ControlOrMeta` resolves to `Control` on Windows and Linux and to `Meta` on macOS.

        Holding down `Shift` will type the text that corresponds to the `key` in the upper case.

        If `key` is a single character, it is case-sensitive, so the values `a` and `A` will generate different respective
        texts.

        Shortcuts such as `key: \"Control+o\"`, `key: \"Control++` or `key: \"Control+Shift+T\"` are supported as well. When
        specified with the modifier, modifier is pressed and being held while the subsequent key is being pressed.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        key : str
            Name of the key to press or a character to generate, such as `ArrowLeft` or `a`.
        delay : Union[float, None]
            Time to wait between `keydown` and `keyup` in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            Actions that initiate navigations are waiting for these navigations to happen and for pages to start loading. You
            can opt out of waiting via setting this flag. You would only need this option in the exceptional cases such as
            navigating to inaccessible pages. Defaults to `false`.
            Deprecated: This option will default to `true` in the future.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.press(
                selector=selector,
                key=key,
                delay=delay,
                noWaitAfter=no_wait_after,
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def query_selector(
        self, selector: str, *, strict: typing.Optional[bool] = None
    ) -> typing.Optional["ElementHandle"]:
        """Frame.query_selector

        Returns the ElementHandle pointing to the frame element.

        **NOTE** The use of `ElementHandle` is discouraged, use `Locator` objects and web-first assertions instead.

        The method finds an element matching the specified selector within the frame. If no elements match the selector,
        returns `null`.

        Parameters
        ----------
        selector : str
            A selector to query for.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.

        Returns
        -------
        Union[ElementHandle, None]
        """

        return mapping.from_impl_nullable(
            self._sync(self._impl_obj.query_selector(selector=selector, strict=strict))
        )

    def query_selector_all(self, selector: str) -> typing.List["ElementHandle"]:
        """Frame.query_selector_all

        Returns the ElementHandles pointing to the frame elements.

        **NOTE** The use of `ElementHandle` is discouraged, use `Locator` objects instead.

        The method finds all elements matching the specified selector within the frame. If no elements match the selector,
        returns empty array.

        Parameters
        ----------
        selector : str
            A selector to query for.

        Returns
        -------
        List[ElementHandle]
        """

        return mapping.from_impl_list(
            self._sync(self._impl_obj.query_selector_all(selector=selector))
        )

    def select_option(
        self,
        selector: str,
        value: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None,
        *,
        element: typing.Optional[
            typing.Union["ElementHandle", typing.Sequence["ElementHandle"]]
        ] = None,
        force: typing.Optional[bool] = None,
        index: typing.Optional[typing.Union[int, typing.Sequence[int]]] = None,
        label: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.List[str]:
        """Frame.select_option

        This method waits for an element matching `selector`, waits for [actionability](https://playwright.dev/python/docs/actionability) checks, waits
        until all specified options are present in the `<select>` element and selects these options.

        If the target element is not a `<select>` element, this method throws an error. However, if the element is inside
        the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be used
        instead.

        Returns the array of option values that have been successfully selected.

        Triggers a `change` and `input` event once all the provided options have been selected.

        **Usage**

        ```py
        # Single selection matching the value or label
        frame.select_option(\"select#colors\", \"blue\")
        # single selection matching both the label
        frame.select_option(\"select#colors\", label=\"blue\")
        # multiple selection
        frame.select_option(\"select#colors\", value=[\"red\", \"green\", \"blue\"])
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        value : Union[Sequence[str], str, None]
            Options to select by value. If the `<select>` has the `multiple` attribute, all given options are selected,
            otherwise only the first option matching one of the passed options is selected. Optional.
        element : Union[ElementHandle, Sequence[ElementHandle], None]
            Option elements to select. Optional.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        index : Union[Sequence[int], int, None]
            Options to select by index. Optional.
        label : Union[Sequence[str], str, None]
            Options to select by label. If the `<select>` has the `multiple` attribute, all given options are selected,
            otherwise only the first option matching one of the passed options is selected. Optional.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        List[str]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.select_option(
                    selector=selector,
                    value=mapping.to_impl(value),
                    element=mapping.to_impl(element),
                    force=force,
                    index=mapping.to_impl(index),
                    label=mapping.to_impl(label),
                    noWaitAfter=no_wait_after,
                    strict=strict,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def set_checked(
        self,
        selector: str,
        checked: bool,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Frame.set_checked

        This method checks or unchecks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Ensure that matched element is a checkbox or a radio input. If not, this method throws.
        1. If the element already has the right checked state, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now checked or unchecked. If not, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        checked : bool
            Whether to check or uncheck the checkbox.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.set_checked(
                selector=selector,
                checked=checked,
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def set_content(
        self,
        html: str,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> None:
        """Frame.set_content

        This method internally calls [document.write()](https://developer.mozilla.org/en-US/docs/Web/API/Document/write),
        inheriting all its specific characteristics and behaviors.

        Parameters
        ----------
        html : str
            HTML markup to assign to the page.
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.
        """

        self._sync(
            self._impl_obj.set_content(
                html=html, timeout=to_milliseconds(timeout), waitUntil=wait_until
            )
        )

    def set_input_files(
        self,
        selector: str,
        files: typing.Union[
            str,
            pathlib.Path,
            typing.Sequence[typing.Union[str, pathlib.Path]],
            FilePayload,
            typing.Sequence[FilePayload],
        ],
        *,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Frame.set_input_files

        Sets the value of the file input to these file paths or files. If some of the `filePaths` are relative paths, then
        they are resolved relative to the current working directory. For empty array, clears the selected files.

        This method expects `selector` to point to an
        [input element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input). However, if the element is inside
        the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), targets the control instead.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        files : Union[Sequence[Union[pathlib.Path, str]], Sequence[{name: str, mimeType: str, buffer: bytes}], pathlib.Path, str, {name: str, mimeType: str, buffer: bytes}]
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.set_input_files(
                selector=selector,
                files=mapping.to_impl(files),
                noWaitAfter=no_wait_after,
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def tap(
        self,
        selector: str,
        *,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Frame.tap

        This method taps an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.touchscreen` to tap the center of the element, or the specified `position`.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **NOTE** `frame.tap()` requires that the `hasTouch` option of the browser context be set to true.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.tap(
                selector=selector,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def text_content(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional[str]:
        """Frame.text_content

        Returns `element.textContent`.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.text_content(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def title(self) -> str:
        """Frame.title

        Returns the page title.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.title()))

    def type(
        self,
        selector: str,
        text: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Frame.type

        Sends a `keydown`, `keypress`/`input`, and `keyup` event for each character in the text. `frame.type` can be used
        to send fine-grained keyboard events. To fill values in form fields, use `frame.fill()`.

        To press a special key, like `Control` or `ArrowDown`, use `keyboard.press()`.

        **Usage**

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        text : str
            A text to type into a focused element.
        delay : Union[float, None]
            Time to wait between key presses in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.type(
                selector=selector,
                text=text,
                delay=delay,
                noWaitAfter=no_wait_after,
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def uncheck(
        self,
        selector: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Frame.uncheck

        This method checks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Ensure that matched element is a checkbox or a radio input. If not, this method throws. If the element is
           already unchecked, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now unchecked. If not, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.uncheck(
                selector=selector,
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    @property
    def url(self) -> str:
        """Frame.url

        Returns frame's url.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)

    def wait_for_function(
        self,
        expression: str,
        *,
        arg: typing.Optional[typing.Any] = None,
        polling: typing.Optional[typing.Union[float, Literal["raf"]]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "JSHandle":
        """Frame.wait_for_function

        Returns when the `expression` returns a truthy value, returns that value.

        **Usage**

        The `frame.wait_for_function()` can be used to observe viewport size change:

        ```py
        from playwright.sync_api import sync_playwright, Playwright

        def run(playwright: Playwright):
            webkit = playwright.webkit
            browser = webkit.launch()
            page = browser.new_page()
            page.evaluate(\"window.x = 0; setTimeout(() => { window.x = 100 }, 1000);\")
            page.main_frame.wait_for_function(\"() => window.x > 0\")
            browser.close()

        with sync_playwright() as playwright:
            run(playwright)
        ```

        To pass an argument to the predicate of `frame.waitForFunction` function:

        ```py
        selector = \".foo\"
        frame.wait_for_function(\"selector => !!document.querySelector(selector)\", selector)
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.
        polling : Union["raf", float, None]
            If `polling` is `'raf'`, then `expression` is constantly executed in `requestAnimationFrame` callback. If `polling`
            is a number, then it is treated as an interval in milliseconds at which the function would be executed. Defaults to
            `raf`.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()`
            methods.

        Returns
        -------
        JSHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.wait_for_function(
                    expression=expression,
                    arg=mapping.to_impl(arg),
                    polling=polling,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def wait_for_load_state(
        self,
        state: typing.Optional[
            Literal["domcontentloaded", "load", "networkidle"]
        ] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Frame.wait_for_load_state

        Waits for the required load state to be reached.

        This returns when the frame reaches a required load state, `load` by default. The navigation must have been
        committed when this method is called. If current document has already reached the required state, resolves
        immediately.

        **NOTE** Most of the time, this method is not needed because Playwright
        [auto-waits before every action](https://playwright.dev/python/docs/actionability).

        **Usage**

        ```py
        frame.click(\"button\") # click triggers navigation.
        frame.wait_for_load_state() # the promise resolves after \"load\" event.
        ```

        Parameters
        ----------
        state : Union["domcontentloaded", "load", "networkidle", None]
            Optional load state to wait for, defaults to `load`. If the state has been already reached while loading current
            document, the method resolves immediately. Can be one of:
            - `'load'` - wait for the `load` event to be fired.
            - `'domcontentloaded'` - wait for the `DOMContentLoaded` event to be fired.
            - `'networkidle'` - **DISCOURAGED** wait until there are no network connections for at least `500` ms. Don't use
              this method for testing, rely on web assertions to assess readiness instead.
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        """

        self._sync(
            self._impl_obj.wait_for_load_state(
                state=state, timeout=to_milliseconds(timeout)
            )
        )

    def wait_for_selector(
        self,
        selector: str,
        *,
        state: typing.Optional[
            Literal["attached", "detached", "hidden", "visible"]
        ] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional["ElementHandle"]:
        """Frame.wait_for_selector

        Returns when element specified by selector satisfies `state` option. Returns `null` if waiting for `hidden` or
        `detached`.

        **NOTE** Playwright automatically waits for element to be ready before performing an action. Using `Locator`
        objects and web-first assertions make the code wait-for-selector-free.

        Wait for the `selector` to satisfy `state` option (either appear/disappear from dom, or become visible/hidden). If
        at the moment of calling the method `selector` already satisfies the condition, the method will return immediately.
        If the selector doesn't satisfy the condition for the `timeout` milliseconds, the function will throw.

        **Usage**

        This method works across navigations:

        ```py
        from playwright.sync_api import sync_playwright, Playwright

        def run(playwright: Playwright):
            chromium = playwright.chromium
            browser = chromium.launch()
            page = browser.new_page()
            for current_url in [\"https://google.com\", \"https://bbc.com\"]:
                page.goto(current_url, wait_until=\"domcontentloaded\")
                element = page.main_frame.wait_for_selector(\"img\")
                print(\"Loaded image: \" + str(element.get_attribute(\"src\")))
            browser.close()

        with sync_playwright() as playwright:
            run(playwright)
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        state : Union["attached", "detached", "hidden", "visible", None]
            Defaults to `'visible'`. Can be either:
            - `'attached'` - wait for element to be present in DOM.
            - `'detached'` - wait for element to not be present in DOM.
            - `'visible'` - wait for element to have non-empty bounding box and no `visibility:hidden`. Note that element
              without any content or with `display:none` has an empty bounding box and is not considered visible.
            - `'hidden'` - wait for element to be either detached from DOM, or have an empty bounding box or
              `visibility:hidden`. This is opposite to the `'visible'` option.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[ElementHandle, None]
        """

        return mapping.from_impl_nullable(
            self._sync(
                self._impl_obj.wait_for_selector(
                    selector=selector,
                    state=state,
                    strict=strict,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def wait_for_timeout(
        self, timeout: typing.Union[float, datetime.timedelta]
    ) -> None:
        """Frame.wait_for_timeout

        Waits for the given `timeout` in milliseconds.

        Note that `frame.waitForTimeout()` should only be used for debugging. Tests using the timer in production are going
        to be flaky. Use signals such as network events, selectors becoming visible and others instead.

        Parameters
        ----------
        timeout : float
            A timeout to wait for
        """

        self._sync(self._impl_obj.wait_for_timeout(timeout=to_milliseconds(timeout)))

    def wait_for_url(
        self,
        url: typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> None:
        """Frame.wait_for_url

        Waits for the frame to navigate to the given URL.

        **Usage**

        ```py
        frame.click(\"a.delayed-navigation\") # clicking the link will indirectly cause a navigation
        frame.wait_for_url(\"**/target.html\")
        ```

        Parameters
        ----------
        url : Union[Callable[[str], bool], Pattern[str], str]
            A glob pattern, regex pattern, or predicate receiving [URL] to match while waiting for the navigation. Note that if
            the parameter is a string without wildcard characters, the method will wait for navigation to URL that is exactly
            equal to the string.
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.
        """

        self._sync(
            self._impl_obj.wait_for_url(
                url=self._wrap_handler(url),
                timeout=to_milliseconds(timeout),
                waitUntil=wait_until,
            )
        )

    @property
    def webmcp(self) -> "WebMCP":
        """Frame.webmcp

        Tools that the frame registers through the experimental `WebMCP` browser API. See `WebMCP` for details.

        Returns
        -------
        WebMCP
        """
        return mapping.from_impl(self._impl_obj.webmcp)


mapping.register(FrameImpl, Frame)


class FrameLocator(SyncBase):
    _impl_obj: FrameLocatorImpl

    @property
    def first(self) -> "FrameLocator":
        """FrameLocator.first

        Returns locator to the first matching frame.

        Returns
        -------
        FrameLocator
        """
        return mapping.from_impl(self._impl_obj.first)

    def frame_locator(self, selector: str) -> "FrameLocator":
        """FrameLocator.frame_locator

        When working with iframes, you can create a frame locator that will enter the iframe and allow selecting elements
        in that iframe.

        Parameters
        ----------
        selector : str
            A selector to use when resolving DOM element.

        Returns
        -------
        FrameLocator
        """

        return mapping.from_impl(self._impl_obj.frame_locator(selector=selector))

    def get_by_alt_text(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """FrameLocator.get_by_alt_text

        Allows locating elements by their alt text.

        **Usage**

        For example, this method will find the image by alt text \"Playwright logo\":

        ```html
        <img alt='Playwright logo'>
        ```

        ```py
        page.get_by_alt_text(\"Playwright logo\").click()
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_alt_text(text=text, exact=exact))

    def get_by_label(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """FrameLocator.get_by_label

        Allows locating input elements by the text of the associated `<label>` or `aria-labelledby` element, or by the
        `aria-label` attribute.

        **Usage**

        For example, this method will find inputs by label \"Username\" and \"Password\" in the following DOM:

        ```html
        <input aria-label=\"Username\">
        <label for=\"password-input\">Password:</label>
        <input id=\"password-input\">
        ```

        ```py
        page.get_by_label(\"Username\").fill(\"john\")
        page.get_by_label(\"Password\").fill(\"secret\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_label(text=text, exact=exact))

    def get_by_placeholder(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """FrameLocator.get_by_placeholder

        Allows locating input elements by the placeholder text.

        **Usage**

        For example, consider the following DOM structure.

        ```html
        <input type=\"email\" placeholder=\"name@example.com\" />
        ```

        You can fill the input after locating it by the placeholder text:

        ```py
        page.get_by_placeholder(\"name@example.com\").fill(\"playwright@microsoft.com\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.get_by_placeholder(text=text, exact=exact)
        )

    def get_by_role(
        self,
        role: Literal[
            "alert",
            "alertdialog",
            "application",
            "article",
            "banner",
            "blockquote",
            "button",
            "caption",
            "cell",
            "checkbox",
            "code",
            "columnheader",
            "combobox",
            "complementary",
            "contentinfo",
            "definition",
            "deletion",
            "dialog",
            "directory",
            "document",
            "emphasis",
            "feed",
            "figure",
            "form",
            "generic",
            "grid",
            "gridcell",
            "group",
            "heading",
            "img",
            "insertion",
            "link",
            "list",
            "listbox",
            "listitem",
            "log",
            "main",
            "marquee",
            "math",
            "menu",
            "menubar",
            "menuitem",
            "menuitemcheckbox",
            "menuitemradio",
            "meter",
            "navigation",
            "none",
            "note",
            "option",
            "paragraph",
            "presentation",
            "progressbar",
            "radio",
            "radiogroup",
            "region",
            "row",
            "rowgroup",
            "rowheader",
            "scrollbar",
            "search",
            "searchbox",
            "separator",
            "slider",
            "spinbutton",
            "status",
            "strong",
            "subscript",
            "superscript",
            "switch",
            "tab",
            "table",
            "tablist",
            "tabpanel",
            "term",
            "textbox",
            "time",
            "timer",
            "toolbar",
            "tooltip",
            "tree",
            "treegrid",
            "treeitem",
        ],
        *,
        checked: typing.Optional[bool] = None,
        description: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        disabled: typing.Optional[bool] = None,
        exact: typing.Optional[bool] = None,
        expanded: typing.Optional[bool] = None,
        include_hidden: typing.Optional[bool] = None,
        level: typing.Optional[int] = None,
        name: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        pressed: typing.Optional[bool] = None,
        selected: typing.Optional[bool] = None,
    ) -> "Locator":
        """FrameLocator.get_by_role

        Allows locating elements by their [ARIA role](https://www.w3.org/TR/wai-aria-1.2/#roles),
        [ARIA attributes](https://www.w3.org/TR/wai-aria-1.2/#aria-attributes) and
        [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).

        **Usage**

        Consider the following DOM structure.

        ```html
        <h3>Sign up</h3>
        <label>
          <input type=\"checkbox\" /> Subscribe
        </label>
        <br/>
        <button>Submit</button>
        ```

        You can locate each element by its implicit role:

        ```py
        expect(page.get_by_role(\"heading\", name=\"Sign up\")).to_be_visible()

        page.get_by_role(\"checkbox\", name=\"Subscribe\").check()

        page.get_by_role(\"button\", name=re.compile(\"submit\", re.IGNORECASE)).click()
        ```

        **Details**

        Role selector **does not replace** accessibility audits and conformance tests, but rather gives early feedback
        about the ARIA guidelines.

        Many html elements have an implicitly [defined role](https://w3c.github.io/html-aam/#html-element-role-mappings)
        that is recognized by the role selector. You can find all the
        [supported roles here](https://www.w3.org/TR/wai-aria-1.2/#role_definitions). ARIA guidelines **do not recommend**
        duplicating implicit roles and attributes by setting `role` and/or `aria-*` attributes to default values.

        Parameters
        ----------
        role : Union["alert", "alertdialog", "application", "article", "banner", "blockquote", "button", "caption", "cell", "checkbox", "code", "columnheader", "combobox", "complementary", "contentinfo", "definition", "deletion", "dialog", "directory", "document", "emphasis", "feed", "figure", "form", "generic", "grid", "gridcell", "group", "heading", "img", "insertion", "link", "list", "listbox", "listitem", "log", "main", "marquee", "math", "menu", "menubar", "menuitem", "menuitemcheckbox", "menuitemradio", "meter", "navigation", "none", "note", "option", "paragraph", "presentation", "progressbar", "radio", "radiogroup", "region", "row", "rowgroup", "rowheader", "scrollbar", "search", "searchbox", "separator", "slider", "spinbutton", "status", "strong", "subscript", "superscript", "switch", "tab", "table", "tablist", "tabpanel", "term", "textbox", "time", "timer", "toolbar", "tooltip", "tree", "treegrid", "treeitem"]
            Required aria role.
        checked : Union[bool, None]
            An attribute that is usually set by `aria-checked` or native `<input type=checkbox>` controls.

            Learn more about [`aria-checked`](https://www.w3.org/TR/wai-aria-1.2/#aria-checked).
        description : Union[Pattern[str], str, None]
            Option to match the [accessible description](https://w3c.github.io/accname/#dfn-accessible-description). By
            default, matching is case-insensitive and searches for a substring, use `exact` to control this behavior.

            Learn more about [accessible description](https://w3c.github.io/accname/#dfn-accessible-description).
        disabled : Union[bool, None]
            An attribute that is usually set by `aria-disabled` or `disabled`.

            **NOTE** Unlike most other attributes, `disabled` is inherited through the DOM hierarchy. Learn more about
            [`aria-disabled`](https://www.w3.org/TR/wai-aria-1.2/#aria-disabled).

        exact : Union[bool, None]
            Whether `name` and `description` are matched exactly: case-sensitive and whole-string. Defaults to false. Ignored
            when the value is a regular expression. Note that exact match still trims whitespace.
        expanded : Union[bool, None]
            An attribute that is usually set by `aria-expanded`.

            Learn more about [`aria-expanded`](https://www.w3.org/TR/wai-aria-1.2/#aria-expanded).
        include_hidden : Union[bool, None]
            Option that controls whether hidden elements are matched. By default, only non-hidden elements, as
            [defined by ARIA](https://www.w3.org/TR/wai-aria-1.2/#tree_exclusion), are matched by role selector.

            Learn more about [`aria-hidden`](https://www.w3.org/TR/wai-aria-1.2/#aria-hidden).
        level : Union[int, None]
            A number attribute that is usually present for roles `heading`, `listitem`, `row`, `treeitem`, with default values
            for `<h1>-<h6>` elements.

            Learn more about [`aria-level`](https://www.w3.org/TR/wai-aria-1.2/#aria-level).
        name : Union[Pattern[str], str, None]
            Option to match the [accessible name](https://w3c.github.io/accname/#dfn-accessible-name). By default, matching is
            case-insensitive and searches for a substring, use `exact` to control this behavior.

            Learn more about [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).
        pressed : Union[bool, None]
            An attribute that is usually set by `aria-pressed`.

            Learn more about [`aria-pressed`](https://www.w3.org/TR/wai-aria-1.2/#aria-pressed).
        selected : Union[bool, None]
            An attribute that is usually set by `aria-selected`.

            Learn more about [`aria-selected`](https://www.w3.org/TR/wai-aria-1.2/#aria-selected).

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.get_by_role(
                role=role,
                checked=checked,
                description=description,
                disabled=disabled,
                exact=exact,
                expanded=expanded,
                includeHidden=include_hidden,
                level=level,
                name=name,
                pressed=pressed,
                selected=selected,
            )
        )

    def get_by_test_id(
        self, test_id: typing.Union[str, typing.Pattern[str]]
    ) -> "Locator":
        """FrameLocator.get_by_test_id

        Locate element by the test id.

        **Usage**

        Consider the following DOM structure.

        ```html
        <button data-testid=\"directions\">Itinéraire</button>
        ```

        You can locate the element by its test id:

        ```py
        page.get_by_test_id(\"directions\").click()
        ```

        **Details**

        By default, the `data-testid` attribute is used as a test id. Use `selectors.set_test_id_attribute()` to configure
        a different test id attribute if necessary.

        Parameters
        ----------
        test_id : Union[Pattern[str], str]
            Id to locate the element by.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_test_id(testId=test_id))

    def get_by_text(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """FrameLocator.get_by_text

        Allows locating elements that contain given text.

        See also `locator.filter()` that allows to match by another criteria, like an accessible role, and then filter by
        the text content.

        **Usage**

        Consider the following DOM structure:

        ```html
        <div>Hello <span>world</span></div>
        <div>Hello</div>
        ```

        You can locate by text substring, exact string, or a regular expression:

        ```py
        # Matches <span>
        page.get_by_text(\"world\")

        # Matches first <div>
        page.get_by_text(\"Hello world\")

        # Matches second <div>
        page.get_by_text(\"Hello\", exact=True)

        # Matches both <div>s
        page.get_by_text(re.compile(\"Hello\"))

        # Matches second <div>
        page.get_by_text(re.compile(\"^hello$\", re.IGNORECASE))
        ```

        **Details**

        Matching by text always normalizes whitespace, even with exact match. For example, it turns multiple spaces into
        one, turns line breaks into spaces and ignores leading and trailing whitespace.

        Input elements of the type `button` and `submit` are matched by their `value` instead of the text content. For
        example, locating by text `\"Log in\"` matches `<input type=button value=\"Log in\">`.

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_text(text=text, exact=exact))

    def get_by_title(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """FrameLocator.get_by_title

        Allows locating elements by their title attribute.

        **Usage**

        Consider the following DOM structure.

        ```html
        <span title='Issues count'>25 issues</span>
        ```

        You can check the issues count after locating it by the title text:

        ```py
        expect(page.get_by_title(\"Issues count\")).to_have_text(\"25 issues\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_title(text=text, exact=exact))

    @property
    def last(self) -> "FrameLocator":
        """FrameLocator.last

        Returns locator to the last matching frame.

        Returns
        -------
        FrameLocator
        """
        return mapping.from_impl(self._impl_obj.last)

    def locator(
        self,
        selector_or_locator: typing.Union[str, "Locator"],
        *,
        has: typing.Optional["Locator"] = None,
        has_not: typing.Optional["Locator"] = None,
        has_not_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        has_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> "Locator":
        """FrameLocator.locator

        The method finds an element matching the specified selector in the locator's subtree. It also accepts filter
        options, similar to `locator.filter()` method.

        [Learn more about locators](https://playwright.dev/python/docs/locators).

        Parameters
        ----------
        selector_or_locator : Union[Locator, str]
            A selector or locator to use when resolving DOM element.
        has : Union[Locator, None]
            Narrows down the results of the method to those which contain elements matching this relative locator. For example,
            `article` that has `text=Playwright` matches `<article><div>Playwright</div></article>`.

            Inner locator **must be relative** to the outer locator and is queried starting with the outer locator match, not
            the document root. For example, you can find `content` that has `div` in
            `<article><content><div>Playwright</div></content></article>`. However, looking for `content` that has `article
            div` will fail, because the inner locator must be relative and should not use any elements outside the `content`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not : Union[Locator, None]
            Matches elements that do not contain an element that matches an inner locator. Inner locator is queried against the
            outer one. For example, `article` that does not have `div` matches `<article><span>Playwright</span></article>`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not_text : Union[Pattern[str], str, None]
            Matches elements that do not contain specified text somewhere inside, possibly in a child or a descendant element.
            When passed a [string], matching is case-insensitive and searches for a substring.
        has_text : Union[Pattern[str], str, None]
            Matches elements containing specified text somewhere inside, possibly in a child or a descendant element. When
            passed a [string], matching is case-insensitive and searches for a substring. For example, `"Playwright"` matches
            `<article><div>Playwright</div></article>`.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.locator(
                selectorOrLocator=mapping.to_impl(selector_or_locator),
                has=has._impl_obj if has else None,
                hasNot=has_not._impl_obj if has_not else None,
                hasNotText=has_not_text,
                hasText=has_text,
            )
        )

    def nth(self, index: int) -> "FrameLocator":
        """FrameLocator.nth

        Returns locator to the n-th matching frame. It's zero based, `nth(0)` selects the first frame.

        Parameters
        ----------
        index : int

        Returns
        -------
        FrameLocator
        """

        return mapping.from_impl(self._impl_obj.nth(index=index))

    @property
    def owner(self) -> "Locator":
        """FrameLocator.owner

        Returns a `Locator` object pointing to the same `iframe` as this frame locator.

        Useful when you have a `FrameLocator` object obtained somewhere, and later on would like to interact with the
        `iframe` element.

        For a reverse operation, use `locator.content_frame`.

        **Usage**

        ```py
        frame_locator = page.locator(\"iframe[name=\\\"embedded\\\"]\").content_frame
        # ...
        locator = frame_locator.owner
        expect(locator).to_be_visible()
        ```

        Returns
        -------
        Locator
        """
        return mapping.from_impl(self._impl_obj.owner)


mapping.register(FrameLocatorImpl, FrameLocator)


class Keyboard(SyncBase):
    _impl_obj: KeyboardImpl

    def down(self, key: str) -> None:
        """Keyboard.down

        Dispatches a `keydown` event.

        `key` can specify the intended
        [keyboardEvent.key](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key) value or a single character
        to generate the text for. A superset of the `key` values can be found
        [here](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values). Examples of the keys are:

        `F1` - `F12`, `Digit0`- `Digit9`, `KeyA`- `KeyZ`, `Backquote`, `Minus`, `Equal`, `Backslash`, `Backspace`, `Tab`,
        `Delete`, `Escape`, `ArrowDown`, `End`, `Enter`, `Home`, `Insert`, `PageDown`, `PageUp`, `ArrowRight`, `ArrowUp`,
        etc.

        Following modification shortcuts are also supported: `Shift`, `Control`, `Alt`, `Meta`, `ShiftLeft`,
        `ControlOrMeta`. `ControlOrMeta` resolves to `Control` on Windows and Linux and to `Meta` on macOS.

        Holding down `Shift` will type the text that corresponds to the `key` in the upper case.

        If `key` is a single character, it is case-sensitive, so the values `a` and `A` will generate different respective
        texts.

        If `key` is a modifier key, `Shift`, `Meta`, `Control`, or `Alt`, subsequent key presses will be sent with that
        modifier active. To release the modifier key, use `keyboard.up()`.

        After the key is pressed once, subsequent calls to `keyboard.down()` will have
        [repeat](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/repeat) set to true. To release the key,
        use `keyboard.up()`.

        **NOTE** Modifier keys DO influence `keyboard.down`. Holding down `Shift` will type the text in upper case.

        Parameters
        ----------
        key : str
            Name of the key to press or a character to generate, such as `ArrowLeft` or `a`.
        """

        self._sync(self._impl_obj.down(key=key))

    def insert_text(self, text: str) -> None:
        """Keyboard.insert_text

        Dispatches only `input` event, does not emit the `keydown`, `keyup` or `keypress` events.

        **Usage**

        ```py
        page.keyboard.insert_text(\"嗨\")
        ```

        **NOTE** Modifier keys DO NOT effect `keyboard.insertText`. Holding down `Shift` will not type the text in upper
        case.

        Parameters
        ----------
        text : str
            Sets input to the specified text value.
        """

        self._sync(self._impl_obj.insert_text(text=text))

    def press(self, key: str, *, delay: typing.Optional[float] = None) -> None:
        """Keyboard.press

        **NOTE** In most cases, you should use `locator.press()` instead.

        `key` can specify the intended
        [keyboardEvent.key](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key) value or a single character
        to generate the text for. A superset of the `key` values can be found
        [here](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values). Examples of the keys are:

        `F1` - `F12`, `Digit0`- `Digit9`, `KeyA`- `KeyZ`, `Backquote`, `Minus`, `Equal`, `Backslash`, `Backspace`, `Tab`,
        `Delete`, `Escape`, `ArrowDown`, `End`, `Enter`, `Home`, `Insert`, `PageDown`, `PageUp`, `ArrowRight`, `ArrowUp`,
        etc.

        Following modification shortcuts are also supported: `Shift`, `Control`, `Alt`, `Meta`, `ShiftLeft`,
        `ControlOrMeta`. `ControlOrMeta` resolves to `Control` on Windows and Linux and to `Meta` on macOS.

        Holding down `Shift` will type the text that corresponds to the `key` in the upper case.

        If `key` is a single character, it is case-sensitive, so the values `a` and `A` will generate different respective
        texts.

        Shortcuts such as `key: \"Control+o\"`, `key: \"Control++` or `key: \"Control+Shift+T\"` are supported as well. When
        specified with the modifier, modifier is pressed and being held while the subsequent key is being pressed.

        **Usage**

        ```py
        page = browser.new_page()
        page.goto(\"https://keycode.info\")
        page.keyboard.press(\"a\")
        page.screenshot(path=\"a.png\")
        page.keyboard.press(\"ArrowLeft\")
        page.screenshot(path=\"arrow_left.png\")
        page.keyboard.press(\"Shift+O\")
        page.screenshot(path=\"o.png\")
        browser.close()
        ```

        Shortcut for `keyboard.down()` and `keyboard.up()`.

        Parameters
        ----------
        key : str
            Name of the key to press or a character to generate, such as `ArrowLeft` or `a`.
        delay : Union[float, None]
            Time to wait between `keydown` and `keyup` in milliseconds. Defaults to 0.
        """

        self._sync(self._impl_obj.press(key=key, delay=delay))

    def type(self, text: str, *, delay: typing.Optional[float] = None) -> None:
        """Keyboard.type

        **NOTE** In most cases, you should use `locator.fill()` instead. You only need to press keys one by one if there is
        special keyboard handling on the page - in this case use `locator.press_sequentially()`.

        Sends a `keydown`, `keypress`/`input`, and `keyup` event for each character in the text.

        To press a special key, like `Control` or `ArrowDown`, use `keyboard.press()`.

        **Usage**

        ```py
        page.keyboard.type(\"Hello\") # types instantly
        page.keyboard.type(\"World\", delay=100) # types slower, like a user
        ```

        **NOTE** Modifier keys DO NOT effect `keyboard.type`. Holding down `Shift` will not type the text in upper case.

        **NOTE** For characters that are not on a US keyboard, only an `input` event will be sent.

        Parameters
        ----------
        text : str
            A text to type into a focused element.
        delay : Union[float, None]
            Time to wait between key presses in milliseconds. Defaults to 0.
        """

        self._sync(self._impl_obj.type(text=text, delay=delay))

    def up(self, key: str) -> None:
        """Keyboard.up

        Dispatches a `keyup` event.

        Parameters
        ----------
        key : str
            Name of the key to press or a character to generate, such as `ArrowLeft` or `a`.
        """

        self._sync(self._impl_obj.up(key=key))


mapping.register(KeyboardImpl, Keyboard)


class Locator(SyncBase):
    _impl_obj: LocatorImpl

    def all(self) -> typing.List["Locator"]:
        """Locator.all

        When the locator points to a list of elements, this returns an array of locators, pointing to their respective
        elements.

        **NOTE** `locator.all()` does not wait for elements to match the locator, and instead immediately returns whatever
        is present in the page.

        When the list of elements changes dynamically, `locator.all()` will produce unpredictable and flaky results.

        When the list of elements is stable, but loaded dynamically, wait for the full list to finish loading before
        calling `locator.all()`.

        **Usage**

        ```py
        for li in page.get_by_role('listitem').all():
          li.click();
        ```

        Returns
        -------
        List[Locator]
        """

        return mapping.from_impl_list(self._sync(self._impl_obj.all()))

    def all_inner_texts(self) -> typing.List[str]:
        """Locator.all_inner_texts

        Returns an array of `node.innerText` values for all matching nodes.

        **NOTE** If you need to assert text on the page, prefer `locator_assertions.to_have_text()` with `use_inner_text`
        option to avoid flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        texts = page.get_by_role(\"link\").all_inner_texts()
        ```

        Returns
        -------
        List[str]
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.all_inner_texts()))

    def all_text_contents(self) -> typing.List[str]:
        """Locator.all_text_contents

        Returns an array of `node.textContent` values for all matching nodes.

        **NOTE** If you need to assert text on the page, prefer `locator_assertions.to_have_text()` to avoid flakiness. See
        [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        texts = page.get_by_role(\"link\").all_text_contents()
        ```

        Returns
        -------
        List[str]
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.all_text_contents()))

    def and_(self, locator: "Locator") -> "Locator":
        """Locator.and_

        Creates a locator that matches both this locator and the argument locator.

        **Usage**

        The following example finds a button with a specific title.

        ```py
        button = page.get_by_role(\"button\").and_(page.get_by_title(\"Subscribe\"))
        ```

        Parameters
        ----------
        locator : Locator
            Additional locator to match.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.and_(locator=locator._impl_obj))

    def aria_snapshot(
        self,
        *,
        boxes: typing.Optional[bool] = None,
        depth: typing.Optional[int] = None,
        mode: typing.Optional[Literal["ai", "default"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Locator.aria_snapshot

        Captures the aria snapshot of the given element. Read more about [aria snapshots](https://playwright.dev/python/docs/aria-snapshots) and
        `locator_assertions.to_match_aria_snapshot()` for the corresponding assertion.

        **Usage**

        ```py
        page.get_by_role(\"link\").aria_snapshot()
        ```

        **Details**

        This method captures the aria snapshot of the given element. The snapshot is a string that represents the state of
        the element and its children. The snapshot can be used to assert the state of the element in the test, or to
        compare it to state in the future.

        The ARIA snapshot is represented using [YAML](https://yaml.org/spec/1.2.2/) markup language:
        - The keys of the objects are the roles and optional accessible names of the elements.
        - The values are either text content or an array of child elements.
        - Generic static text can be represented with the `text` key.

        Below is the HTML markup and the respective ARIA snapshot:

        ```html
        <ul aria-label=\"Links\">
          <li><a href=\"/\">Home</a></li>
          <li><a href=\"/about\">About</a></li>
        <ul>
        ```

        ```yml
        - list \"Links\":
          - listitem:
            - link \"Home\"
          - listitem:
            - link \"About\"
        ```

        An AI-optimized snapshot, controlled by `mode`, is different from a default snapshot:
        1. Includes element references `[ref=e2]`. 2. Does not wait for an element matching the locator, and throws when
           no elements match. 3. Includes snapshots of `<iframe>`s inside the target.

        Parameters
        ----------
        boxes : Union[bool, None]
            When `true`, appends each element's bounding box as `[box=x,y,width,height]` to the snapshot. Coordinates are
            relative to the viewport, in CSS pixels, as returned by
            [`Element.getBoundingClientRect()`](https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect).
            Defaults to `false`.
        depth : Union[int, None]
            When specified, limits the depth of the snapshot.
        mode : Union["ai", "default", None]
            When set to `"ai"`, returns a snapshot optimized for AI consumption. Defaults to `"default"`. See details for more
            information.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.aria_snapshot(
                    boxes=boxes,
                    depth=depth,
                    mode=mode,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def blur(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.blur

        Calls [blur](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/blur) on the element.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(self._impl_obj.blur(timeout=to_milliseconds(timeout)))

    def bounding_box(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional[FloatRect]:
        """Locator.bounding_box

        This method returns the bounding box of the element matching the locator, or `null` if the element is not visible.
        The bounding box is calculated relative to the main frame viewport - which is usually the same as the browser
        window.

        **Details**

        Scrolling affects the returned bounding box, similarly to
        [Element.getBoundingClientRect](https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect).
        That means `x` and/or `y` may be negative.

        Elements from child frames return the bounding box relative to the main frame, unlike the
        [Element.getBoundingClientRect](https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect).

        Assuming the page is static, it is safe to use bounding box coordinates to perform input. For example, the
        following snippet should click the center of the element.

        **Usage**

        ```py
        box = page.get_by_role(\"button\").bounding_box()
        page.mouse.click(box[\"x\"] + box[\"width\"] / 2, box[\"y\"] + box[\"height\"] / 2)
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[{x: float, y: float, width: float, height: float}, None]
        """

        return mapping.from_impl_nullable(
            self._sync(self._impl_obj.bounding_box(timeout=to_milliseconds(timeout)))
        )

    def check(
        self,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Locator.check

        Ensure that checkbox or radio element is checked.

        **Details**

        Performs the following steps:
        1. Ensure that element is a checkbox or a radio input. If not, this method throws. If the element is already
           checked, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now checked. If not, this method throws.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **Usage**

        ```py
        page.get_by_role(\"checkbox\").check()
        ```

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.check(
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def clear(
        self,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.clear

        Clear the input field.

        **Details**

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, focuses the element, clears it and triggers an
        `input` event after clearing.

        If the target element is not an `<input>`, `<textarea>` or `[contenteditable]` element, this method throws an
        error. However, if the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be cleared
        instead.

        **Usage**

        ```py
        page.get_by_role(\"textbox\").clear()
        ```

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.clear(
                force=force, noWaitAfter=no_wait_after, timeout=to_milliseconds(timeout)
            )
        )

    def click(
        self,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        click_count: typing.Optional[int] = None,
        delay: typing.Optional[float] = None,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        steps: typing.Optional[int] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Locator.click

        Click an element.

        **Details**

        This method clicks the element by performing the following steps:
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element, or the specified `position`.
        1. Wait for initiated navigations to either succeed or fail, unless `no_wait_after` option is set.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **Usage**

        Click a button:

        ```py
        page.get_by_role(\"button\").click()
        ```

        Shift-right-click at a specific position on a canvas:

        ```py
        page.locator(\"canvas\").click(
            button=\"right\", modifiers=[\"Shift\"], position={\"x\": 23, \"y\": 32}
        )
        ```

        Parameters
        ----------
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        click_count : Union[int, None]
            defaults to 1. See [UIEvent.detail].
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            Actions that initiate navigations are waiting for these navigations to happen and for pages to start loading. You
            can opt out of waiting via setting this flag. You would only need this option in the exceptional cases such as
            navigating to inaccessible pages. Defaults to `false`.
            Deprecated: This option will default to `true` in the future.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        steps : Union[int, None]
            Defaults to 1. Sends `n` interpolated `mousemove` events to represent travel between Playwright's current cursor
            position and the provided destination. When set to 1, emits a single `mousemove` event at the destination location.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.click(
                button=button,
                clickCount=click_count,
                delay=delay,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                steps=steps,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    @property
    def content_frame(self) -> "FrameLocator":
        """Locator.content_frame

        Returns a `FrameLocator` object pointing to the same `iframe` as this locator.

        Useful when you have a `Locator` object obtained somewhere, and later on would like to interact with the content
        inside the frame.

        For a reverse operation, use `frame_locator.owner`.

        **Usage**

        ```py
        locator = page.locator(\"iframe[name=\\\"embedded\\\"]\")
        # ...
        frame_locator = locator.content_frame
        frame_locator.get_by_role(\"button\").click()
        ```

        Returns
        -------
        FrameLocator
        """
        return mapping.from_impl(self._impl_obj.content_frame)

    def count(self) -> int:
        """Locator.count

        Returns the number of elements matching the locator.

        **NOTE** If you need to assert the number of elements on the page, prefer `locator_assertions.to_have_count()` to
        avoid flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        count = page.get_by_role(\"listitem\").count()
        ```

        Returns
        -------
        int
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.count()))

    def dblclick(
        self,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        delay: typing.Optional[float] = None,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        steps: typing.Optional[int] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Locator.dblclick

        Double-click an element.

        **Details**

        This method double clicks the element by performing the following steps:
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to double click in the center of the element, or the specified `position`.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **NOTE** `element.dblclick()` dispatches two `click` events and a single `dblclick` event.

        Parameters
        ----------
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        steps : Union[int, None]
            Defaults to 1. Sends `n` interpolated `mousemove` events to represent travel between Playwright's current cursor
            position and the provided destination. When set to 1, emits a single `mousemove` event at the destination location.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.dblclick(
                button=button,
                delay=delay,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                steps=steps,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def describe(self, description: str) -> "Locator":
        """Locator.describe

        Describes the locator, description is used in the trace viewer and reports. Returns the locator pointing to the
        same element.

        **Usage**

        ```py
        button = page.get_by_test_id(\"btn-sub\").describe(\"Subscribe button\")
        button.click()
        ```

        Parameters
        ----------
        description : str
            Locator description.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.describe(description=description))

    @property
    def description(self) -> typing.Optional[str]:
        """Locator.description

        Returns locator description previously set with `locator.describe()`. Returns `null` if no custom description has
        been set.

        **Usage**

        ```py
        button = page.get_by_role(\"button\").describe(\"Subscribe button\")
        print(button.description())  # \"Subscribe button\"

        input = page.get_by_role(\"textbox\")
        print(input.description())  # None
        ```

        Returns
        -------
        Union[str, None]
        """
        return mapping.from_maybe_impl(self._impl_obj.description)

    def dispatch_event(
        self,
        type: str,
        event_init: typing.Optional[typing.Dict] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.dispatch_event

        Programmatically dispatch an event on the matching element.

        **Usage**

        ```py
        locator.dispatch_event(\"click\")
        ```

        **Details**

        The snippet above dispatches the `click` event on the element. Regardless of the visibility state of the element,
        `click` is dispatched. This is equivalent to calling
        [element.click()](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/click).

        Under the hood, it creates an instance of an event based on the given `type`, initializes it with `event_init`
        properties and dispatches it on the element. Events are `composed`, `cancelable` and bubble by default.

        Since `event_init` is event-specific, please refer to the events documentation for the lists of initial properties:
        - [DeviceMotionEvent](https://developer.mozilla.org/en-US/docs/Web/API/DeviceMotionEvent/DeviceMotionEvent)
        - [DeviceOrientationEvent](https://developer.mozilla.org/en-US/docs/Web/API/DeviceOrientationEvent/DeviceOrientationEvent)
        - [DragEvent](https://developer.mozilla.org/en-US/docs/Web/API/DragEvent/DragEvent)
        - [Event](https://developer.mozilla.org/en-US/docs/Web/API/Event/Event)
        - [FocusEvent](https://developer.mozilla.org/en-US/docs/Web/API/FocusEvent/FocusEvent)
        - [KeyboardEvent](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/KeyboardEvent)
        - [MouseEvent](https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/MouseEvent)
        - [PointerEvent](https://developer.mozilla.org/en-US/docs/Web/API/PointerEvent/PointerEvent)
        - [TouchEvent](https://developer.mozilla.org/en-US/docs/Web/API/TouchEvent/TouchEvent)
        - [WheelEvent](https://developer.mozilla.org/en-US/docs/Web/API/WheelEvent/WheelEvent)

        You can also specify `JSHandle` as the property value if you want live objects to be passed into the event:

        ```py
        data_transfer = page.evaluate_handle(\"new DataTransfer()\")
        locator.dispatch_event(\"#source\", \"dragstart\", {\"dataTransfer\": data_transfer})
        ```

        Parameters
        ----------
        type : str
            DOM event type: `"click"`, `"dragstart"`, etc.
        event_init : Union[Dict, None]
            Optional event-specific initialization properties.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.dispatch_event(
                type=type,
                eventInit=mapping.to_impl(event_init),
                timeout=to_milliseconds(timeout),
            )
        )

    def drag_to(
        self,
        target: "Locator",
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        source_position: typing.Optional[Position] = None,
        steps: typing.Optional[int] = None,
        target_position: typing.Optional[Position] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Locator.drag_to

        Drag the source element towards the target element and drop it.

        **Details**

        This method drags the locator to another target locator or target position. It will first move to the source
        element, perform a `mousedown`, then move to the target element or position and perform a `mouseup`.

        **Usage**

        ```py
        source = page.locator(\"#source\")
        target = page.locator(\"#target\")

        source.drag_to(target)
        # or specify exact positions relative to the top-left corners of the elements:
        source.drag_to(
          target,
          source_position={\"x\": 34, \"y\": 7},
          target_position={\"x\": 10, \"y\": 20}
        )
        ```

        Parameters
        ----------
        target : Locator
            Locator of the element to drag to.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        source_position : Union[{x: float, y: float}, None]
            Clicks on the source element at this point relative to the top-left corner of the element's padding box. If not
            specified, some visible point of the element is used.
        steps : Union[int, None]
            Defaults to 1. Sends `n` interpolated `mousemove` events to represent travel between the `mousedown` and `mouseup`
            of the drag. When set to 1, emits a single `mousemove` event at the destination location.
        target_position : Union[{x: float, y: float}, None]
            Drops on the target element at this point relative to the top-left corner of the element's padding box. If not
            specified, some visible point of the element is used.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.drag_to(
                target=target._impl_obj,
                force=force,
                noWaitAfter=no_wait_after,
                scroll=scroll,
                sourcePosition=source_position,
                steps=steps,
                targetPosition=target_position,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def drop(
        self,
        payload: DropPayload,
        *,
        position: typing.Optional[Position] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.drop

        Simulate an external drag-and-drop of files or clipboard-like data onto this locator.

        **Details**

        Dispatches the native `dragenter`, `dragover`, and `drop` events at the center of the target element with a
        synthetic [DataTransfer] carrying the provided files and/or data entries. Works cross-browser by constructing the
        [DataTransfer] in the page context.

        If the target element's `dragover` listener does not call `preventDefault()`, the target is considered to have
        rejected the drop: Playwright dispatches `dragleave` and this method throws.

        **Usage**

        Drop a file buffer onto an upload area:

        Drop plain text and a URL together:

        Parameters
        ----------
        payload : {files: Union[Sequence[Union[pathlib.Path, str]], Sequence[{name: str, mimeType: str, buffer: bytes}], pathlib.Path, str, {name: str, mimeType: str, buffer: bytes}, None], data: Union[Dict[str, str], None]}
            Data to drop onto the target. Provide `files` (file paths or in-memory buffers), `data` (a mime-type → string map
            for clipboard-like content such as `text/plain`, `text/html`, `text/uri-list`), or both.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.drop(
                payload=payload, position=position, timeout=to_milliseconds(timeout)
            )
        )

    def element_handle(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "ElementHandle":
        """Locator.element_handle

        Resolves given locator to the first matching DOM element. If there are no matching elements, waits for one. If
        multiple elements match the locator, throws.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        ElementHandle
        """

        return mapping.from_impl(
            self._sync(self._impl_obj.element_handle(timeout=to_milliseconds(timeout)))
        )

    def element_handles(self) -> typing.List["ElementHandle"]:
        """Locator.element_handles

        Resolves given locator to all matching DOM elements. If there are no matching elements, returns an empty list.

        Returns
        -------
        List[ElementHandle]
        """

        return mapping.from_impl_list(self._sync(self._impl_obj.element_handles()))

    def evaluate(
        self,
        expression: str,
        arg: typing.Optional[typing.Any] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Any:
        """Locator.evaluate

        Execute JavaScript code in the page, taking the matching element as an argument.

        **Details**

        Returns the return value of `expression`, called with the matching element as a first argument, and `arg` as a
        second argument.

        If `expression` returns a [Promise], this method will wait for the promise to resolve and return its value.

        If `expression` throws or rejects, this method throws.

        **Usage**

        Passing argument to `expression`:

        ```py
        result = page.get_by_testid(\"myId\").evaluate(\"(element, [x, y]) => element.textContent + ' ' + x * y\", [7, 8])
        print(result) # prints \"myId text 56\"
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.
        timeout : Union[float, None]
            Maximum time in milliseconds to wait for the locator before evaluating. Note that after locator is resolved,
            evaluation itself is not limited by the timeout. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.evaluate(
                    expression=expression,
                    arg=mapping.to_impl(arg),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def evaluate_all(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """Locator.evaluate_all

        Execute JavaScript code in the page, taking all matching elements as an argument.

        **Details**

        Returns the return value of `expression`, called with an array of all matching elements as a first argument, and
        `arg` as a second argument.

        If `expression` returns a [Promise], this method will wait for the promise to resolve and return its value.

        If `expression` throws or rejects, this method throws.

        **Usage**

        ```py
        locator = page.locator(\"div\")
        more_than_ten = locator.evaluate_all(\"(divs, min) => divs.length > min\", 10)
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.evaluate_all(
                    expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    def evaluate_handle(
        self,
        expression: str,
        arg: typing.Optional[typing.Any] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "JSHandle":
        """Locator.evaluate_handle

        Execute JavaScript code in the page, taking the matching element as an argument, and return a `JSHandle` with the
        result.

        **Details**

        Returns the return value of `expression` as a`JSHandle`, called with the matching element as a first argument, and
        `arg` as a second argument.

        The only difference between `locator.evaluate()` and `locator.evaluate_handle()` is that
        `locator.evaluate_handle()` returns `JSHandle`.

        If `expression` returns a [Promise], this method will wait for the promise to resolve and return its value.

        If `expression` throws or rejects, this method throws.

        See `page.evaluate_handle()` for more details.

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.
        timeout : Union[float, None]
            Maximum time in milliseconds to wait for the locator before evaluating. Note that after locator is resolved,
            evaluation itself is not limited by the timeout. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.

        Returns
        -------
        JSHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.evaluate_handle(
                    expression=expression,
                    arg=mapping.to_impl(arg),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def fill(
        self,
        value: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.fill

        Set a value to the input field.

        **Usage**

        ```py
        page.get_by_role(\"textbox\").fill(\"example value\")
        ```

        **Details**

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, focuses the element, fills it and triggers an
        `input` event after filling. Note that you can pass an empty string to clear the input field.

        If the target element is not an `<input>`, `<textarea>` or `[contenteditable]` element, this method throws an
        error. However, if the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be filled
        instead.

        To send fine-grained keyboard events, use `locator.press_sequentially()`.

        Parameters
        ----------
        value : str
            Value to set for the `<input>`, `<textarea>` or `[contenteditable]` element.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.fill(
                value=value,
                force=force,
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def filter(
        self,
        *,
        has: typing.Optional["Locator"] = None,
        has_not: typing.Optional["Locator"] = None,
        has_not_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        has_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        visible: typing.Optional[bool] = None,
    ) -> "Locator":
        """Locator.filter

        This method narrows existing locator according to the options, for example filters by text. It can be chained to
        filter multiple times.

        **Usage**

        ```py
        row_locator = page.locator(\"tr\")
        # ...
        row_locator.filter(has_text=\"text in column 1\").filter(
            has=page.get_by_role(\"button\", name=\"column 2 button\")
        ).screenshot()
        ```

        Parameters
        ----------
        has : Union[Locator, None]
            Narrows down the results of the method to those which contain elements matching this relative locator. For example,
            `article` that has `text=Playwright` matches `<article><div>Playwright</div></article>`.

            Inner locator **must be relative** to the outer locator and is queried starting with the outer locator match, not
            the document root. For example, you can find `content` that has `div` in
            `<article><content><div>Playwright</div></content></article>`. However, looking for `content` that has `article
            div` will fail, because the inner locator must be relative and should not use any elements outside the `content`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not : Union[Locator, None]
            Matches elements that do not contain an element that matches an inner locator. Inner locator is queried against the
            outer one. For example, `article` that does not have `div` matches `<article><span>Playwright</span></article>`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not_text : Union[Pattern[str], str, None]
            Matches elements that do not contain specified text somewhere inside, possibly in a child or a descendant element.
            When passed a [string], matching is case-insensitive and searches for a substring.
        has_text : Union[Pattern[str], str, None]
            Matches elements containing specified text somewhere inside, possibly in a child or a descendant element. When
            passed a [string], matching is case-insensitive and searches for a substring. For example, `"Playwright"` matches
            `<article><div>Playwright</div></article>`.
        visible : Union[bool, None]
            Only matches visible or invisible elements. Prefer the `locator.visible` shortcut when matching only visible
            elements.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.filter(
                has=has._impl_obj if has else None,
                hasNot=has_not._impl_obj if has_not else None,
                hasNotText=has_not_text,
                hasText=has_text,
                visible=visible,
            )
        )

    @property
    def first(self) -> "Locator":
        """Locator.first

        Returns locator to the first matching element.

        Returns
        -------
        Locator
        """
        return mapping.from_impl(self._impl_obj.first)

    def focus(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.focus

        Calls [focus](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/focus) on the matching element.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(self._impl_obj.focus(timeout=to_milliseconds(timeout)))

    def frame_locator(self, selector: str) -> "FrameLocator":
        """Locator.frame_locator

        When working with iframes, you can create a frame locator that will enter the iframe and allow locating elements in
        that iframe:

        **Usage**

        ```py
        locator = page.frame_locator(\"iframe\").get_by_text(\"Submit\")
        locator.click()
        ```

        Parameters
        ----------
        selector : str
            A selector to use when resolving DOM element.

        Returns
        -------
        FrameLocator
        """

        return mapping.from_impl(self._impl_obj.frame_locator(selector=selector))

    def get_attribute(
        self,
        name: str,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional[str]:
        """Locator.get_attribute

        Returns the matching element's attribute value.

        **NOTE** If you need to assert an element's attribute, prefer `locator_assertions.to_have_attribute()` to avoid
        flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        Parameters
        ----------
        name : str
            Attribute name to get the value for.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.get_attribute(
                    name=name, timeout=to_milliseconds(timeout)
                )
            )
        )

    def get_by_alt_text(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Locator.get_by_alt_text

        Allows locating elements by their alt text.

        **Usage**

        For example, this method will find the image by alt text \"Playwright logo\":

        ```html
        <img alt='Playwright logo'>
        ```

        ```py
        page.get_by_alt_text(\"Playwright logo\").click()
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_alt_text(text=text, exact=exact))

    def get_by_label(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Locator.get_by_label

        Allows locating input elements by the text of the associated `<label>` or `aria-labelledby` element, or by the
        `aria-label` attribute.

        **Usage**

        For example, this method will find inputs by label \"Username\" and \"Password\" in the following DOM:

        ```html
        <input aria-label=\"Username\">
        <label for=\"password-input\">Password:</label>
        <input id=\"password-input\">
        ```

        ```py
        page.get_by_label(\"Username\").fill(\"john\")
        page.get_by_label(\"Password\").fill(\"secret\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_label(text=text, exact=exact))

    def get_by_placeholder(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Locator.get_by_placeholder

        Allows locating input elements by the placeholder text.

        **Usage**

        For example, consider the following DOM structure.

        ```html
        <input type=\"email\" placeholder=\"name@example.com\" />
        ```

        You can fill the input after locating it by the placeholder text:

        ```py
        page.get_by_placeholder(\"name@example.com\").fill(\"playwright@microsoft.com\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.get_by_placeholder(text=text, exact=exact)
        )

    def get_by_role(
        self,
        role: Literal[
            "alert",
            "alertdialog",
            "application",
            "article",
            "banner",
            "blockquote",
            "button",
            "caption",
            "cell",
            "checkbox",
            "code",
            "columnheader",
            "combobox",
            "complementary",
            "contentinfo",
            "definition",
            "deletion",
            "dialog",
            "directory",
            "document",
            "emphasis",
            "feed",
            "figure",
            "form",
            "generic",
            "grid",
            "gridcell",
            "group",
            "heading",
            "img",
            "insertion",
            "link",
            "list",
            "listbox",
            "listitem",
            "log",
            "main",
            "marquee",
            "math",
            "menu",
            "menubar",
            "menuitem",
            "menuitemcheckbox",
            "menuitemradio",
            "meter",
            "navigation",
            "none",
            "note",
            "option",
            "paragraph",
            "presentation",
            "progressbar",
            "radio",
            "radiogroup",
            "region",
            "row",
            "rowgroup",
            "rowheader",
            "scrollbar",
            "search",
            "searchbox",
            "separator",
            "slider",
            "spinbutton",
            "status",
            "strong",
            "subscript",
            "superscript",
            "switch",
            "tab",
            "table",
            "tablist",
            "tabpanel",
            "term",
            "textbox",
            "time",
            "timer",
            "toolbar",
            "tooltip",
            "tree",
            "treegrid",
            "treeitem",
        ],
        *,
        checked: typing.Optional[bool] = None,
        description: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        disabled: typing.Optional[bool] = None,
        exact: typing.Optional[bool] = None,
        expanded: typing.Optional[bool] = None,
        include_hidden: typing.Optional[bool] = None,
        level: typing.Optional[int] = None,
        name: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        pressed: typing.Optional[bool] = None,
        selected: typing.Optional[bool] = None,
    ) -> "Locator":
        """Locator.get_by_role

        Allows locating elements by their [ARIA role](https://www.w3.org/TR/wai-aria-1.2/#roles),
        [ARIA attributes](https://www.w3.org/TR/wai-aria-1.2/#aria-attributes) and
        [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).

        **Usage**

        Consider the following DOM structure.

        ```html
        <h3>Sign up</h3>
        <label>
          <input type=\"checkbox\" /> Subscribe
        </label>
        <br/>
        <button>Submit</button>
        ```

        You can locate each element by its implicit role:

        ```py
        expect(page.get_by_role(\"heading\", name=\"Sign up\")).to_be_visible()

        page.get_by_role(\"checkbox\", name=\"Subscribe\").check()

        page.get_by_role(\"button\", name=re.compile(\"submit\", re.IGNORECASE)).click()
        ```

        **Details**

        Role selector **does not replace** accessibility audits and conformance tests, but rather gives early feedback
        about the ARIA guidelines.

        Many html elements have an implicitly [defined role](https://w3c.github.io/html-aam/#html-element-role-mappings)
        that is recognized by the role selector. You can find all the
        [supported roles here](https://www.w3.org/TR/wai-aria-1.2/#role_definitions). ARIA guidelines **do not recommend**
        duplicating implicit roles and attributes by setting `role` and/or `aria-*` attributes to default values.

        Parameters
        ----------
        role : Union["alert", "alertdialog", "application", "article", "banner", "blockquote", "button", "caption", "cell", "checkbox", "code", "columnheader", "combobox", "complementary", "contentinfo", "definition", "deletion", "dialog", "directory", "document", "emphasis", "feed", "figure", "form", "generic", "grid", "gridcell", "group", "heading", "img", "insertion", "link", "list", "listbox", "listitem", "log", "main", "marquee", "math", "menu", "menubar", "menuitem", "menuitemcheckbox", "menuitemradio", "meter", "navigation", "none", "note", "option", "paragraph", "presentation", "progressbar", "radio", "radiogroup", "region", "row", "rowgroup", "rowheader", "scrollbar", "search", "searchbox", "separator", "slider", "spinbutton", "status", "strong", "subscript", "superscript", "switch", "tab", "table", "tablist", "tabpanel", "term", "textbox", "time", "timer", "toolbar", "tooltip", "tree", "treegrid", "treeitem"]
            Required aria role.
        checked : Union[bool, None]
            An attribute that is usually set by `aria-checked` or native `<input type=checkbox>` controls.

            Learn more about [`aria-checked`](https://www.w3.org/TR/wai-aria-1.2/#aria-checked).
        description : Union[Pattern[str], str, None]
            Option to match the [accessible description](https://w3c.github.io/accname/#dfn-accessible-description). By
            default, matching is case-insensitive and searches for a substring, use `exact` to control this behavior.

            Learn more about [accessible description](https://w3c.github.io/accname/#dfn-accessible-description).
        disabled : Union[bool, None]
            An attribute that is usually set by `aria-disabled` or `disabled`.

            **NOTE** Unlike most other attributes, `disabled` is inherited through the DOM hierarchy. Learn more about
            [`aria-disabled`](https://www.w3.org/TR/wai-aria-1.2/#aria-disabled).

        exact : Union[bool, None]
            Whether `name` and `description` are matched exactly: case-sensitive and whole-string. Defaults to false. Ignored
            when the value is a regular expression. Note that exact match still trims whitespace.
        expanded : Union[bool, None]
            An attribute that is usually set by `aria-expanded`.

            Learn more about [`aria-expanded`](https://www.w3.org/TR/wai-aria-1.2/#aria-expanded).
        include_hidden : Union[bool, None]
            Option that controls whether hidden elements are matched. By default, only non-hidden elements, as
            [defined by ARIA](https://www.w3.org/TR/wai-aria-1.2/#tree_exclusion), are matched by role selector.

            Learn more about [`aria-hidden`](https://www.w3.org/TR/wai-aria-1.2/#aria-hidden).
        level : Union[int, None]
            A number attribute that is usually present for roles `heading`, `listitem`, `row`, `treeitem`, with default values
            for `<h1>-<h6>` elements.

            Learn more about [`aria-level`](https://www.w3.org/TR/wai-aria-1.2/#aria-level).
        name : Union[Pattern[str], str, None]
            Option to match the [accessible name](https://w3c.github.io/accname/#dfn-accessible-name). By default, matching is
            case-insensitive and searches for a substring, use `exact` to control this behavior.

            Learn more about [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).
        pressed : Union[bool, None]
            An attribute that is usually set by `aria-pressed`.

            Learn more about [`aria-pressed`](https://www.w3.org/TR/wai-aria-1.2/#aria-pressed).
        selected : Union[bool, None]
            An attribute that is usually set by `aria-selected`.

            Learn more about [`aria-selected`](https://www.w3.org/TR/wai-aria-1.2/#aria-selected).

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.get_by_role(
                role=role,
                checked=checked,
                description=description,
                disabled=disabled,
                exact=exact,
                expanded=expanded,
                includeHidden=include_hidden,
                level=level,
                name=name,
                pressed=pressed,
                selected=selected,
            )
        )

    def get_by_test_id(
        self, test_id: typing.Union[str, typing.Pattern[str]]
    ) -> "Locator":
        """Locator.get_by_test_id

        Locate element by the test id.

        **Usage**

        Consider the following DOM structure.

        ```html
        <button data-testid=\"directions\">Itinéraire</button>
        ```

        You can locate the element by its test id:

        ```py
        page.get_by_test_id(\"directions\").click()
        ```

        **Details**

        By default, the `data-testid` attribute is used as a test id. Use `selectors.set_test_id_attribute()` to configure
        a different test id attribute if necessary.

        Parameters
        ----------
        test_id : Union[Pattern[str], str]
            Id to locate the element by.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_test_id(testId=test_id))

    def get_by_text(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Locator.get_by_text

        Allows locating elements that contain given text.

        See also `locator.filter()` that allows to match by another criteria, like an accessible role, and then filter by
        the text content.

        **Usage**

        Consider the following DOM structure:

        ```html
        <div>Hello <span>world</span></div>
        <div>Hello</div>
        ```

        You can locate by text substring, exact string, or a regular expression:

        ```py
        # Matches <span>
        page.get_by_text(\"world\")

        # Matches first <div>
        page.get_by_text(\"Hello world\")

        # Matches second <div>
        page.get_by_text(\"Hello\", exact=True)

        # Matches both <div>s
        page.get_by_text(re.compile(\"Hello\"))

        # Matches second <div>
        page.get_by_text(re.compile(\"^hello$\", re.IGNORECASE))
        ```

        **Details**

        Matching by text always normalizes whitespace, even with exact match. For example, it turns multiple spaces into
        one, turns line breaks into spaces and ignores leading and trailing whitespace.

        Input elements of the type `button` and `submit` are matched by their `value` instead of the text content. For
        example, locating by text `\"Log in\"` matches `<input type=button value=\"Log in\">`.

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_text(text=text, exact=exact))

    def get_by_title(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Locator.get_by_title

        Allows locating elements by their title attribute.

        **Usage**

        Consider the following DOM structure.

        ```html
        <span title='Issues count'>25 issues</span>
        ```

        You can check the issues count after locating it by the title text:

        ```py
        expect(page.get_by_title(\"Issues count\")).to_have_text(\"25 issues\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_title(text=text, exact=exact))

    def hide_highlight(self) -> None:
        """Locator.hide_highlight

        Hides the element highlight previously added by `locator.highlight()`.
        """

        self._sync(self._impl_obj.hide_highlight())

    def highlight(self, *, style: typing.Optional[str] = None) -> None:
        """Locator.highlight

        Highlight the corresponding element(s) on the screen. Useful for debugging, don't commit the code that uses
        `locator.highlight()`.

        Parameters
        ----------
        style : Union[str, None]
            Additional inline CSS applied to the highlight overlay, e.g. `"outline: 2px dashed red"`.
        """

        self._sync(self._impl_obj.highlight(style=style))

    def hover(
        self,
        *,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Locator.hover

        Hover over the matching element.

        **Usage**

        ```py
        page.get_by_role(\"link\").hover()
        ```

        **Details**

        This method hovers over the element by performing the following steps:
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to hover over the center of the element, or the specified `position`.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.hover(
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def inner_html(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Locator.inner_html

        Returns the [`element.innerHTML`](https://developer.mozilla.org/en-US/docs/Web/API/Element/innerHTML).

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.inner_html(timeout=to_milliseconds(timeout)))
        )

    def inner_text(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Locator.inner_text

        Returns the [`element.innerText`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/innerText).

        **NOTE** If you need to assert text on the page, prefer `locator_assertions.to_have_text()` with `use_inner_text`
        option to avoid flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.inner_text(timeout=to_milliseconds(timeout)))
        )

    def input_value(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Locator.input_value

        Returns the value for the matching `<input>` or `<textarea>` or `<select>` element.

        **NOTE** If you need to assert input value, prefer `locator_assertions.to_have_value()` to avoid flakiness. See
        [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        value = page.get_by_role(\"textbox\").input_value()
        ```

        **Details**

        Throws elements that are not an input, textarea or a select. However, if the element is inside the `<label>`
        element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), returns the value of the
        control.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.input_value(timeout=to_milliseconds(timeout)))
        )

    def is_checked(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Locator.is_checked

        Returns whether the element is checked. Throws if the element is not a checkbox or radio input.

        **NOTE** If you need to assert that checkbox is checked, prefer `locator_assertions.to_be_checked()` to avoid
        flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        checked = page.get_by_role(\"checkbox\").is_checked()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.is_checked(timeout=to_milliseconds(timeout)))
        )

    def is_disabled(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Locator.is_disabled

        Returns whether the element is disabled, the opposite of [enabled](https://playwright.dev/python/docs/actionability#enabled).

        **NOTE** If you need to assert that an element is disabled, prefer `locator_assertions.to_be_disabled()` to avoid
        flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        disabled = page.get_by_role(\"button\").is_disabled()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.is_disabled(timeout=to_milliseconds(timeout)))
        )

    def is_editable(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Locator.is_editable

        Returns whether the element is [editable](https://playwright.dev/python/docs/actionability#editable). If the target element is not an `<input>`,
        `<textarea>`, `<select>`, `[contenteditable]` and does not have a role allowing `[aria-readonly]`, this method
        throws an error.

        **NOTE** If you need to assert that an element is editable, prefer `locator_assertions.to_be_editable()` to avoid
        flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        editable = page.get_by_role(\"textbox\").is_editable()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.is_editable(timeout=to_milliseconds(timeout)))
        )

    def is_enabled(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Locator.is_enabled

        Returns whether the element is [enabled](https://playwright.dev/python/docs/actionability#enabled).

        **NOTE** If you need to assert that an element is enabled, prefer `locator_assertions.to_be_enabled()` to avoid
        flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        enabled = page.get_by_role(\"button\").is_enabled()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.is_enabled(timeout=to_milliseconds(timeout)))
        )

    def is_hidden(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Locator.is_hidden

        Returns whether the element is hidden, the opposite of [visible](https://playwright.dev/python/docs/actionability#visible).

        **NOTE** If you need to assert that element is hidden, prefer `locator_assertions.to_be_hidden()` to avoid
        flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        hidden = page.get_by_role(\"button\").is_hidden()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Deprecated: This option is ignored. `locator.is_hidden()` does not wait for the element to become hidden and returns immediately.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.is_hidden(timeout=to_milliseconds(timeout)))
        )

    def is_visible(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Locator.is_visible

        Returns whether the element is [visible](https://playwright.dev/python/docs/actionability#visible).

        **NOTE** If you need to assert that element is visible, prefer `locator_assertions.to_be_visible()` to avoid
        flakiness. See [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        **Usage**

        ```py
        visible = page.get_by_role(\"button\").is_visible()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Deprecated: This option is ignored. `locator.is_visible()` does not wait for the element to become visible and returns immediately.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.is_visible(timeout=to_milliseconds(timeout)))
        )

    @property
    def last(self) -> "Locator":
        """Locator.last

        Returns locator to the last matching element.

        **Usage**

        ```py
        banana = page.get_by_role(\"listitem\").last
        ```

        Returns
        -------
        Locator
        """
        return mapping.from_impl(self._impl_obj.last)

    def locator(
        self,
        selector_or_locator: typing.Union[str, "Locator"],
        *,
        has: typing.Optional["Locator"] = None,
        has_not: typing.Optional["Locator"] = None,
        has_not_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        has_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> "Locator":
        """Locator.locator

        The method finds an element matching the specified selector in the locator's subtree. It also accepts filter
        options, similar to `locator.filter()` method.

        [Learn more about locators](https://playwright.dev/python/docs/locators).

        Parameters
        ----------
        selector_or_locator : Union[Locator, str]
            A selector or locator to use when resolving DOM element.
        has : Union[Locator, None]
            Narrows down the results of the method to those which contain elements matching this relative locator. For example,
            `article` that has `text=Playwright` matches `<article><div>Playwright</div></article>`.

            Inner locator **must be relative** to the outer locator and is queried starting with the outer locator match, not
            the document root. For example, you can find `content` that has `div` in
            `<article><content><div>Playwright</div></content></article>`. However, looking for `content` that has `article
            div` will fail, because the inner locator must be relative and should not use any elements outside the `content`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not : Union[Locator, None]
            Matches elements that do not contain an element that matches an inner locator. Inner locator is queried against the
            outer one. For example, `article` that does not have `div` matches `<article><span>Playwright</span></article>`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not_text : Union[Pattern[str], str, None]
            Matches elements that do not contain specified text somewhere inside, possibly in a child or a descendant element.
            When passed a [string], matching is case-insensitive and searches for a substring.
        has_text : Union[Pattern[str], str, None]
            Matches elements containing specified text somewhere inside, possibly in a child or a descendant element. When
            passed a [string], matching is case-insensitive and searches for a substring. For example, `"Playwright"` matches
            `<article><div>Playwright</div></article>`.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.locator(
                selectorOrLocator=mapping.to_impl(selector_or_locator),
                has=has._impl_obj if has else None,
                hasNot=has_not._impl_obj if has_not else None,
                hasNotText=has_not_text,
                hasText=has_text,
            )
        )

    def normalize(self) -> "Locator":
        """Locator.normalize

        Returns a new locator that uses best practices for referencing the matched element, prioritizing test ids, aria
        roles, and other user-facing attributes over CSS selectors. This is useful for converting implementation-detail
        selectors into more resilient, human-readable locators.

        **Usage**

        An agent can pick an element by its ref from an `page.aria_snapshot()` taken in the `\"ai\"` mode. Refs only work for
        the latest snapshot. Normalize the ref locator and convert it to a string to get resilient locator code in your
        language, the same way `codegen` does.

        Consider the following aria snapshot.

        You can turn the ref into locator code:

        ```py
        normalized = page.get_by_ref(\"e2\").normalize()
        print(str(normalized))
        # get_by_role(\"button\", name=\"Submit\")
        ```

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._sync(self._impl_obj.normalize()))

    def nth(self, index: int) -> "Locator":
        """Locator.nth

        Returns locator to the n-th matching element. It's zero based, `nth(0)` selects the first element.

        **Usage**

        ```py
        banana = page.get_by_role(\"listitem\").nth(2)
        ```

        Parameters
        ----------
        index : int

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.nth(index=index))

    def or_(self, locator: "Locator") -> "Locator":
        """Locator.or_

        Creates a locator matching all elements that match one or both of the two locators.

        Note that when both locators match something, the resulting locator will have multiple matches, potentially causing
        a [locator strictness](https://playwright.dev/python/docs/locators#strictness) violation.

        **Usage**

        Consider a scenario where you'd like to click on a \"New email\" button, but sometimes a security settings dialog
        shows up instead. In this case, you can wait for either a \"New email\" button, or a dialog and act accordingly.

        **NOTE** If both \"New email\" button and security dialog appear on screen, the \"or\" locator will match both of them,
        possibly throwing the [\"strict mode violation\" error](https://playwright.dev/python/docs/locators#strictness). In this case, you can use
        `locator.first` to only match one of them.

        ```py
        new_email = page.get_by_role(\"button\", name=\"New\")
        dialog = page.get_by_text(\"Confirm security settings\")
        expect(new_email.or_(dialog).first).to_be_visible()
        if (dialog.is_visible()):
          page.get_by_role(\"button\", name=\"Dismiss\").click()
        new_email.click()
        ```

        Parameters
        ----------
        locator : Locator
            Alternative locator to match.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.or_(locator=locator._impl_obj))

    @property
    def page(self) -> "Page":
        """Locator.page

        A page this locator belongs to.

        Returns
        -------
        Page
        """
        return mapping.from_impl(self._impl_obj.page)

    def press(
        self,
        key: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.press

        Focuses the matching element and presses a combination of the keys.

        **Usage**

        ```py
        page.get_by_role(\"textbox\").press(\"Backspace\")
        ```

        **Details**

        Focuses the element, and then uses `keyboard.down()` and `keyboard.up()`.

        `key` can specify the intended
        [keyboardEvent.key](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key) value or a single character
        to generate the text for. A superset of the `key` values can be found
        [here](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values). Examples of the keys are:

        `F1` - `F12`, `Digit0`- `Digit9`, `KeyA`- `KeyZ`, `Backquote`, `Minus`, `Equal`, `Backslash`, `Backspace`, `Tab`,
        `Delete`, `Escape`, `ArrowDown`, `End`, `Enter`, `Home`, `Insert`, `PageDown`, `PageUp`, `ArrowRight`, `ArrowUp`,
        etc.

        Following modification shortcuts are also supported: `Shift`, `Control`, `Alt`, `Meta`, `ShiftLeft`,
        `ControlOrMeta`. `ControlOrMeta` resolves to `Control` on Windows and Linux and to `Meta` on macOS.

        Holding down `Shift` will type the text that corresponds to the `key` in the upper case.

        If `key` is a single character, it is case-sensitive, so the values `a` and `A` will generate different respective
        texts.

        Shortcuts such as `key: \"Control+o\"`, `key: \"Control++` or `key: \"Control+Shift+T\"` are supported as well. When
        specified with the modifier, modifier is pressed and being held while the subsequent key is being pressed.

        Parameters
        ----------
        key : str
            Name of the key to press or a character to generate, such as `ArrowLeft` or `a`.
        delay : Union[float, None]
            Time to wait between `keydown` and `keyup` in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            Actions that initiate navigations are waiting for these navigations to happen and for pages to start loading. You
            can opt out of waiting via setting this flag. You would only need this option in the exceptional cases such as
            navigating to inaccessible pages. Defaults to `false`.
            Deprecated: This option will default to `true` in the future.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.press(
                key=key,
                delay=delay,
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def press_sequentially(
        self,
        text: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.press_sequentially

        **NOTE** In most cases, you should use `locator.fill()` instead. You only need to press keys one by one if there is
        special keyboard handling on the page.

        Focuses the element, and then sends a `keydown`, `keypress`/`input`, and `keyup` event for each character in the
        text.

        To press a special key, like `Control` or `ArrowDown`, use `locator.press()`.

        **Usage**

        ```py
        locator.press_sequentially(\"hello\") # types instantly
        locator.press_sequentially(\"world\", delay=100) # types slower, like a user
        ```

        An example of typing into a text field and then submitting the form:

        ```py
        locator = page.get_by_label(\"Password\")
        locator.press_sequentially(\"my password\")
        locator.press(\"Enter\")
        ```

        Parameters
        ----------
        text : str
            String of characters to sequentially press into a focused element.
        delay : Union[float, None]
            Time to wait between key presses in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.press_sequentially(
                text=text,
                delay=delay,
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def screenshot(
        self,
        *,
        animations: typing.Optional[Literal["allow", "disabled"]] = None,
        caret: typing.Optional[Literal["hide", "initial"]] = None,
        mask: typing.Optional[typing.Sequence["Locator"]] = None,
        mask_color: typing.Optional[str] = None,
        omit_background: typing.Optional[bool] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        quality: typing.Optional[int] = None,
        scale: typing.Optional[Literal["css", "device"]] = None,
        style: typing.Optional[str] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        type: typing.Optional[Literal["jpeg", "png", "webp"]] = None,
    ) -> bytes:
        """Locator.screenshot

        Take a screenshot of the element matching the locator.

        **Usage**

        ```py
        page.get_by_role(\"link\").screenshot()
        ```

        Disable animations and save screenshot to a file:

        ```py
        page.get_by_role(\"link\").screenshot(animations=\"disabled\", path=\"link.png\")
        ```

        **Details**

        This method captures a screenshot of the page, clipped to the size and position of a particular element matching
        the locator. If the element is covered by other elements, it will not be actually visible on the screenshot. If the
        element is a scrollable container, only the currently scrolled content will be visible on the screenshot.

        This method waits for the [actionability](https://playwright.dev/python/docs/actionability) checks, then scrolls element into view before taking
        a screenshot. If the element is detached from DOM, the method throws an error.

        Returns the buffer with the captured screenshot.

        Parameters
        ----------
        animations : Union["allow", "disabled", None]
            When set to `"disabled"`, stops CSS animations, CSS transitions and Web Animations. Animations get different
            treatment depending on their duration:
            - finite animations are fast-forwarded to completion, so they'll fire `transitionend` event.
            - infinite animations are canceled to initial state, and then played over after the screenshot.

            Defaults to `"allow"` that leaves animations untouched.
        caret : Union["hide", "initial", None]
            When set to `"hide"`, screenshot will hide text caret. When set to `"initial"`, text caret behavior will not be
            changed.  Defaults to `"hide"`.
        mask : Union[Sequence[Locator], None]
            Specify locators that should be masked when the screenshot is taken. Masked elements will be overlaid with a pink
            box `#FF00FF` (customized by `mask_color`) that completely covers its bounding box. The mask is also applied to
            invisible elements, see [Matching only visible elements](../locators.md#matching-only-visible-elements) to disable
            that.
        mask_color : Union[str, None]
            Specify the color of the overlay box for masked elements, in
            [CSS color format](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value). Default color is pink `#FF00FF`.
        omit_background : Union[bool, None]
            Hides default white background and allows capturing screenshots with transparency. Not applicable to `jpeg` images.
            Defaults to `false`.
        path : Union[pathlib.Path, str, None]
            The file path to save the image to. The screenshot type will be inferred from file extension. If `path` is a
            relative path, then it is resolved relative to the current working directory. If no path is provided, the image
            won't be saved to the disk.
        quality : Union[int, None]
            The quality of the image, between 0-100. Not applicable to `png` images. For `jpeg` the default is `80`. For
            `webp`, a quality of `100` (the default) produces a lossless image, while lower values use lossy compression.
        scale : Union["css", "device", None]
            When set to `"css"`, screenshot will have a single pixel per each css pixel on the page. For high-dpi devices, this
            will keep screenshots small. Using `"device"` option will produce a single pixel per each device pixel, so
            screenshots of high-dpi devices will be twice as large or even larger.

            Defaults to `"device"`.
        style : Union[str, None]
            Text of the stylesheet to apply while making the screenshot. This is where you can hide dynamic elements, make
            elements invisible or change their properties to help you creating repeatable screenshots. This stylesheet pierces
            the Shadow DOM and applies to the inner frames.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        type : Union["jpeg", "png", "webp", None]
            Specify screenshot type, defaults to `png`.

        Returns
        -------
        bytes
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.screenshot(
                    animations=animations,
                    caret=caret,
                    mask=mapping.to_impl(mask),
                    maskColor=mask_color,
                    omitBackground=omit_background,
                    path=path,
                    quality=quality,
                    scale=scale,
                    style=style,
                    timeout=to_milliseconds(timeout),
                    type=type,
                )
            )
        )

    def scroll_into_view_if_needed(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.scroll_into_view_if_needed

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, then tries to scroll element into view, unless
        it is completely visible as defined by
        [IntersectionObserver](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API)'s `ratio`.

        See [scrolling](https://playwright.dev/python/docs/input#scrolling) for alternative ways to scroll.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.scroll_into_view_if_needed(timeout=to_milliseconds(timeout))
        )

    def select_option(
        self,
        value: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None,
        *,
        element: typing.Optional[
            typing.Union["ElementHandle", typing.Sequence["ElementHandle"]]
        ] = None,
        force: typing.Optional[bool] = None,
        index: typing.Optional[typing.Union[int, typing.Sequence[int]]] = None,
        label: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.List[str]:
        """Locator.select_option

        Selects option or options in `<select>`.

        **Details**

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, waits until all specified options are present in
        the `<select>` element and selects these options.

        If the target element is not a `<select>` element, this method throws an error. However, if the element is inside
        the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be used
        instead.

        Returns the array of option values that have been successfully selected.

        Triggers a `change` and `input` event once all the provided options have been selected.

        **Usage**

        ```html
        <select multiple>
          <option value=\"red\">Red</option>
          <option value=\"green\">Green</option>
          <option value=\"blue\">Blue</option>
        </select>
        ```

        ```py
        # single selection matching the value or label
        element.select_option(\"blue\")
        # single selection matching the label
        element.select_option(label=\"blue\")
        # multiple selection for blue, red and second option
        element.select_option(value=[\"red\", \"green\", \"blue\"])
        ```

        Parameters
        ----------
        value : Union[Sequence[str], str, None]
            Options to select by value. If the `<select>` has the `multiple` attribute, all given options are selected,
            otherwise only the first option matching one of the passed options is selected. Optional.
        element : Union[ElementHandle, Sequence[ElementHandle], None]
            Option elements to select. Optional.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        index : Union[Sequence[int], int, None]
            Options to select by index. Optional.
        label : Union[Sequence[str], str, None]
            Options to select by label. If the `<select>` has the `multiple` attribute, all given options are selected,
            otherwise only the first option matching one of the passed options is selected. Optional.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        List[str]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.select_option(
                    value=mapping.to_impl(value),
                    element=mapping.to_impl(element),
                    force=force,
                    index=mapping.to_impl(index),
                    label=mapping.to_impl(label),
                    noWaitAfter=no_wait_after,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def select_text(
        self,
        *,
        force: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.select_text

        This method waits for [actionability](https://playwright.dev/python/docs/actionability) checks, then focuses the element and selects all its
        text content.

        If the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), focuses and selects text in
        the control instead.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.select_text(force=force, timeout=to_milliseconds(timeout))
        )

    def set_checked(
        self,
        checked: bool,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Locator.set_checked

        Set the state of a checkbox or a radio element.

        **Usage**

        ```py
        page.get_by_role(\"checkbox\").set_checked(True)
        ```

        **Details**

        This method checks or unchecks an element by performing the following steps:
        1. Ensure that matched element is a checkbox or a radio input. If not, this method throws.
        1. If the element already has the right checked state, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now checked or unchecked. If not, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        checked : bool
            Whether to check or uncheck the checkbox.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.set_checked(
                checked=checked,
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def set_input_files(
        self,
        files: typing.Union[
            str,
            pathlib.Path,
            typing.Sequence[typing.Union[str, pathlib.Path]],
            FilePayload,
            typing.Sequence[FilePayload],
        ],
        *,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.set_input_files

        Upload file or multiple files into `<input type=file>`. For inputs with a `[webkitdirectory]` attribute, only a
        single directory path is supported.

        **Usage**

        ```py
        # Select one file
        page.get_by_label(\"Upload file\").set_input_files('myfile.pdf')

        # Select multiple files
        page.get_by_label(\"Upload files\").set_input_files(['file1.txt', 'file2.txt'])

        # Select a directory
        page.get_by_label(\"Upload directory\").set_input_files('mydir')

        # Remove all the selected files
        page.get_by_label(\"Upload file\").set_input_files([])

        # Upload buffer from memory
        page.get_by_label(\"Upload file\").set_input_files(
            files=[
                {\"name\": \"test.txt\", \"mimeType\": \"text/plain\", \"buffer\": b\"this is a test\"}
            ],
        )
        ```

        **Details**

        Sets the value of the file input to these file paths or files. If some of the `filePaths` are relative paths, then
        they are resolved relative to the current working directory. For empty array, clears the selected files.

        This method expects `Locator` to point to an
        [input element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input). However, if the element is inside
        the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), targets the control instead.

        Parameters
        ----------
        files : Union[Sequence[Union[pathlib.Path, str]], Sequence[{name: str, mimeType: str, buffer: bytes}], pathlib.Path, str, {name: str, mimeType: str, buffer: bytes}]
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.set_input_files(
                files=mapping.to_impl(files),
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def tap(
        self,
        *,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Locator.tap

        Perform a tap gesture on the element matching the locator. For examples of emulating other gestures by manually
        dispatching touch events, see the [emulating legacy touch events](https://playwright.dev/python/docs/touch-events) page.

        **Details**

        This method taps the element by performing the following steps:
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.touchscreen` to tap the center of the element, or the specified `position`.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **NOTE** `element.tap()` requires that the `hasTouch` option of the browser context be set to true.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.tap(
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def text_content(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional[str]:
        """Locator.text_content

        Returns the [`node.textContent`](https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent).

        **NOTE** If you need to assert text on the page, prefer `locator_assertions.to_have_text()` to avoid flakiness. See
        [assertions guide](https://playwright.dev/python/docs/test-assertions) for more details.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.text_content(timeout=to_milliseconds(timeout)))
        )

    def type(
        self,
        text: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.type

        Focuses the element, and then sends a `keydown`, `keypress`/`input`, and `keyup` event for each character in the
        text.

        To press a special key, like `Control` or `ArrowDown`, use `locator.press()`.

        **Usage**

        Parameters
        ----------
        text : str
            A text to type into a focused element.
        delay : Union[float, None]
            Time to wait between key presses in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.type(
                text=text,
                delay=delay,
                noWaitAfter=no_wait_after,
                timeout=to_milliseconds(timeout),
            )
        )

    def uncheck(
        self,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Locator.uncheck

        Ensure that checkbox or radio element is unchecked.

        **Usage**

        ```py
        page.get_by_role(\"checkbox\").uncheck()
        ```

        **Details**

        This method unchecks the element by performing the following steps:
        1. Ensure that element is a checkbox or a radio input. If not, this method throws. If the element is already
           unchecked, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the element, unless `force` option is set.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now unchecked. If not, this method throws.

        If the element is detached from the DOM at any moment during the action, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.uncheck(
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    @property
    def visible(self) -> "Locator":
        """Locator.visible

        Returns a locator that matches only [visible](https://playwright.dev/python/docs/actionability#visible) elements, ignoring the invisible ones.
        This is the recommended way to distinguish elements by visibility, as opposed to the `:visible` CSS pseudo-class.

        Note that visibility is checked every time the locator is used, and not at the moment of the `locator.visible`
        call.

        **Usage**

        Consider a page with two buttons, the first invisible and the second visible.

        ```html
        <button style='display: none'>Invisible</button>
        <button>Visible</button>
        ```

        This will only find the second button, because it is visible, and then click it.

        ```py
        page.locator(\"button\").visible.click()
        ```

        To match invisible elements instead, use `locator.filter()` with the `visible` option set to `false`.

        Returns
        -------
        Locator
        """
        return mapping.from_impl(self._impl_obj.visible)

    def wait_for(
        self,
        *,
        state: typing.Optional[
            Literal["attached", "detached", "hidden", "visible"]
        ] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.wait_for

        Returns when element specified by locator satisfies the `state` option.

        If target element already satisfies the condition, the method returns immediately. Otherwise, waits for up to
        `timeout` milliseconds until the condition is met.

        **Usage**

        ```py
        order_sent = page.locator(\"#order-sent\")
        order_sent.wait_for()
        ```

        Parameters
        ----------
        state : Union["attached", "detached", "hidden", "visible", None]
            Defaults to `'visible'`. Can be either:
            - `'attached'` - wait for element to be present in DOM.
            - `'detached'` - wait for element to not be present in DOM.
            - `'visible'` - wait for element to have non-empty bounding box and no `visibility:hidden`. Note that element
              without any content or with `display:none` has an empty bounding box and is not considered visible.
            - `'hidden'` - wait for element to be either detached from DOM, or have an empty bounding box or
              `visibility:hidden`. This is opposite to the `'visible'` option.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.wait_for(state=state, timeout=to_milliseconds(timeout))
        )

    def wait_for_function(
        self,
        expression: str,
        *,
        arg: typing.Optional[typing.Any] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Locator.wait_for_function

        Returns when `expression` returns a truthy value, called with the matching element as a first argument, and `arg`
        as a second argument.

        This is a generic way to wait for an element to reach a custom condition without asserting it. The locator is
        re-resolved on each retry, so it tolerates the element being re-rendered while waiting.

        If `expression` returns a [Promise], this method will wait for the promise to resolve before checking its value.

        If `expression` throws or rejects, this method throws.

        **Usage**

        Wait for an attribute to appear:

        Passing argument to `expression`:

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()`
            methods.
        """

        self._sync(
            self._impl_obj.wait_for_function(
                expression=expression,
                arg=mapping.to_impl(arg),
                timeout=to_milliseconds(timeout),
            )
        )

    def within(self, locator: "Locator") -> "Locator":
        """Locator.within

        Returns a locator that matches this locator's elements inside each element matched by `locator`.

        Note that relative locators, such as `locator.nth()` or `locator.first`, are resolved separately inside each
        matched parent. In the example below, `page.getByRole('cell').nth(2)` picks the third cell of every row, not the
        third cell in the whole table.

        **Usage**

        ```py
        third_column = page.get_by_role(\"cell\").nth(2).within(page.get_by_role(\"row\"))
        expect(third_column).to_have_text([\"Apple\", \"Banana\", \"Cherry\"])
        ```

        Parameters
        ----------
        locator : Locator
            Locator matching the parent elements to search within.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.within(locator=locator._impl_obj))


mapping.register(LocatorImpl, Locator)


class LocatorAssertions(SyncBase):
    _impl_obj: LocatorAssertionsImpl

    def not_to_be_attached(
        self,
        *,
        attached: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_attached

        The opposite of `locator_assertions.to_be_attached()`.

        Parameters
        ----------
        attached : Union[bool, None]
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_be_attached(
                attached=attached, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_be_checked(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_checked

        The opposite of `locator_assertions.to_be_checked()`.

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.not_to_be_checked(timeout=to_milliseconds(timeout)))

    def not_to_be_disabled(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_disabled

        The opposite of `locator_assertions.to_be_disabled()`.

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.not_to_be_disabled(timeout=to_milliseconds(timeout)))

    def not_to_be_editable(
        self,
        *,
        editable: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_editable

        The opposite of `locator_assertions.to_be_editable()`.

        Parameters
        ----------
        editable : Union[bool, None]
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_be_editable(
                editable=editable, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_be_empty(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_empty

        The opposite of `locator_assertions.to_be_empty()`.

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.not_to_be_empty(timeout=to_milliseconds(timeout)))

    def not_to_be_enabled(
        self,
        *,
        enabled: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_enabled

        The opposite of `locator_assertions.to_be_enabled()`.

        Parameters
        ----------
        enabled : Union[bool, None]
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_be_enabled(
                enabled=enabled, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_be_focused(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_focused

        The opposite of `locator_assertions.to_be_focused()`.

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.not_to_be_focused(timeout=to_milliseconds(timeout)))

    def not_to_be_hidden(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_hidden

        The opposite of `locator_assertions.to_be_hidden()`.

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.not_to_be_hidden(timeout=to_milliseconds(timeout)))

    def not_to_be_in_viewport(
        self,
        *,
        ratio: typing.Optional[float] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_in_viewport

        The opposite of `locator_assertions.to_be_in_viewport()`.

        Parameters
        ----------
        ratio : Union[float, None]
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_be_in_viewport(
                ratio=ratio, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_be_visible(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        visible: typing.Optional[bool] = None,
    ) -> None:
        """LocatorAssertions.not_to_be_visible

        The opposite of `locator_assertions.to_be_visible()`.

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        visible : Union[bool, None]
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_be_visible(
                timeout=to_milliseconds(timeout), visible=visible
            )
        )

    def not_to_contain_class(
        self,
        expected: typing.Union[str, typing.Sequence[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_contain_class

        The opposite of `locator_assertions.to_contain_class()`.

        Parameters
        ----------
        expected : Union[Sequence[str], str]
            Expected class or RegExp or a list of those.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_contain_class(
                expected=mapping.to_impl(expected), timeout=to_milliseconds(timeout)
            )
        )

    def not_to_contain_text(
        self,
        expected: typing.Union[
            str,
            typing.Pattern[str],
            typing.Sequence[str],
            typing.Sequence[typing.Pattern[str]],
            typing.Sequence[typing.Union[str, typing.Pattern[str]]],
        ],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        use_inner_text: typing.Optional[bool] = None,
    ) -> None:
        """LocatorAssertions.not_to_contain_text

        The opposite of `locator_assertions.to_contain_text()`.

        Parameters
        ----------
        expected : Union[Pattern[str], Sequence[Pattern[str]], Sequence[Union[Pattern[str], str]], Sequence[str], str]
            Expected substring or RegExp or a list of those.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        use_inner_text : Union[bool, None]
            Whether to use `element.innerText` instead of `element.textContent` when retrieving DOM node text.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_contain_text(
                expected=mapping.to_impl(expected),
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
                useInnerText=use_inner_text,
            )
        )

    def not_to_have_accessible_description(
        self,
        name: typing.Union[str, typing.Pattern[str]],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_accessible_description

        The opposite of `locator_assertions.to_have_accessible_description()`.

        Parameters
        ----------
        name : Union[Pattern[str], str]
            Expected accessible description.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_accessible_description(
                name=name, ignoreCase=ignore_case, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_have_accessible_error_message(
        self,
        error_message: typing.Union[str, typing.Pattern[str]],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_accessible_error_message

        The opposite of `locator_assertions.to_have_accessible_error_message()`.

        Parameters
        ----------
        error_message : Union[Pattern[str], str]
            Expected accessible error message.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_accessible_error_message(
                errorMessage=error_message,
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
            )
        )

    def not_to_have_accessible_name(
        self,
        name: typing.Union[str, typing.Pattern[str]],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_accessible_name

        The opposite of `locator_assertions.to_have_accessible_name()`.

        Parameters
        ----------
        name : Union[Pattern[str], str]
            Expected accessible name.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_accessible_name(
                name=name, ignoreCase=ignore_case, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_have_attribute(
        self,
        name: str,
        value: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_attribute

        The opposite of `locator_assertions.to_have_attribute()`.

        Parameters
        ----------
        name : str
            Attribute name.
        value : Union[Pattern[str], str, None]
            Expected attribute value. If not specified, the assertion verifies that the attribute is absent.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_attribute(
                name=name,
                value=value,
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
            )
        )

    def not_to_have_class(
        self,
        expected: typing.Union[
            str,
            typing.Pattern[str],
            typing.Sequence[str],
            typing.Sequence[typing.Pattern[str]],
            typing.Sequence[typing.Union[str, typing.Pattern[str]]],
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_class

        The opposite of `locator_assertions.to_have_class()`.

        Parameters
        ----------
        expected : Union[Pattern[str], Sequence[Pattern[str]], Sequence[Union[Pattern[str], str]], Sequence[str], str]
            Expected class or RegExp or a list of those.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_class(
                expected=mapping.to_impl(expected), timeout=to_milliseconds(timeout)
            )
        )

    def not_to_have_count(
        self,
        count: int,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_count

        The opposite of `locator_assertions.to_have_count()`.

        Parameters
        ----------
        count : int
            Expected count.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_count(
                count=count, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_have_css(
        self,
        name: str,
        value: typing.Union[str, typing.Pattern[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_css

        The opposite of `locator_assertions.to_have_css()`.

        Parameters
        ----------
        name : str
            CSS property name.
        value : Union[Pattern[str], str]
            CSS property value.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_css(
                name=name, value=value, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_have_id(
        self,
        id: typing.Union[str, typing.Pattern[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_id

        The opposite of `locator_assertions.to_have_id()`.

        Parameters
        ----------
        id : Union[Pattern[str], str]
            Element id.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_id(id=id, timeout=to_milliseconds(timeout))
        )

    def not_to_have_js_property(
        self,
        name: str,
        value: typing.Any,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_js_property

        The opposite of `locator_assertions.to_have_js_property()`.

        Parameters
        ----------
        name : str
            Property name.
        value : Any
            Property value.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_js_property(
                name=name,
                value=mapping.to_impl(value),
                timeout=to_milliseconds(timeout),
            )
        )

    def not_to_have_role(
        self,
        role: Literal[
            "alert",
            "alertdialog",
            "application",
            "article",
            "banner",
            "blockquote",
            "button",
            "caption",
            "cell",
            "checkbox",
            "code",
            "columnheader",
            "combobox",
            "complementary",
            "contentinfo",
            "definition",
            "deletion",
            "dialog",
            "directory",
            "document",
            "emphasis",
            "feed",
            "figure",
            "form",
            "generic",
            "grid",
            "gridcell",
            "group",
            "heading",
            "img",
            "insertion",
            "link",
            "list",
            "listbox",
            "listitem",
            "log",
            "main",
            "marquee",
            "math",
            "menu",
            "menubar",
            "menuitem",
            "menuitemcheckbox",
            "menuitemradio",
            "meter",
            "navigation",
            "none",
            "note",
            "option",
            "paragraph",
            "presentation",
            "progressbar",
            "radio",
            "radiogroup",
            "region",
            "row",
            "rowgroup",
            "rowheader",
            "scrollbar",
            "search",
            "searchbox",
            "separator",
            "slider",
            "spinbutton",
            "status",
            "strong",
            "subscript",
            "superscript",
            "switch",
            "tab",
            "table",
            "tablist",
            "tabpanel",
            "term",
            "textbox",
            "time",
            "timer",
            "toolbar",
            "tooltip",
            "tree",
            "treegrid",
            "treeitem",
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_role

        The opposite of `locator_assertions.to_have_role()`.

        Parameters
        ----------
        role : Union["alert", "alertdialog", "application", "article", "banner", "blockquote", "button", "caption", "cell", "checkbox", "code", "columnheader", "combobox", "complementary", "contentinfo", "definition", "deletion", "dialog", "directory", "document", "emphasis", "feed", "figure", "form", "generic", "grid", "gridcell", "group", "heading", "img", "insertion", "link", "list", "listbox", "listitem", "log", "main", "marquee", "math", "menu", "menubar", "menuitem", "menuitemcheckbox", "menuitemradio", "meter", "navigation", "none", "note", "option", "paragraph", "presentation", "progressbar", "radio", "radiogroup", "region", "row", "rowgroup", "rowheader", "scrollbar", "search", "searchbox", "separator", "slider", "spinbutton", "status", "strong", "subscript", "superscript", "switch", "tab", "table", "tablist", "tabpanel", "term", "textbox", "time", "timer", "toolbar", "tooltip", "tree", "treegrid", "treeitem"]
            Required aria role.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_role(role=role, timeout=to_milliseconds(timeout))
        )

    def not_to_have_text(
        self,
        expected: typing.Union[
            str,
            typing.Pattern[str],
            typing.Sequence[str],
            typing.Sequence[typing.Pattern[str]],
            typing.Sequence[typing.Union[str, typing.Pattern[str]]],
        ],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        use_inner_text: typing.Optional[bool] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_text

        The opposite of `locator_assertions.to_have_text()`.

        Parameters
        ----------
        expected : Union[Pattern[str], Sequence[Pattern[str]], Sequence[Union[Pattern[str], str]], Sequence[str], str]
            Expected string or RegExp or a list of those.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        use_inner_text : Union[bool, None]
            Whether to use `element.innerText` instead of `element.textContent` when retrieving DOM node text.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_text(
                expected=mapping.to_impl(expected),
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
                useInnerText=use_inner_text,
            )
        )

    def not_to_have_value(
        self,
        value: typing.Union[str, typing.Pattern[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_value

        The opposite of `locator_assertions.to_have_value()`.

        Parameters
        ----------
        value : Union[Pattern[str], str]
            Expected value.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_value(
                value=value, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_have_values(
        self,
        values: typing.Union[
            typing.Sequence[str],
            typing.Sequence[typing.Pattern[str]],
            typing.Sequence[typing.Union[str, typing.Pattern[str]]],
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_have_values

        The opposite of `locator_assertions.to_have_values()`.

        Parameters
        ----------
        values : Union[Sequence[Pattern[str]], Sequence[Union[Pattern[str], str]], Sequence[str]]
            Expected options currently selected.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_values(
                values=mapping.to_impl(values), timeout=to_milliseconds(timeout)
            )
        )

    def not_to_match_aria_snapshot(
        self,
        expected: str,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.not_to_match_aria_snapshot

        The opposite of `locator_assertions.to_match_aria_snapshot()`.

        Parameters
        ----------
        expected : str
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_match_aria_snapshot(
                expected=expected, timeout=to_milliseconds(timeout)
            )
        )

    def to_be_attached(
        self,
        *,
        attached: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_attached

        Ensures that `Locator` points to an element that is
        [connected](https://developer.mozilla.org/en-US/docs/Web/API/Node/isConnected) to a Document or a ShadowRoot.

        **Usage**

        ```py
        expect(page.get_by_text(\"Hidden text\")).to_be_attached()
        ```

        Parameters
        ----------
        attached : Union[bool, None]
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_be_attached(
                attached=attached, timeout=to_milliseconds(timeout)
            )
        )

    def to_be_checked(
        self,
        *,
        checked: typing.Optional[bool] = None,
        indeterminate: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_checked

        Ensures the `Locator` points to a checked input.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.get_by_label(\"Subscribe to newsletter\")
        expect(locator).to_be_checked()
        ```

        Parameters
        ----------
        checked : Union[bool, None]
            Provides state to assert for. Asserts for input to be checked by default. This option can't be used when
            `indeterminate` is set to true.
        indeterminate : Union[bool, None]
            Asserts that the element is in the indeterminate (mixed) state. Only supported for checkboxes and radio buttons.
            This option can't be true when `checked` is provided.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_be_checked(
                checked=checked,
                indeterminate=indeterminate,
                timeout=to_milliseconds(timeout),
            )
        )

    def to_be_disabled(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_disabled

        Ensures the `Locator` points to a disabled element. Element is disabled if it has \"disabled\" attribute or is
        disabled via
        ['aria-disabled'](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Attributes/aria-disabled). Note
        that only native control elements such as HTML `button`, `input`, `select`, `textarea`, `option`, `optgroup` can be
        disabled by setting \"disabled\" attribute. \"disabled\" attribute on other elements is ignored by the browser.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\"button.submit\")
        expect(locator).to_be_disabled()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.to_be_disabled(timeout=to_milliseconds(timeout)))

    def to_be_editable(
        self,
        *,
        editable: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_editable

        Ensures the `Locator` points to an editable element.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.get_by_role(\"textbox\")
        expect(locator).to_be_editable()
        ```

        Parameters
        ----------
        editable : Union[bool, None]
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_be_editable(
                editable=editable, timeout=to_milliseconds(timeout)
            )
        )

    def to_be_empty(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_empty

        Ensures the `Locator` points to an empty editable element or to a DOM node that has no text.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\"div.warning\")
        expect(locator).to_be_empty()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.to_be_empty(timeout=to_milliseconds(timeout)))

    def to_be_enabled(
        self,
        *,
        enabled: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_enabled

        Ensures the `Locator` points to an enabled element.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\"button.submit\")
        expect(locator).to_be_enabled()
        ```

        Parameters
        ----------
        enabled : Union[bool, None]
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_be_enabled(
                enabled=enabled, timeout=to_milliseconds(timeout)
            )
        )

    def to_be_focused(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_focused

        Ensures the `Locator` points to a focused DOM node.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.get_by_role(\"textbox\")
        expect(locator).to_be_focused()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.to_be_focused(timeout=to_milliseconds(timeout)))

    def to_be_hidden(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_hidden

        Ensures that `Locator` either does not resolve to any DOM node, or resolves to a
        [non-visible](https://playwright.dev/python/docs/actionability#visible) one.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.locator('.my-element')
        expect(locator).to_be_hidden()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.to_be_hidden(timeout=to_milliseconds(timeout)))

    def to_be_in_viewport(
        self,
        *,
        ratio: typing.Optional[float] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_be_in_viewport

        Ensures the `Locator` points to an element that intersects viewport, according to the
        [intersection observer API](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API).

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.get_by_role(\"button\")
        # Make sure at least some part of element intersects viewport.
        expect(locator).to_be_in_viewport()
        # Make sure element is fully outside of viewport.
        expect(locator).not_to_be_in_viewport()
        # Make sure that at least half of the element intersects viewport.
        expect(locator).to_be_in_viewport(ratio=0.5)
        ```

        Parameters
        ----------
        ratio : Union[float, None]
            The minimal ratio of the element to intersect viewport. If equals to `0`, then element should intersect viewport at
            any positive ratio. Defaults to `0`.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_be_in_viewport(
                ratio=ratio, timeout=to_milliseconds(timeout)
            )
        )

    def to_be_visible(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        visible: typing.Optional[bool] = None,
    ) -> None:
        """LocatorAssertions.to_be_visible

        Ensures that `Locator` points to an attached and [visible](https://playwright.dev/python/docs/actionability#visible) DOM node.

        To check that at least one element from the list is visible, use `locator.first`.

        **Usage**

        ```py
        # A specific element is visible.
        expect(page.get_by_text(\"Welcome\")).to_be_visible()

        # At least one item in the list is visible.
        expect(page.get_by_test_id(\"todo-item\").first).to_be_visible()

        # At least one of the two elements is visible, possibly both.
        expect(
            page.get_by_role(\"button\", name=\"Sign in\")
            .or_(page.get_by_role(\"button\", name=\"Sign up\"))
            .first
        ).to_be_visible()
        ```

        Parameters
        ----------
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        visible : Union[bool, None]
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_be_visible(
                timeout=to_milliseconds(timeout), visible=visible
            )
        )

    def to_contain_class(
        self,
        expected: typing.Union[str, typing.Sequence[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_contain_class

        Ensures the `Locator` points to an element with given CSS classes. All classes from the asserted value, separated
        by spaces, must be present in the
        [Element.classList](https://developer.mozilla.org/en-US/docs/Web/API/Element/classList) in any order.

        **Usage**

        ```html
        <div class='middle selected row' id='component'></div>
        ```

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\"#component\")
        expect(locator).to_contain_class(\"middle selected row\")
        expect(locator).to_contain_class(\"selected\")
        expect(locator).to_contain_class(\"row middle\")
        ```

        When an array is passed, the method asserts that the list of elements located matches the corresponding list of
        expected class lists. Each element's class attribute is matched against the corresponding class in the array:

        ```html
        <div class='list'>
          <div class='component inactive'></div>
          <div class='component active'></div>
          <div class='component inactive'></div>
        </div>
        ```

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\".list > .component\")
        await expect(locator).to_contain_class([\"inactive\", \"active\", \"inactive\"])
        ```

        Parameters
        ----------
        expected : Union[Sequence[str], str]
            A string containing expected class names, separated by spaces, or a list of such strings to assert multiple
            elements.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_contain_class(
                expected=mapping.to_impl(expected), timeout=to_milliseconds(timeout)
            )
        )

    def to_contain_text(
        self,
        expected: typing.Union[
            str,
            typing.Pattern[str],
            typing.Sequence[str],
            typing.Sequence[typing.Pattern[str]],
            typing.Sequence[typing.Union[str, typing.Pattern[str]]],
        ],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        use_inner_text: typing.Optional[bool] = None,
    ) -> None:
        """LocatorAssertions.to_contain_text

        Ensures the `Locator` points to an element that contains the given text. All nested elements will be considered
        when computing the text content of the element. You can use regular expressions for the value as well.

        **Details**

        When `expected` parameter is a string, Playwright will normalize whitespaces and line breaks both in the actual
        text and in the expected string before matching. When regular expression is used, the actual text is matched as is.

        **Usage**

        ```py
        import re
        from playwright.sync_api import expect

        locator = page.locator('.title')
        expect(locator).to_contain_text(\"substring\")
        expect(locator).to_contain_text(re.compile(r\"\\d messages\"))
        ```

        If you pass an array as an expected value, the expectations are:
        1. Locator resolves to a list of elements.
        1. Elements from a **subset** of this list contain text from the expected array, respectively.
        1. The matching subset of elements has the same order as the expected array.
        1. Each text value from the expected array is matched by some element from the list.

        For example, consider the following list:

        ```html
        <ul>
          <li>Item Text 1</li>
          <li>Item Text 2</li>
          <li>Item Text 3</li>
        </ul>
        ```

        Let's see how we can use the assertion:

        ```py
        from playwright.sync_api import expect

        # ✓ Contains the right items in the right order
        expect(page.locator(\"ul > li\")).to_contain_text([\"Text 1\", \"Text 3\"])

        # ✖ Wrong order
        expect(page.locator(\"ul > li\")).to_contain_text([\"Text 3\", \"Text 2\"])

        # ✖ No item contains this text
        expect(page.locator(\"ul > li\")).to_contain_text([\"Some 33\"])

        # ✖ Locator points to the outer list element, not to the list items
        expect(page.locator(\"ul\")).to_contain_text([\"Text 3\"])
        ```

        Parameters
        ----------
        expected : Union[Pattern[str], Sequence[Pattern[str]], Sequence[Union[Pattern[str], str]], Sequence[str], str]
            Expected substring or RegExp or a list of those.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        use_inner_text : Union[bool, None]
            Whether to use `element.innerText` instead of `element.textContent` when retrieving DOM node text.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_contain_text(
                expected=mapping.to_impl(expected),
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
                useInnerText=use_inner_text,
            )
        )

    def to_have_accessible_description(
        self,
        description: typing.Union[str, typing.Pattern[str]],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_accessible_description

        Ensures the `Locator` points to an element with a given
        [accessible description](https://w3c.github.io/accname/#dfn-accessible-description).

        **Usage**

        ```py
        locator = page.get_by_test_id(\"save-button\")
        expect(locator).to_have_accessible_description(\"Save results to disk\")
        ```

        Parameters
        ----------
        description : Union[Pattern[str], str]
            Expected accessible description.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_accessible_description(
                description=description,
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
            )
        )

    def to_have_accessible_error_message(
        self,
        error_message: typing.Union[str, typing.Pattern[str]],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_accessible_error_message

        Ensures the `Locator` points to an element with a given
        [aria errormessage](https://w3c.github.io/aria/#aria-errormessage).

        **Usage**

        ```py
        locator = page.get_by_test_id(\"username-input\")
        expect(locator).to_have_accessible_error_message(\"Username is required.\")
        ```

        Parameters
        ----------
        error_message : Union[Pattern[str], str]
            Expected accessible error message.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_accessible_error_message(
                errorMessage=error_message,
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
            )
        )

    def to_have_accessible_name(
        self,
        name: typing.Union[str, typing.Pattern[str]],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_accessible_name

        Ensures the `Locator` points to an element with a given
        [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).

        **Usage**

        ```py
        locator = page.get_by_test_id(\"save-button\")
        expect(locator).to_have_accessible_name(\"Save to disk\")
        ```

        Parameters
        ----------
        name : Union[Pattern[str], str]
            Expected accessible name.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_accessible_name(
                name=name, ignoreCase=ignore_case, timeout=to_milliseconds(timeout)
            )
        )

    def to_have_attribute(
        self,
        name: str,
        value: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_attribute

        Ensures the `Locator` points to an element with given attribute.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\"input\")
        expect(locator).to_have_attribute(\"type\", \"text\")
        expect(locator).to_have_attribute(\"disabled\")
        expect(locator).not_to_have_attribute(\"readonly\")
        ```

        Parameters
        ----------
        name : str
            Attribute name.
        value : Union[Pattern[str], str, None]
            Expected attribute value. If not specified, the assertion verifies that the attribute is present.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_attribute(
                name=name,
                value=value,
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
            )
        )

    def to_have_class(
        self,
        expected: typing.Union[
            str,
            typing.Pattern[str],
            typing.Sequence[str],
            typing.Sequence[typing.Pattern[str]],
            typing.Sequence[typing.Union[str, typing.Pattern[str]]],
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_class

        Ensures the `Locator` points to an element with given CSS classes. When a string is provided, it must fully match
        the element's `class` attribute. To match individual classes use `locator_assertions.to_contain_class()`.

        **Usage**

        ```html
        <div class='middle selected row' id='component'></div>
        ```

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\"#component\")
        expect(locator).to_have_class(\"middle selected row\")
        expect(locator).to_have_class(re.compile(r\"(^|\\\\s)selected(\\\\s|$)\"))
        ```

        When an array is passed, the method asserts that the list of elements located matches the corresponding list of
        expected class values. Each element's class attribute is matched against the corresponding string or regular
        expression in the array:

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\".list > .component\")
        expect(locator).to_have_class([\"component\", \"component selected\", \"component\"])
        ```

        Parameters
        ----------
        expected : Union[Pattern[str], Sequence[Pattern[str]], Sequence[Union[Pattern[str], str]], Sequence[str], str]
            Expected class or RegExp or a list of those.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_class(
                expected=mapping.to_impl(expected), timeout=to_milliseconds(timeout)
            )
        )

    def to_have_count(
        self,
        count: int,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_count

        Ensures the `Locator` resolves to an exact number of DOM nodes.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\"list > .component\")
        expect(locator).to_have_count(3)
        ```

        Parameters
        ----------
        count : int
            Expected count.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_count(count=count, timeout=to_milliseconds(timeout))
        )

    def to_have_css(
        self,
        name: str,
        value: typing.Union[str, typing.Pattern[str]],
        *,
        pseudo: typing.Optional[Literal["after", "before"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_css

        Ensures the `Locator` resolves to an element with the given computed CSS style.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.get_by_role(\"button\")
        expect(locator).to_have_css(\"display\", \"flex\")
        ```

        Parameters
        ----------
        name : str
            CSS property name.
        value : Union[Pattern[str], str]
            CSS property value.
        pseudo : Union["after", "before", None]
            Pseudo-element to read computed styles from.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_css(
                name=name, value=value, pseudo=pseudo, timeout=to_milliseconds(timeout)
            )
        )

    def to_have_id(
        self,
        id: typing.Union[str, typing.Pattern[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_id

        Ensures the `Locator` points to an element with the given DOM Node ID.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.get_by_role(\"textbox\")
        expect(locator).to_have_id(\"lastname\")
        ```

        Parameters
        ----------
        id : Union[Pattern[str], str]
            Element id.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(self._impl_obj.to_have_id(id=id, timeout=to_milliseconds(timeout)))

    def to_have_js_property(
        self,
        name: str,
        value: typing.Any,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_js_property

        Ensures the `Locator` points to an element with given JavaScript property. Note that this property can be of a
        primitive type as well as a plain serializable JavaScript object.

        **Usage**

        ```py
        from playwright.sync_api import expect

        locator = page.locator(\".component\")
        expect(locator).to_have_js_property(\"loaded\", True)
        ```

        Parameters
        ----------
        name : str
            Property name.
        value : Any
            Property value.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_js_property(
                name=name,
                value=mapping.to_impl(value),
                timeout=to_milliseconds(timeout),
            )
        )

    def to_have_role(
        self,
        role: Literal[
            "alert",
            "alertdialog",
            "application",
            "article",
            "banner",
            "blockquote",
            "button",
            "caption",
            "cell",
            "checkbox",
            "code",
            "columnheader",
            "combobox",
            "complementary",
            "contentinfo",
            "definition",
            "deletion",
            "dialog",
            "directory",
            "document",
            "emphasis",
            "feed",
            "figure",
            "form",
            "generic",
            "grid",
            "gridcell",
            "group",
            "heading",
            "img",
            "insertion",
            "link",
            "list",
            "listbox",
            "listitem",
            "log",
            "main",
            "marquee",
            "math",
            "menu",
            "menubar",
            "menuitem",
            "menuitemcheckbox",
            "menuitemradio",
            "meter",
            "navigation",
            "none",
            "note",
            "option",
            "paragraph",
            "presentation",
            "progressbar",
            "radio",
            "radiogroup",
            "region",
            "row",
            "rowgroup",
            "rowheader",
            "scrollbar",
            "search",
            "searchbox",
            "separator",
            "slider",
            "spinbutton",
            "status",
            "strong",
            "subscript",
            "superscript",
            "switch",
            "tab",
            "table",
            "tablist",
            "tabpanel",
            "term",
            "textbox",
            "time",
            "timer",
            "toolbar",
            "tooltip",
            "tree",
            "treegrid",
            "treeitem",
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_role

        Ensures the `Locator` points to an element with a given [ARIA role](https://www.w3.org/TR/wai-aria-1.2/#roles).

        Note that role is matched as a string, disregarding the ARIA role hierarchy. For example, asserting  a superclass
        role `\"checkbox\"` on an element with a subclass role `\"switch\"` will fail.

        **Usage**

        ```py
        locator = page.get_by_test_id(\"save-button\")
        expect(locator).to_have_role(\"button\")
        ```

        Parameters
        ----------
        role : Union["alert", "alertdialog", "application", "article", "banner", "blockquote", "button", "caption", "cell", "checkbox", "code", "columnheader", "combobox", "complementary", "contentinfo", "definition", "deletion", "dialog", "directory", "document", "emphasis", "feed", "figure", "form", "generic", "grid", "gridcell", "group", "heading", "img", "insertion", "link", "list", "listbox", "listitem", "log", "main", "marquee", "math", "menu", "menubar", "menuitem", "menuitemcheckbox", "menuitemradio", "meter", "navigation", "none", "note", "option", "paragraph", "presentation", "progressbar", "radio", "radiogroup", "region", "row", "rowgroup", "rowheader", "scrollbar", "search", "searchbox", "separator", "slider", "spinbutton", "status", "strong", "subscript", "superscript", "switch", "tab", "table", "tablist", "tabpanel", "term", "textbox", "time", "timer", "toolbar", "tooltip", "tree", "treegrid", "treeitem"]
            Required aria role.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_role(role=role, timeout=to_milliseconds(timeout))
        )

    def to_have_text(
        self,
        expected: typing.Union[
            str,
            typing.Pattern[str],
            typing.Sequence[str],
            typing.Sequence[typing.Pattern[str]],
            typing.Sequence[typing.Union[str, typing.Pattern[str]]],
        ],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        use_inner_text: typing.Optional[bool] = None,
    ) -> None:
        """LocatorAssertions.to_have_text

        Ensures the `Locator` points to an element with the given text. All nested elements will be considered when
        computing the text content of the element. You can use regular expressions for the value as well.

        **Details**

        When `expected` parameter is a string, Playwright will normalize whitespaces and line breaks both in the actual
        text and in the expected string before matching. When regular expression is used, the actual text is matched as is.

        **Usage**

        ```py
        import re
        from playwright.sync_api import expect

        locator = page.locator(\".title\")
        expect(locator).to_have_text(re.compile(r\"Welcome, Test User\"))
        expect(locator).to_have_text(re.compile(r\"Welcome, .*\"))
        ```

        If you pass an array as an expected value, the expectations are:
        1. Locator resolves to a list of elements.
        1. The number of elements equals the number of expected values in the array.
        1. Elements from the list have text matching expected array values, one by one, in order.

        For example, consider the following list:

        ```html
        <ul>
          <li>Text 1</li>
          <li>Text 2</li>
          <li>Text 3</li>
        </ul>
        ```

        Let's see how we can use the assertion:

        ```py
        from playwright.sync_api import expect

        # ✓ Has the right items in the right order
        expect(page.locator(\"ul > li\")).to_have_text([\"Text 1\", \"Text 2\", \"Text 3\"])

        # ✖ Wrong order
        expect(page.locator(\"ul > li\")).to_have_text([\"Text 3\", \"Text 2\", \"Text 1\"])

        # ✖ Last item does not match
        expect(page.locator(\"ul > li\")).to_have_text([\"Text 1\", \"Text 2\", \"Text\"])

        # ✖ Locator points to the outer list element, not to the list items
        expect(page.locator(\"ul\")).to_have_text([\"Text 1\", \"Text 2\", \"Text 3\"])
        ```

        Parameters
        ----------
        expected : Union[Pattern[str], Sequence[Pattern[str]], Sequence[Union[Pattern[str], str]], Sequence[str], str]
            Expected string or RegExp or a list of those.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        use_inner_text : Union[bool, None]
            Whether to use `element.innerText` instead of `element.textContent` when retrieving DOM node text.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_text(
                expected=mapping.to_impl(expected),
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
                useInnerText=use_inner_text,
            )
        )

    def to_have_value(
        self,
        value: typing.Union[str, typing.Pattern[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_value

        Ensures the `Locator` points to an element with the given input value. You can use regular expressions for the
        value as well.

        **Usage**

        ```py
        import re
        from playwright.sync_api import expect

        locator = page.locator(\"input[type=number]\")
        expect(locator).to_have_value(re.compile(r\"[0-9]\"))
        ```

        Parameters
        ----------
        value : Union[Pattern[str], str]
            Expected value.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_value(value=value, timeout=to_milliseconds(timeout))
        )

    def to_have_values(
        self,
        values: typing.Union[
            typing.Sequence[str],
            typing.Sequence[typing.Pattern[str]],
            typing.Sequence[typing.Union[str, typing.Pattern[str]]],
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_have_values

        Ensures the `Locator` points to multi-select/combobox (i.e. a `select` with the `multiple` attribute) and the
        specified values are selected.

        **Usage**

        For example, given the following element:

        ```html
        <select id=\"favorite-colors\" multiple>
          <option value=\"R\">Red</option>
          <option value=\"G\">Green</option>
          <option value=\"B\">Blue</option>
        </select>
        ```

        ```py
        import re
        from playwright.sync_api import expect

        locator = page.locator(\"id=favorite-colors\")
        locator.select_option([\"R\", \"G\"])
        expect(locator).to_have_values([re.compile(r\"R\"), re.compile(r\"G\")])
        ```

        Parameters
        ----------
        values : Union[Sequence[Pattern[str]], Sequence[Union[Pattern[str], str]], Sequence[str]]
            Expected options currently selected.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_values(
                values=mapping.to_impl(values), timeout=to_milliseconds(timeout)
            )
        )

    def to_match_aria_snapshot(
        self,
        expected: str,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """LocatorAssertions.to_match_aria_snapshot

        Asserts that the target element matches the given [accessibility snapshot](https://playwright.dev/python/docs/aria-snapshots).

        **Usage**

        ```py
        page.goto(\"https://demo.playwright.dev/todomvc/\")
        expect(page.locator('body')).to_match_aria_snapshot('''
          - heading \"todos\"
          - textbox \"What needs to be done?\"
        ''')
        ```

        Parameters
        ----------
        expected : str
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_match_aria_snapshot(
                expected=expected, timeout=to_milliseconds(timeout)
            )
        )


mapping.register(LocatorAssertionsImpl, LocatorAssertions)


class Mouse(SyncBase):
    _impl_obj: MouseImpl

    def click(
        self,
        x: float,
        y: float,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        click_count: typing.Optional[int] = None,
        delay: typing.Optional[float] = None,
    ) -> None:
        """Mouse.click

        Shortcut for `mouse.move()`, `mouse.down()`, `mouse.up()`.

        Parameters
        ----------
        x : float
            X coordinate relative to the main frame's viewport in CSS pixels.
        y : float
            Y coordinate relative to the main frame's viewport in CSS pixels.
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        click_count : Union[int, None]
            defaults to 1. See [UIEvent.detail].
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        """

        self._sync(
            self._impl_obj.click(
                x=x, y=y, button=button, clickCount=click_count, delay=delay
            )
        )

    def dblclick(
        self,
        x: float,
        y: float,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        delay: typing.Optional[float] = None,
    ) -> None:
        """Mouse.dblclick

        Shortcut for `mouse.move()`, `mouse.down()`, `mouse.up()`, `mouse.down()` and `mouse.up()`.

        Parameters
        ----------
        x : float
            X coordinate relative to the main frame's viewport in CSS pixels.
        y : float
            Y coordinate relative to the main frame's viewport in CSS pixels.
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        """

        self._sync(self._impl_obj.dblclick(x=x, y=y, button=button, delay=delay))

    def down(
        self,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        click_count: typing.Optional[int] = None,
    ) -> None:
        """Mouse.down

        Dispatches a `mousedown` event.

        Parameters
        ----------
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        click_count : Union[int, None]
            defaults to 1. See [UIEvent.detail].
        """

        self._sync(self._impl_obj.down(button=button, clickCount=click_count))

    def move(self, x: float, y: float, *, steps: typing.Optional[int] = None) -> None:
        """Mouse.move

        Dispatches a `mousemove` event.

        Parameters
        ----------
        x : float
            X coordinate relative to the main frame's viewport in CSS pixels.
        y : float
            Y coordinate relative to the main frame's viewport in CSS pixels.
        steps : Union[int, None]
            Defaults to 1. Sends `n` interpolated `mousemove` events to represent travel between Playwright's current cursor
            position and the provided destination. When set to 1, emits a single `mousemove` event at the destination location.
        """

        self._sync(self._impl_obj.move(x=x, y=y, steps=steps))

    def up(
        self,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        click_count: typing.Optional[int] = None,
    ) -> None:
        """Mouse.up

        Dispatches a `mouseup` event.

        Parameters
        ----------
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        click_count : Union[int, None]
            defaults to 1. See [UIEvent.detail].
        """

        self._sync(self._impl_obj.up(button=button, clickCount=click_count))

    def wheel(self, delta_x: float, delta_y: float) -> None:
        """Mouse.wheel

        Dispatches a `wheel` event. This method is usually used to manually scroll the page. See
        [scrolling](https://playwright.dev/python/docs/input#scrolling) for alternative ways to scroll.

        **NOTE** Wheel events may cause scrolling if they are not handled, and this method does not wait for the scrolling
        to finish before returning.

        Parameters
        ----------
        delta_x : float
            Pixels to scroll horizontally.
        delta_y : float
            Pixels to scroll vertically.
        """

        self._sync(self._impl_obj.wheel(deltaX=delta_x, deltaY=delta_y))


mapping.register(MouseImpl, Mouse)


class Page(SyncContextManager):
    _impl_obj: PageImpl

    def add_init_script(
        self,
        script: typing.Optional[str] = None,
        *,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
    ) -> "SyncContextManager":
        """Page.add_init_script

        Adds a script which would be evaluated in one of the following scenarios:
        - Whenever the page is navigated.
        - Whenever the child frame is attached or navigated. In this case, the script is evaluated in the context of the
          newly attached frame.

        The script is evaluated after the document was created but before any of its scripts were run. This is useful to
        amend the JavaScript environment, e.g. to seed `Math.random`.

        **Usage**

        An example of overriding `Math.random` before the page loads:

        ```py
        # in your playwright script, assuming the preload.js file is in same directory
        page.add_init_script(path=\"./preload.js\")
        ```

        **NOTE** The order of evaluation of multiple scripts installed via `browser_context.add_init_script()` and
        `page.add_init_script()` is not defined.

        Parameters
        ----------
        script : Union[str, None]
            Script to be evaluated in all pages in the browser context. Optional.
        path : Union[pathlib.Path, str, None]
            Path to the JavaScript file. If `path` is a relative path, then it is resolved relative to the current working
            directory. Optional.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(self._impl_obj.add_init_script(script=script, path=path))
        )

    def add_locator_handler(
        self,
        locator: "Locator",
        handler: typing.Union[
            typing.Callable[["Locator"], typing.Any], typing.Callable[[], typing.Any]
        ],
        *,
        no_wait_after: typing.Optional[bool] = None,
        times: typing.Optional[int] = None,
    ) -> None:
        """Page.add_locator_handler

        When testing a web page, sometimes unexpected overlays like a \"Sign up\" dialog appear and block actions you want to
        automate, e.g. clicking a button. These overlays don't always show up in the same way or at the same time, making
        them tricky to handle in automated tests.

        This method lets you set up a special function, called a handler, that activates when it detects that overlay is
        visible. The handler's job is to remove the overlay, allowing your test to continue as if the overlay wasn't there.

        Things to keep in mind:
        - When an overlay is shown predictably, we recommend explicitly waiting for it in your test and dismissing it as
          a part of your normal test flow, instead of using `page.add_locator_handler()`.
        - Playwright checks for the overlay every time before executing or retrying an action that requires an
          [actionability check](https://playwright.dev/python/docs/actionability), or before performing an auto-waiting assertion check. When overlay
          is visible, Playwright calls the handler first, and then proceeds with the action/assertion. Note that the
          handler is only called when you perform an action/assertion - if the overlay becomes visible but you don't
          perform any actions, the handler will not be triggered.
        - After executing the handler, Playwright will ensure that overlay that triggered the handler is not visible
          anymore. You can opt-out of this behavior with `no_wait_after`.
        - The execution time of the handler counts towards the timeout of the action/assertion that executed the handler.
          If your handler takes too long, it might cause timeouts.
        - You can register multiple handlers. However, only a single handler will be running at a time. Make sure the
          actions within a handler don't depend on another handler.

        **NOTE** Running the handler will alter your page state mid-test. For example it will change the currently focused
        element and move the mouse. Make sure that actions that run after the handler are self-contained and do not rely on
        the focus and mouse state being unchanged.

        For example, consider a test that calls `locator.focus()` followed by `keyboard.press()`. If your handler clicks a
        button between these two actions, the focused element most likely will be wrong, and key press will happen on the
        unexpected element. Use `locator.press()` instead to avoid this problem.

        Another example is a series of mouse actions, where `mouse.move()` is followed by `mouse.down()`. Again, when the
        handler runs between these two actions, the mouse position will be wrong during the mouse down. Prefer
        self-contained actions like `locator.click()` that do not rely on the state being unchanged by a handler.

        **Usage**

        An example that closes a \"Sign up to the newsletter\" dialog when it appears:

        ```py
        # Setup the handler.
        def handler():
          page.get_by_role(\"button\", name=\"No thanks\").click()
        page.add_locator_handler(page.get_by_text(\"Sign up to the newsletter\"), handler)

        # Write the test as usual.
        page.goto(\"https://example.com\")
        page.get_by_role(\"button\", name=\"Start here\").click()
        ```

        An example that skips the \"Confirm your security details\" page when it is shown:

        ```py
        # Setup the handler.
        def handler():
          page.get_by_role(\"button\", name=\"Remind me later\").click()
        page.add_locator_handler(page.get_by_text(\"Confirm your security details\"), handler)

        # Write the test as usual.
        page.goto(\"https://example.com\")
        page.get_by_role(\"button\", name=\"Start here\").click()
        ```

        An example with a custom callback on every actionability check. It uses a `<body>` locator that is always visible,
        so the handler is called before every actionability check. It is important to specify `no_wait_after`, because the
        handler does not hide the `<body>` element.

        ```py
        # Setup the handler.
        def handler():
          page.evaluate(\"window.removeObstructionsForTestIfNeeded()\")
        page.add_locator_handler(page.locator(\"body\"), handler, no_wait_after=True)

        # Write the test as usual.
        page.goto(\"https://example.com\")
        page.get_by_role(\"button\", name=\"Start here\").click()
        ```

        Handler takes the original locator as an argument. You can also automatically remove the handler after a number of
        invocations by setting `times`:

        ```py
        def handler(locator):
          locator.click()
        page.add_locator_handler(page.get_by_label(\"Close\"), handler, times=1)
        ```

        Parameters
        ----------
        locator : Locator
            Locator that triggers the handler.
        handler : Union[Callable[[Locator], Any], Callable[[], Any]]
            Function that should be run once `locator` appears. This function should get rid of the element that blocks actions
            like click.
        no_wait_after : Union[bool, None]
            By default, after calling the handler Playwright will wait until the overlay becomes hidden, and only then
            Playwright will continue with the action/assertion that triggered the handler. This option allows to opt-out of
            this behavior, so that overlay can stay visible after the handler has run.
        times : Union[int, None]
            Specifies the maximum number of times this handler should be called. Unlimited by default.
        """

        self._sync(
            self._impl_obj.add_locator_handler(
                locator=locator._impl_obj,
                handler=self._wrap_handler(handler),
                noWaitAfter=no_wait_after,
                times=times,
            )
        )

    def add_script_tag(
        self,
        *,
        content: typing.Optional[str] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        type: typing.Optional[str] = None,
        url: typing.Optional[str] = None,
    ) -> "ElementHandle":
        """Page.add_script_tag

        Adds a `<script>` tag into the page with the desired url or content. Returns the added tag when the script's onload
        fires or when the script content was injected into frame.

        Parameters
        ----------
        content : Union[str, None]
            Raw JavaScript content to be injected into frame.
        path : Union[pathlib.Path, str, None]
            Path to the JavaScript file to be injected into frame. If `path` is a relative path, then it is resolved relative
            to the current working directory.
        type : Union[str, None]
            Script type. Use 'module' in order to load a JavaScript ES6 module. See
            [script](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/script) for more details.
        url : Union[str, None]
            URL of a script to be added.

        Returns
        -------
        ElementHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.add_script_tag(
                    content=content, path=path, type=type, url=url
                )
            )
        )

    def add_style_tag(
        self,
        *,
        content: typing.Optional[str] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        url: typing.Optional[str] = None,
    ) -> "ElementHandle":
        """Page.add_style_tag

        Adds a `<link rel=\"stylesheet\">` tag into the page with the desired url or a `<style type=\"text/css\">` tag with the
        content. Returns the added tag when the stylesheet's onload fires or when the CSS content was injected into frame.

        Parameters
        ----------
        content : Union[str, None]
            Raw CSS content to be injected into frame.
        path : Union[pathlib.Path, str, None]
            Path to the CSS file to be injected into frame. If `path` is a relative path, then it is resolved relative to the
            current working directory.
        url : Union[str, None]
            URL of the `<link>` tag.

        Returns
        -------
        ElementHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.add_style_tag(content=content, path=path, url=url)
            )
        )

    def aria_snapshot(
        self,
        *,
        boxes: typing.Optional[bool] = None,
        depth: typing.Optional[int] = None,
        mode: typing.Optional[Literal["ai", "default"]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Page.aria_snapshot

        Captures the aria snapshot of the page. Read more about [aria snapshots](https://playwright.dev/python/docs/aria-snapshots).

        Parameters
        ----------
        boxes : Union[bool, None]
            When `true`, appends each element's bounding box as `[box=x,y,width,height]` to the snapshot. Coordinates are
            relative to the viewport, in CSS pixels, as returned by
            [`Element.getBoundingClientRect()`](https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect).
            Defaults to `false`.
        depth : Union[int, None]
            When specified, limits the depth of the snapshot.
        mode : Union["ai", "default", None]
            When set to `"ai"`, returns a snapshot optimized for AI consumption: including element references like `[ref=e2]`
            and snapshots of `<iframe>`s. Defaults to `"default"`.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.aria_snapshot(
                    boxes=boxes,
                    depth=depth,
                    mode=mode,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def bring_to_front(self) -> None:
        """Page.bring_to_front

        Brings page to front (activates tab).
        """

        self._sync(self._impl_obj.bring_to_front())

    def cancel_pick_locator(self) -> None:
        """Page.cancel_pick_locator

        Cancels an ongoing `page.pick_locator()` call by deactivating pick locator mode. If no pick locator mode is active,
        this method is a no-op.
        """

        self._sync(self._impl_obj.cancel_pick_locator())

    def check(
        self,
        selector: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Page.check

        This method checks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Ensure that matched element is a checkbox or a radio input. If not, this method throws. If the element is
           already checked, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now checked. If not, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.check(
                selector=selector,
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def clear_console_messages(self) -> None:
        """Page.clear_console_messages

        Clears all stored console messages from this page. Subsequent calls to `page.console_messages()` will only return
        messages logged after the clear.
        """

        self._sync(self._impl_obj.clear_console_messages())

    def clear_page_errors(self) -> None:
        """Page.clear_page_errors

        Clears all stored page errors from this page. Subsequent calls to `page.page_errors()` will only return errors
        thrown after the clear.
        """

        self._sync(self._impl_obj.clear_page_errors())

    def click(
        self,
        selector: str,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        click_count: typing.Optional[int] = None,
        delay: typing.Optional[float] = None,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Page.click

        This method clicks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element, or the specified `position`.
        1. Wait for initiated navigations to either succeed or fail, unless `no_wait_after` option is set.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        click_count : Union[int, None]
            defaults to 1. See [UIEvent.detail].
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            Actions that initiate navigations are waiting for these navigations to happen and for pages to start loading. You
            can opt out of waiting via setting this flag. You would only need this option in the exceptional cases such as
            navigating to inaccessible pages. Defaults to `false`.
            Deprecated: This option will default to `true` in the future.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.click(
                selector=selector,
                button=button,
                clickCount=click_count,
                delay=delay,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    @property
    def clock(self) -> "Clock":
        """Page.clock

        Playwright has ability to mock clock and passage of time.

        Returns
        -------
        Clock
        """
        return mapping.from_impl(self._impl_obj.clock)

    def close(
        self,
        *,
        reason: typing.Optional[str] = None,
        run_before_unload: typing.Optional[bool] = None,
    ) -> None:
        """Page.close

        If `run_before_unload` is `false`, does not run any unload handlers and waits for the page to be closed. If
        `run_before_unload` is `true` the method will run unload handlers, but will **not** wait for the page to close.

        By default, `page.close()` **does not** run `beforeunload` handlers.

        **NOTE** if `run_before_unload` is passed as true, a `beforeunload` dialog might be summoned and should be handled
        manually via `page.on('dialog')` event.

        Parameters
        ----------
        reason : Union[str, None]
            The reason to be reported to the operations interrupted by the page closure.
        run_before_unload : Union[bool, None]
            Defaults to `false`. Whether to run the
            [before unload](https://developer.mozilla.org/en-US/docs/Web/Events/beforeunload) page handlers.
        """

        self._sync(
            self._impl_obj.close(reason=reason, runBeforeUnload=run_before_unload)
        )

    def console_messages(
        self, *, filter: typing.Optional[Literal["all", "since-navigation"]] = None
    ) -> typing.List["ConsoleMessage"]:
        """Page.console_messages

        Returns up to (currently) 200 last console messages from this page. See `page.on('console')` for more details.

        Parameters
        ----------
        filter : Union["all", "since-navigation", None]
            Controls which messages are returned:

        Returns
        -------
        List[ConsoleMessage]
        """

        return mapping.from_impl_list(
            self._sync(self._impl_obj.console_messages(filter=filter))
        )

    def content(self, *, include_shadow: typing.Optional[bool] = None) -> str:
        """Page.content

        Gets the full HTML contents of the page, including the doctype.

        Parameters
        ----------
        include_shadow : Union[bool, None]
            When true, contents of open shadow roots are included as
            [declarative shadow DOM](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_shadow_DOM#declaratively_with_html),
            i.e. `<template shadowrootmode="open">` elements nested inside their host elements. Closed shadow roots are never
            included. Defaults to `false`.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.content(includeShadow=include_shadow))
        )

    @property
    def context(self) -> "BrowserContext":
        """Page.context

        Get the browser context that the page belongs to.

        Returns
        -------
        BrowserContext
        """
        return mapping.from_impl(self._impl_obj.context)

    def dblclick(
        self,
        selector: str,
        *,
        button: typing.Optional[Literal["left", "middle", "right"]] = None,
        delay: typing.Optional[float] = None,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Page.dblclick

        This method double clicks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to double click in the center of the element, or the specified `position`.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **NOTE** `page.dblclick()` dispatches two `click` events and a single `dblclick` event.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        button : Union["left", "middle", "right", None]
            Defaults to `left`.
        delay : Union[float, None]
            Time to wait between `mousedown` and `mouseup` in milliseconds. Defaults to 0.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.dblclick(
                selector=selector,
                button=button,
                delay=delay,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def dispatch_event(
        self,
        selector: str,
        type: str,
        event_init: typing.Optional[typing.Dict] = None,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Page.dispatch_event

        The snippet below dispatches the `click` event on the element. Regardless of the visibility state of the element,
        `click` is dispatched. This is equivalent to calling
        [element.click()](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/click).

        **Usage**

        ```py
        page.dispatch_event(\"button#submit\", \"click\")
        ```

        Under the hood, it creates an instance of an event based on the given `type`, initializes it with `event_init`
        properties and dispatches it on the element. Events are `composed`, `cancelable` and bubble by default.

        Since `event_init` is event-specific, please refer to the events documentation for the lists of initial properties:
        - [DeviceMotionEvent](https://developer.mozilla.org/en-US/docs/Web/API/DeviceMotionEvent/DeviceMotionEvent)
        - [DeviceOrientationEvent](https://developer.mozilla.org/en-US/docs/Web/API/DeviceOrientationEvent/DeviceOrientationEvent)
        - [DragEvent](https://developer.mozilla.org/en-US/docs/Web/API/DragEvent/DragEvent)
        - [Event](https://developer.mozilla.org/en-US/docs/Web/API/Event/Event)
        - [FocusEvent](https://developer.mozilla.org/en-US/docs/Web/API/FocusEvent/FocusEvent)
        - [KeyboardEvent](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/KeyboardEvent)
        - [MouseEvent](https://developer.mozilla.org/en-US/docs/Web/API/MouseEvent/MouseEvent)
        - [PointerEvent](https://developer.mozilla.org/en-US/docs/Web/API/PointerEvent/PointerEvent)
        - [TouchEvent](https://developer.mozilla.org/en-US/docs/Web/API/TouchEvent/TouchEvent)
        - [WheelEvent](https://developer.mozilla.org/en-US/docs/Web/API/WheelEvent/WheelEvent)

        You can also specify `JSHandle` as the property value if you want live objects to be passed into the event:

        ```py
        # note you can only create data_transfer in chromium and firefox
        data_transfer = page.evaluate_handle(\"new DataTransfer()\")
        page.dispatch_event(\"#source\", \"dragstart\", { \"dataTransfer\": data_transfer })
        ```

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        type : str
            DOM event type: `"click"`, `"dragstart"`, etc.
        event_init : Union[Dict, None]
            Optional event-specific initialization properties.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.dispatch_event(
                selector=selector,
                type=type,
                eventInit=mapping.to_impl(event_init),
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def drag_and_drop(
        self,
        source: str,
        target: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        source_position: typing.Optional[Position] = None,
        steps: typing.Optional[int] = None,
        strict: typing.Optional[bool] = None,
        target_position: typing.Optional[Position] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Page.drag_and_drop

        This method drags the source element to the target element. It will first move to the source element, perform a
        `mousedown`, then move to the target element and perform a `mouseup`.

        **Usage**

        ```py
        page.drag_and_drop(\"#source\", \"#target\")
        # or specify exact positions relative to the top-left corners of the elements:
        page.drag_and_drop(
          \"#source\",
          \"#target\",
          source_position={\"x\": 34, \"y\": 7},
          target_position={\"x\": 10, \"y\": 20}
        )
        ```

        Parameters
        ----------
        source : str
            A selector to search for an element to drag. If there are multiple elements satisfying the selector, the first will
            be used.
        target : str
            A selector to search for an element to drop onto. If there are multiple elements satisfying the selector, the first
            will be used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        source_position : Union[{x: float, y: float}, None]
            Clicks on the source element at this point relative to the top-left corner of the element's padding box. If not
            specified, some visible point of the element is used.
        steps : Union[int, None]
            Defaults to 1. Sends `n` interpolated `mousemove` events to represent travel between the `mousedown` and `mouseup`
            of the drag. When set to 1, emits a single `mousemove` event at the destination location.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        target_position : Union[{x: float, y: float}, None]
            Drops on the target element at this point relative to the top-left corner of the element's padding box. If not
            specified, some visible point of the element is used.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.drag_and_drop(
                source=source,
                target=target,
                force=force,
                noWaitAfter=no_wait_after,
                scroll=scroll,
                sourcePosition=source_position,
                steps=steps,
                strict=strict,
                targetPosition=target_position,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def emulate_media(
        self,
        *,
        color_scheme: typing.Optional[
            Literal["dark", "light", "no-preference", "null"]
        ] = None,
        contrast: typing.Optional[Literal["more", "no-preference", "null"]] = None,
        forced_colors: typing.Optional[Literal["active", "none", "null"]] = None,
        media: typing.Optional[Literal["null", "print", "screen"]] = None,
        reduced_motion: typing.Optional[
            Literal["no-preference", "null", "reduce"]
        ] = None,
    ) -> None:
        """Page.emulate_media

        This method changes the `CSS media type` through the `media` argument, and/or the `'prefers-colors-scheme'` media
        feature, using the `colorScheme` argument.

        **Usage**

        ```py
        page.evaluate(\"matchMedia('screen').matches\")
        # → True
        page.evaluate(\"matchMedia('print').matches\")
        # → False

        page.emulate_media(media=\"print\")
        page.evaluate(\"matchMedia('screen').matches\")
        # → False
        page.evaluate(\"matchMedia('print').matches\")
        # → True

        page.emulate_media()
        page.evaluate(\"matchMedia('screen').matches\")
        # → True
        page.evaluate(\"matchMedia('print').matches\")
        # → False
        ```

        ```py
        page.emulate_media(color_scheme=\"dark\")
        page.evaluate(\"matchMedia('(prefers-color-scheme: dark)').matches\")
        # → True
        page.evaluate(\"matchMedia('(prefers-color-scheme: light)').matches\")
        # → False
        ```

        Parameters
        ----------
        color_scheme : Union["dark", "light", "no-preference", "null", None]
            Emulates [prefers-colors-scheme](https://developer.mozilla.org/en-US/docs/Web/CSS/@media/prefers-color-scheme)
            media feature, supported values are `'light'` and `'dark'`. Passing `'Null'` disables color scheme emulation.
            `'no-preference'` is deprecated.
        contrast : Union["more", "no-preference", "null", None]
        forced_colors : Union["active", "none", "null", None]
        media : Union["null", "print", "screen", None]
            Changes the CSS media type of the page. The only allowed values are `'Screen'`, `'Print'` and `'Null'`. Passing
            `'Null'` disables CSS media emulation.
        reduced_motion : Union["no-preference", "null", "reduce", None]
            Emulates `'prefers-reduced-motion'` media feature, supported values are `'reduce'`, `'no-preference'`. Passing
            `null` disables reduced motion emulation.
        """

        self._sync(
            self._impl_obj.emulate_media(
                colorScheme=color_scheme,
                contrast=contrast,
                forcedColors=forced_colors,
                media=media,
                reducedMotion=reduced_motion,
            )
        )

    def eval_on_selector(
        self,
        selector: str,
        expression: str,
        arg: typing.Optional[typing.Any] = None,
        *,
        strict: typing.Optional[bool] = None,
    ) -> typing.Any:
        """Page.eval_on_selector

        The method finds an element matching the specified selector within the page and passes it as a first argument to
        `expression`. If no elements match the selector, the method throws an error. Returns the value of `expression`.

        If `expression` returns a [Promise], then `page.eval_on_selector()` would wait for the promise to resolve and
        return its value.

        **Usage**

        ```py
        search_value = page.eval_on_selector(\"#search\", \"el => el.value\")
        preload_href = page.eval_on_selector(\"link[rel=preload]\", \"el => el.href\")
        html = page.eval_on_selector(\".main-container\", \"(e, suffix) => e.outer_html + suffix\", \"hello\")
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.eval_on_selector(
                    selector=selector,
                    expression=expression,
                    arg=mapping.to_impl(arg),
                    strict=strict,
                )
            )
        )

    def eval_on_selector_all(
        self, selector: str, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """Page.eval_on_selector_all

        The method finds all elements matching the specified selector within the page and passes an array of matched
        elements as a first argument to `expression`. Returns the result of `expression` invocation.

        If `expression` returns a [Promise], then `page.eval_on_selector_all()` would wait for the promise to resolve and
        return its value.

        **Usage**

        ```py
        div_counts = page.eval_on_selector_all(\"div\", \"(divs, min) => divs.length >= min\", 10)
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.eval_on_selector_all(
                    selector=selector, expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    def evaluate(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """Page.evaluate

        Returns the value of the `expression` invocation.

        If the function passed to the `page.evaluate()` returns a [Promise], then `page.evaluate()` would wait for the
        promise to resolve and return its value.

        If the function passed to the `page.evaluate()` returns a non-[Serializable] value, then `page.evaluate()` resolves
        to `undefined`. Playwright also supports transferring some additional values that are not serializable by `JSON`:
        `-0`, `NaN`, `Infinity`, `-Infinity`.

        **Usage**

        Passing argument to `expression`:

        ```py
        result = page.evaluate(\"([x, y]) => Promise.resolve(x * y)\", [7, 8])
        print(result) # prints \"56\"
        ```

        A string can also be passed in instead of a function:

        ```py
        print(page.evaluate(\"1 + 2\")) # prints \"3\"
        x = 10
        print(page.evaluate(f\"1 + {x}\")) # prints \"11\"
        ```

        `ElementHandle` instances can be passed as an argument to the `page.evaluate()`:

        ```py
        body_handle = page.evaluate_handle(\"document.body\")
        html = page.evaluate(\"([body, suffix]) => body.innerHTML + suffix\", [body_handle, \"hello\"])
        body_handle.dispose()
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.evaluate(expression=expression, arg=mapping.to_impl(arg))
            )
        )

    def evaluate_handle(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> "JSHandle":
        """Page.evaluate_handle

        Returns the value of the `expression` invocation as a `JSHandle`.

        The only difference between `page.evaluate()` and `page.evaluate_handle()` is that `page.evaluate_handle()` returns
        `JSHandle`.

        If the function passed to the `page.evaluate_handle()` returns a [Promise], then `page.evaluate_handle()` would
        wait for the promise to resolve and return its value.

        **Usage**

        ```py
        a_window_handle = page.evaluate_handle(\"Promise.resolve(window)\")
        a_window_handle # handle for the window object.
        ```

        A string can also be passed in instead of a function:

        ```py
        a_handle = page.evaluate_handle(\"document\") # handle for the \"document\"
        ```

        `JSHandle` instances can be passed as an argument to the `page.evaluate_handle()`:

        ```py
        a_handle = page.evaluate_handle(\"document.body\")
        result_handle = page.evaluate_handle(\"body => body.innerHTML\", a_handle)
        print(result_handle.json_value())
        result_handle.dispose()
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        JSHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.evaluate_handle(
                    expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    def expect_console_message(
        self,
        predicate: typing.Optional[typing.Callable[["ConsoleMessage"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["ConsoleMessage"]:
        """Page.expect_console_message

        Performs action and waits for a `ConsoleMessage` to be logged by in the page. If predicate is provided, it passes
        `ConsoleMessage` value into the `predicate` function and waits for `predicate(message)` to return a truthy value.
        Will throw an error if the page is closed before the `page.on('console')` event is fired.

        Parameters
        ----------
        predicate : Union[Callable[[ConsoleMessage], bool], None]
            Receives the `ConsoleMessage` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[ConsoleMessage]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_console_message(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_download(
        self,
        predicate: typing.Optional[typing.Callable[["Download"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["Download"]:
        """Page.expect_download

        Performs action and waits for a new `Download`. If predicate is provided, it passes `Download` value into the
        `predicate` function and waits for `predicate(download)` to return a truthy value. Will throw an error if the page
        is closed before the download event is fired.

        Parameters
        ----------
        predicate : Union[Callable[[Download], bool], None]
            Receives the `Download` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[Download]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_download(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["close"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["console"],
        predicate: typing.Optional[typing.Callable[["ConsoleMessage"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["ConsoleMessage"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["crash"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["dialog"],
        predicate: typing.Optional[typing.Callable[["Dialog"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Dialog"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["dialogclosed"],
        predicate: typing.Optional[typing.Callable[["Dialog"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Dialog"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["domcontentloaded"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["download"],
        predicate: typing.Optional[typing.Callable[["Download"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Download"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["filechooser"],
        predicate: typing.Optional[typing.Callable[["FileChooser"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["FileChooser"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["frameattached"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Frame"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["framedetached"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Frame"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["framenavigated"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Frame"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["load"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["pageerror"],
        predicate: typing.Optional[typing.Callable[["Error"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Error"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["popup"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Page"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["request"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Request"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["requestfailed"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Request"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["requestfinished"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Request"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["response"],
        predicate: typing.Optional[typing.Callable[["Response"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Response"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["websocket"],
        predicate: typing.Optional[typing.Callable[["WebSocket"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["WebSocket"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["worker"],
        predicate: typing.Optional[typing.Callable[["Worker"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Worker"]: ...

    @typing.overload
    def expect_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable[..., bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager[typing.Any]: ...

    def expect_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager:
        """Page.expect_event

        Waits for event to fire and passes its value into the predicate function. Returns when the predicate returns truthy
        value. Will throw an error if the page is closed before the event is fired. Returns the event data value.

        **Usage**

        ```py
        with page.expect_event(\"framenavigated\") as event_info:
            page.get_by_role(\"button\")
        frame = event_info.value
        ```

        Parameters
        ----------
        event : str
            Event name, same one typically passed into `*.on(event)`.
        predicate : Union[Callable, None]
            Receives the event data and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_event(
                event=event,
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_file_chooser(
        self,
        predicate: typing.Optional[typing.Callable[["FileChooser"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["FileChooser"]:
        """Page.expect_file_chooser

        Performs action and waits for a new `FileChooser` to be created. If predicate is provided, it passes `FileChooser`
        value into the `predicate` function and waits for `predicate(fileChooser)` to return a truthy value. Will throw an
        error if the page is closed before the file chooser is opened.

        Parameters
        ----------
        predicate : Union[Callable[[FileChooser], bool], None]
            Receives the `FileChooser` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[FileChooser]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_file_chooser(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_navigation(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        url: typing.Optional[
            typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]]
        ] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> EventContextManager["Response"]:
        """Page.expect_navigation

        Waits for the main frame navigation and returns the main resource response. In case of multiple redirects, the
        navigation will resolve with the response of the last redirect. In case of navigation to a different anchor or
        navigation due to History API usage, the navigation will resolve with `null`.

        **Usage**

        This resolves when the page navigates to a new URL or reloads. It is useful for when you run code which will
        indirectly cause the page to navigate. e.g. The click target has an `onclick` handler that triggers navigation from
        a `setTimeout`. Consider this example:

        ```py
        with page.expect_navigation():
            # This action triggers the navigation after a timeout.
            page.get_by_text(\"Navigate after timeout\").click()
        # Resolves after navigation has finished
        ```

        **NOTE** Usage of the [History API](https://developer.mozilla.org/en-US/docs/Web/API/History_API) to change the URL
        is considered a navigation.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        url : Union[Callable[[str], bool], Pattern[str], str, None]
            A glob pattern, regex pattern, or predicate receiving [URL] to match while waiting for the navigation. Note that if
            the parameter is a string without wildcard characters, the method will wait for navigation to URL that is exactly
            equal to the string.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.

        Returns
        -------
        EventContextManager[Response]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_navigation(
                timeout=to_milliseconds(timeout),
                url=self._wrap_handler(url),
                waitUntil=wait_until,
            ).future,
        )

    def expect_popup(
        self,
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["Page"]:
        """Page.expect_popup

        Performs action and waits for a popup `Page`. If predicate is provided, it passes [Popup] value into the
        `predicate` function and waits for `predicate(page)` to return a truthy value. Will throw an error if the page is
        closed before the popup event is fired.

        Parameters
        ----------
        predicate : Union[Callable[[Page], bool], None]
            Receives the `Page` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[Page]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_popup(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_request(
        self,
        url_or_predicate: typing.Union[
            str, typing.Pattern[str], typing.Callable[["Request"], bool]
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["Request"]:
        """Page.expect_request

        Waits for the matching request and returns it. See [waiting for event](https://playwright.dev/python/docs/events#waiting-for-event) for more
        details about events.

        **Usage**

        ```py
        with page.expect_request(\"http://example.com/resource\") as first:
            page.get_by_text(\"trigger request\").click()
        first_request = first.value

        # or with a lambda
        with page.expect_request(lambda request: request.url == \"http://example.com\" and request.method == \"get\") as second:
            page.get_by_text(\"trigger request\").click()
        second_request = second.value
        ```

        Parameters
        ----------
        url_or_predicate : Union[Callable[[Request], bool], Pattern[str], str]
            Request URL string, regex or predicate receiving `Request` object. When a `base_url` via the context options was
            provided and the passed URL is a path, it gets merged via the
            [`new URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor.
        timeout : Union[float, None]
            Maximum wait time in milliseconds, defaults to 30 seconds, pass `0` to disable the timeout. The default value can
            be changed by using the `page.set_default_timeout()` method.

        Returns
        -------
        EventContextManager[Request]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_request(
                urlOrPredicate=self._wrap_handler(url_or_predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_request_finished(
        self,
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["Request"]:
        """Page.expect_request_finished

        Performs action and waits for a `Request` to finish loading. If predicate is provided, it passes `Request` value
        into the `predicate` function and waits for `predicate(request)` to return a truthy value. Will throw an error if
        the page is closed before the `page.on('requestfinished')` event is fired.

        Parameters
        ----------
        predicate : Union[Callable[[Request], bool], None]
            Receives the `Request` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[Request]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_request_finished(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_response(
        self,
        url_or_predicate: typing.Union[
            str, typing.Pattern[str], typing.Callable[["Response"], bool]
        ],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["Response"]:
        """Page.expect_response

        Returns the matched response. See [waiting for event](https://playwright.dev/python/docs/events#waiting-for-event) for more details about
        events.

        **Usage**

        ```py
        with page.expect_response(\"https://example.com/resource\") as response_info:
            page.get_by_text(\"trigger response\").click()
        response = response_info.value
        return response.ok

        # or with a lambda
        with page.expect_response(lambda response: response.url == \"https://example.com\" and response.status == 200 and response.request.method == \"get\") as response_info:
            page.get_by_text(\"trigger response\").click()
        response = response_info.value
        return response.ok
        ```

        Parameters
        ----------
        url_or_predicate : Union[Callable[[Response], bool], Pattern[str], str]
            Request URL string, regex or predicate receiving `Response` object. When a `base_url` via the context options was
            provided and the passed URL is a path, it gets merged via the
            [`new URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor.
        timeout : Union[float, None]
            Maximum wait time in milliseconds, defaults to 30 seconds, pass `0` to disable the timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        EventContextManager[Response]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_response(
                urlOrPredicate=self._wrap_handler(url_or_predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_websocket(
        self,
        predicate: typing.Optional[typing.Callable[["WebSocket"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["WebSocket"]:
        """Page.expect_websocket

        Performs action and waits for a new `WebSocket`. If predicate is provided, it passes `WebSocket` value into the
        `predicate` function and waits for `predicate(webSocket)` to return a truthy value. Will throw an error if the page
        is closed before the WebSocket event is fired.

        Parameters
        ----------
        predicate : Union[Callable[[WebSocket], bool], None]
            Receives the `WebSocket` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[WebSocket]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_websocket(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expect_worker(
        self,
        predicate: typing.Optional[typing.Callable[["Worker"], bool]] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager["Worker"]:
        """Page.expect_worker

        Performs action and waits for a new `Worker`. If predicate is provided, it passes `Worker` value into the
        `predicate` function and waits for `predicate(worker)` to return a truthy value. Will throw an error if the page is
        closed before the worker event is fired.

        Parameters
        ----------
        predicate : Union[Callable[[Worker], bool], None]
            Receives the `Worker` object and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager[Worker]
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_worker(
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def expose_binding(
        self, name: str, callback: typing.Callable
    ) -> "SyncContextManager":
        """Page.expose_binding

        The method adds a function called `name` on the `window` object of every frame in this page. When called, the
        function executes `callback` and returns a [Promise] which resolves to the return value of `callback`. If the
        `callback` returns a [Promise], it will be awaited.

        The first argument of the `callback` function contains information about the caller: `{ browserContext:
        BrowserContext, page: Page, frame: Frame }`.

        See `browser_context.expose_binding()` for the context-wide version.

        **NOTE** Functions installed via `page.expose_binding()` survive navigations.

        **Usage**

        An example of exposing page URL to all frames in a page:

        ```py
        from playwright.sync_api import sync_playwright, Playwright

        def run(playwright: Playwright):
            webkit = playwright.webkit
            browser = webkit.launch(headless=False)
            context = browser.new_context()
            page = context.new_page()
            page.expose_binding(\"pageURL\", lambda source: source[\"page\"].url)
            page.set_content(\"\"\"
            <script>
              async function onClick() {
                document.querySelector('div').textContent = await window.pageURL();
              }
            </script>
            <button onclick=\"onClick()\">Click me</button>
            <div></div>
            \"\"\")
            page.click(\"button\")

        with sync_playwright() as playwright:
            run(playwright)
        ```

        Parameters
        ----------
        name : str
            Name of the function on the window object.
        callback : Callable
            Callback function that will be called in the Playwright's context.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.expose_binding(
                    name=name, callback=self._wrap_handler(callback)
                )
            )
        )

    def expose_function(
        self, name: str, callback: typing.Callable
    ) -> "SyncContextManager":
        """Page.expose_function

        The method adds a function called `name` on the `window` object of every frame in the page. When called, the
        function executes `callback` and returns a [Promise] which resolves to the return value of `callback`.

        If the `callback` returns a [Promise], it will be awaited.

        See `browser_context.expose_function()` for context-wide exposed function.

        **NOTE** Functions installed via `page.expose_function()` survive navigations.

        **Usage**

        An example of adding a `sha256` function to the page:

        ```py
        import hashlib
        from playwright.sync_api import sync_playwright, Playwright

        def sha256(text):
            m = hashlib.sha256()
            m.update(bytes(text, \"utf8\"))
            return m.hexdigest()

        def run(playwright: Playwright):
            webkit = playwright.webkit
            browser = webkit.launch(headless=False)
            page = browser.new_page()
            page.expose_function(\"sha256\", sha256)
            page.set_content(\"\"\"
                <script>
                  async function onClick() {
                    document.querySelector('div').textContent = await window.sha256('PLAYWRIGHT');
                  }
                </script>
                <button onclick=\"onClick()\">Click me</button>
                <div></div>
            \"\"\")
            page.click(\"button\")

        with sync_playwright() as playwright:
            run(playwright)
        ```

        Parameters
        ----------
        name : str
            Name of the function on the window object
        callback : Callable
            Callback function which will be called in Playwright's context.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.expose_function(
                    name=name, callback=self._wrap_handler(callback)
                )
            )
        )

    def fill(
        self,
        selector: str,
        value: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Page.fill

        This method waits for an element matching `selector`, waits for [actionability](https://playwright.dev/python/docs/actionability) checks,
        focuses the element, fills it and triggers an `input` event after filling. Note that you can pass an empty string
        to clear the input field.

        If the target element is not an `<input>`, `<textarea>` or `[contenteditable]` element, this method throws an
        error. However, if the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be filled
        instead.

        To send fine-grained keyboard events, use `locator.press_sequentially()`.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        value : str
            Value to fill for the `<input>`, `<textarea>` or `[contenteditable]` element.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.fill(
                selector=selector,
                value=value,
                force=force,
                noWaitAfter=no_wait_after,
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def focus(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Page.focus

        This method fetches an element with `selector` and focuses it. If there's no element matching `selector`, the
        method waits until a matching element appears in the DOM.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.focus(
                selector=selector, strict=strict, timeout=to_milliseconds(timeout)
            )
        )

    def frame(
        self,
        name: typing.Optional[str] = None,
        *,
        url: typing.Optional[
            typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]]
        ] = None,
    ) -> typing.Optional["Frame"]:
        """Page.frame

        Returns frame matching the specified criteria. Either `name` or `url` must be specified.

        **Usage**

        ```py
        frame = page.frame(name=\"frame-name\")
        ```

        ```py
        frame = page.frame(url=r\".*domain.*\")
        ```

        Parameters
        ----------
        name : Union[str, None]
            Frame name specified in the `iframe`'s `name` attribute. Optional.
        url : Union[Callable[[str], bool], Pattern[str], str, None]
            A glob pattern, regex pattern or predicate receiving frame's `url` as a [URL] object. Optional.

        Returns
        -------
        Union[Frame, None]
        """

        return mapping.from_impl_nullable(
            self._impl_obj.frame(name=name, url=self._wrap_handler(url))
        )

    def frame_locator(self, selector: typing.Optional[str] = None) -> "FrameLocator":
        """Page.frame_locator

        When working with iframes, you can create a frame locator that will enter the iframe and allow selecting elements
        in that iframe.

        When called without `selector`, the search starts in any frame on the page - the main frame or any of the iframes -
        so that you don't need to locate each iframe first. Note that the rest of the locator is resolved inside a single
        frame, just like any other locator. If it matches elements inside multiple frames, an error is thrown.

        **Usage**

        Following snippet locates element with text \"Submit\" in the iframe with id `my-frame`, like `<iframe
        id=\"my-frame\">`:

        ```py
        locator = page.frame_locator(\"#my-iframe\").get_by_text(\"Submit\")
        locator.click()
        ```

        Following snippet locates a button, either in the main frame or in one of the iframes:

        ```py
        locator = page.frame_locator().get_by_role(\"button\")
        locator.click()
        ```

        Parameters
        ----------
        selector : Union[str, None]
            A selector that matches the frame element. When not specified, locator is matched in any frame on the page.

        Returns
        -------
        FrameLocator
        """

        return mapping.from_impl(self._impl_obj.frame_locator(selector=selector))

    @property
    def frames(self) -> typing.List["Frame"]:
        """Page.frames

        An array of all frames attached to the page.

        Returns
        -------
        List[Frame]
        """
        return mapping.from_impl_list(self._impl_obj.frames)

    def get_attribute(
        self,
        selector: str,
        name: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional[str]:
        """Page.get_attribute

        Returns element attribute value.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        name : str
            Attribute name to get the value for.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.get_attribute(
                    selector=selector,
                    name=name,
                    strict=strict,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def get_by_alt_text(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Page.get_by_alt_text

        Allows locating elements by their alt text.

        **Usage**

        For example, this method will find the image by alt text \"Playwright logo\":

        ```html
        <img alt='Playwright logo'>
        ```

        ```py
        page.get_by_alt_text(\"Playwright logo\").click()
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_alt_text(text=text, exact=exact))

    def get_by_label(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Page.get_by_label

        Allows locating input elements by the text of the associated `<label>` or `aria-labelledby` element, or by the
        `aria-label` attribute.

        **Usage**

        For example, this method will find inputs by label \"Username\" and \"Password\" in the following DOM:

        ```html
        <input aria-label=\"Username\">
        <label for=\"password-input\">Password:</label>
        <input id=\"password-input\">
        ```

        ```py
        page.get_by_label(\"Username\").fill(\"john\")
        page.get_by_label(\"Password\").fill(\"secret\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_label(text=text, exact=exact))

    def get_by_placeholder(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Page.get_by_placeholder

        Allows locating input elements by the placeholder text.

        **Usage**

        For example, consider the following DOM structure.

        ```html
        <input type=\"email\" placeholder=\"name@example.com\" />
        ```

        You can fill the input after locating it by the placeholder text:

        ```py
        page.get_by_placeholder(\"name@example.com\").fill(\"playwright@microsoft.com\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.get_by_placeholder(text=text, exact=exact)
        )

    def get_by_ref(self, ref: str) -> "Locator":
        """Page.get_by_ref

        Locate element by its aria ref. Refs like `[ref=e2]` are reported by `page.aria_snapshot()` when called with the
        `\"ai\"` mode, and resolve against the latest snapshot taken in the element's frame.

        **Usage**

        Consider the following aria snapshot.

        You can locate the button by its ref:

        ```py
        page.get_by_ref(\"e2\").click()
        ```

        Parameters
        ----------
        ref : str
            Aria ref of the element, for example `e2` or `f1e3`.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_ref(ref=ref))

    def get_by_role(
        self,
        role: Literal[
            "alert",
            "alertdialog",
            "application",
            "article",
            "banner",
            "blockquote",
            "button",
            "caption",
            "cell",
            "checkbox",
            "code",
            "columnheader",
            "combobox",
            "complementary",
            "contentinfo",
            "definition",
            "deletion",
            "dialog",
            "directory",
            "document",
            "emphasis",
            "feed",
            "figure",
            "form",
            "generic",
            "grid",
            "gridcell",
            "group",
            "heading",
            "img",
            "insertion",
            "link",
            "list",
            "listbox",
            "listitem",
            "log",
            "main",
            "marquee",
            "math",
            "menu",
            "menubar",
            "menuitem",
            "menuitemcheckbox",
            "menuitemradio",
            "meter",
            "navigation",
            "none",
            "note",
            "option",
            "paragraph",
            "presentation",
            "progressbar",
            "radio",
            "radiogroup",
            "region",
            "row",
            "rowgroup",
            "rowheader",
            "scrollbar",
            "search",
            "searchbox",
            "separator",
            "slider",
            "spinbutton",
            "status",
            "strong",
            "subscript",
            "superscript",
            "switch",
            "tab",
            "table",
            "tablist",
            "tabpanel",
            "term",
            "textbox",
            "time",
            "timer",
            "toolbar",
            "tooltip",
            "tree",
            "treegrid",
            "treeitem",
        ],
        *,
        checked: typing.Optional[bool] = None,
        description: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        disabled: typing.Optional[bool] = None,
        exact: typing.Optional[bool] = None,
        expanded: typing.Optional[bool] = None,
        include_hidden: typing.Optional[bool] = None,
        level: typing.Optional[int] = None,
        name: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        pressed: typing.Optional[bool] = None,
        selected: typing.Optional[bool] = None,
    ) -> "Locator":
        """Page.get_by_role

        Allows locating elements by their [ARIA role](https://www.w3.org/TR/wai-aria-1.2/#roles),
        [ARIA attributes](https://www.w3.org/TR/wai-aria-1.2/#aria-attributes) and
        [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).

        **Usage**

        Consider the following DOM structure.

        ```html
        <h3>Sign up</h3>
        <label>
          <input type=\"checkbox\" /> Subscribe
        </label>
        <br/>
        <button>Submit</button>
        ```

        You can locate each element by its implicit role:

        ```py
        expect(page.get_by_role(\"heading\", name=\"Sign up\")).to_be_visible()

        page.get_by_role(\"checkbox\", name=\"Subscribe\").check()

        page.get_by_role(\"button\", name=re.compile(\"submit\", re.IGNORECASE)).click()
        ```

        **Details**

        Role selector **does not replace** accessibility audits and conformance tests, but rather gives early feedback
        about the ARIA guidelines.

        Many html elements have an implicitly [defined role](https://w3c.github.io/html-aam/#html-element-role-mappings)
        that is recognized by the role selector. You can find all the
        [supported roles here](https://www.w3.org/TR/wai-aria-1.2/#role_definitions). ARIA guidelines **do not recommend**
        duplicating implicit roles and attributes by setting `role` and/or `aria-*` attributes to default values.

        Parameters
        ----------
        role : Union["alert", "alertdialog", "application", "article", "banner", "blockquote", "button", "caption", "cell", "checkbox", "code", "columnheader", "combobox", "complementary", "contentinfo", "definition", "deletion", "dialog", "directory", "document", "emphasis", "feed", "figure", "form", "generic", "grid", "gridcell", "group", "heading", "img", "insertion", "link", "list", "listbox", "listitem", "log", "main", "marquee", "math", "menu", "menubar", "menuitem", "menuitemcheckbox", "menuitemradio", "meter", "navigation", "none", "note", "option", "paragraph", "presentation", "progressbar", "radio", "radiogroup", "region", "row", "rowgroup", "rowheader", "scrollbar", "search", "searchbox", "separator", "slider", "spinbutton", "status", "strong", "subscript", "superscript", "switch", "tab", "table", "tablist", "tabpanel", "term", "textbox", "time", "timer", "toolbar", "tooltip", "tree", "treegrid", "treeitem"]
            Required aria role.
        checked : Union[bool, None]
            An attribute that is usually set by `aria-checked` or native `<input type=checkbox>` controls.

            Learn more about [`aria-checked`](https://www.w3.org/TR/wai-aria-1.2/#aria-checked).
        description : Union[Pattern[str], str, None]
            Option to match the [accessible description](https://w3c.github.io/accname/#dfn-accessible-description). By
            default, matching is case-insensitive and searches for a substring, use `exact` to control this behavior.

            Learn more about [accessible description](https://w3c.github.io/accname/#dfn-accessible-description).
        disabled : Union[bool, None]
            An attribute that is usually set by `aria-disabled` or `disabled`.

            **NOTE** Unlike most other attributes, `disabled` is inherited through the DOM hierarchy. Learn more about
            [`aria-disabled`](https://www.w3.org/TR/wai-aria-1.2/#aria-disabled).

        exact : Union[bool, None]
            Whether `name` and `description` are matched exactly: case-sensitive and whole-string. Defaults to false. Ignored
            when the value is a regular expression. Note that exact match still trims whitespace.
        expanded : Union[bool, None]
            An attribute that is usually set by `aria-expanded`.

            Learn more about [`aria-expanded`](https://www.w3.org/TR/wai-aria-1.2/#aria-expanded).
        include_hidden : Union[bool, None]
            Option that controls whether hidden elements are matched. By default, only non-hidden elements, as
            [defined by ARIA](https://www.w3.org/TR/wai-aria-1.2/#tree_exclusion), are matched by role selector.

            Learn more about [`aria-hidden`](https://www.w3.org/TR/wai-aria-1.2/#aria-hidden).
        level : Union[int, None]
            A number attribute that is usually present for roles `heading`, `listitem`, `row`, `treeitem`, with default values
            for `<h1>-<h6>` elements.

            Learn more about [`aria-level`](https://www.w3.org/TR/wai-aria-1.2/#aria-level).
        name : Union[Pattern[str], str, None]
            Option to match the [accessible name](https://w3c.github.io/accname/#dfn-accessible-name). By default, matching is
            case-insensitive and searches for a substring, use `exact` to control this behavior.

            Learn more about [accessible name](https://w3c.github.io/accname/#dfn-accessible-name).
        pressed : Union[bool, None]
            An attribute that is usually set by `aria-pressed`.

            Learn more about [`aria-pressed`](https://www.w3.org/TR/wai-aria-1.2/#aria-pressed).
        selected : Union[bool, None]
            An attribute that is usually set by `aria-selected`.

            Learn more about [`aria-selected`](https://www.w3.org/TR/wai-aria-1.2/#aria-selected).

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.get_by_role(
                role=role,
                checked=checked,
                description=description,
                disabled=disabled,
                exact=exact,
                expanded=expanded,
                includeHidden=include_hidden,
                level=level,
                name=name,
                pressed=pressed,
                selected=selected,
            )
        )

    def get_by_test_id(
        self, test_id: typing.Union[str, typing.Pattern[str]]
    ) -> "Locator":
        """Page.get_by_test_id

        Locate element by the test id.

        **Usage**

        Consider the following DOM structure.

        ```html
        <button data-testid=\"directions\">Itinéraire</button>
        ```

        You can locate the element by its test id:

        ```py
        page.get_by_test_id(\"directions\").click()
        ```

        **Details**

        By default, the `data-testid` attribute is used as a test id. Use `selectors.set_test_id_attribute()` to configure
        a different test id attribute if necessary.

        Parameters
        ----------
        test_id : Union[Pattern[str], str]
            Id to locate the element by.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_test_id(testId=test_id))

    def get_by_text(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Page.get_by_text

        Allows locating elements that contain given text.

        See also `locator.filter()` that allows to match by another criteria, like an accessible role, and then filter by
        the text content.

        **Usage**

        Consider the following DOM structure:

        ```html
        <div>Hello <span>world</span></div>
        <div>Hello</div>
        ```

        You can locate by text substring, exact string, or a regular expression:

        ```py
        # Matches <span>
        page.get_by_text(\"world\")

        # Matches first <div>
        page.get_by_text(\"Hello world\")

        # Matches second <div>
        page.get_by_text(\"Hello\", exact=True)

        # Matches both <div>s
        page.get_by_text(re.compile(\"Hello\"))

        # Matches second <div>
        page.get_by_text(re.compile(\"^hello$\", re.IGNORECASE))
        ```

        **Details**

        Matching by text always normalizes whitespace, even with exact match. For example, it turns multiple spaces into
        one, turns line breaks into spaces and ignores leading and trailing whitespace.

        Input elements of the type `button` and `submit` are matched by their `value` instead of the text content. For
        example, locating by text `\"Log in\"` matches `<input type=button value=\"Log in\">`.

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_text(text=text, exact=exact))

    def get_by_title(
        self,
        text: typing.Union[str, typing.Pattern[str]],
        *,
        exact: typing.Optional[bool] = None,
    ) -> "Locator":
        """Page.get_by_title

        Allows locating elements by their title attribute.

        **Usage**

        Consider the following DOM structure.

        ```html
        <span title='Issues count'>25 issues</span>
        ```

        You can check the issues count after locating it by the title text:

        ```py
        expect(page.get_by_title(\"Issues count\")).to_have_text(\"25 issues\")
        ```

        Parameters
        ----------
        text : Union[Pattern[str], str]
            Text to locate the element for.
        exact : Union[bool, None]
            Whether to find an exact match: case-sensitive and whole-string. Default to false. Ignored when locating by a
            regular expression. Note that exact match still trims whitespace.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._impl_obj.get_by_title(text=text, exact=exact))

    def go_back(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> typing.Optional["Response"]:
        """Page.go_back

        Returns the main resource response. In case of multiple redirects, the navigation will resolve with the response of
        the last redirect. If cannot go back, returns `null`.

        Navigate to the previous page in history.

        **NOTE** **Testing Back/Forward Cache (BFCache) is not supported.** By default, Playwright disables the
        Back/Forward Cache across all browsers. Even if explicitly enabled, Playwright's internal state relies on
        network-level navigation events. Because BFCache restores unfreeze the DOM without firing these events, using
        `page.goBack()` or `page.goForward()` to trigger a BFCache restore will result in timeouts and a desynchronized
        `Page` state.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.

        Returns
        -------
        Union[Response, None]
        """

        return mapping.from_impl_nullable(
            self._sync(
                self._impl_obj.go_back(
                    timeout=to_milliseconds(timeout), waitUntil=wait_until
                )
            )
        )

    def go_forward(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> typing.Optional["Response"]:
        """Page.go_forward

        Returns the main resource response. In case of multiple redirects, the navigation will resolve with the response of
        the last redirect. If cannot go forward, returns `null`.

        Navigate to the next page in history.

        **NOTE** **Testing Back/Forward Cache (BFCache) is not supported.** By default, Playwright disables the
        Back/Forward Cache across all browsers. Even if explicitly enabled, Playwright's internal state relies on
        network-level navigation events. Because BFCache restores unfreeze the DOM without firing these events, using
        `page.goBack()` or `page.goForward()` to trigger a BFCache restore will result in timeouts and a desynchronized
        `Page` state.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.

        Returns
        -------
        Union[Response, None]
        """

        return mapping.from_impl_nullable(
            self._sync(
                self._impl_obj.go_forward(
                    timeout=to_milliseconds(timeout), waitUntil=wait_until
                )
            )
        )

    def goto(
        self,
        url: str,
        *,
        referer: typing.Optional[str] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> typing.Optional["Response"]:
        """Page.goto

        Returns the main resource response. In case of multiple redirects, the navigation will resolve with the first
        non-redirect response.

        The method will throw an error if:
        - there's an SSL error (e.g. in case of self-signed certificates).
        - target URL is invalid.
        - the `timeout` is exceeded during navigation.
        - the remote server does not respond or is unreachable.
        - the main resource failed to load.

        The method will not throw an error when any valid HTTP status code is returned by the remote server, including 404
        \"Not Found\" and 500 \"Internal Server Error\".  The status code for such responses can be retrieved by calling
        `response.status`.

        **NOTE** The method either throws an error or returns a main resource response. The only exceptions are navigation
        to `about:blank` or navigation to the same URL with a different hash, which would succeed and return `null`.

        **NOTE** Headless mode doesn't support navigation to a PDF document. See the
        [upstream issue](https://bugs.chromium.org/p/chromium/issues/detail?id=761295).

        Parameters
        ----------
        url : str
            URL to navigate page to. The url should include scheme, e.g. `https://`. When a `base_url` via the context options
            was provided and the passed URL is a path, it gets merged via the
            [`new URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor.
        referer : Union[str, None]
            Referer header value. If provided it will take preference over the referer header value set by
            `page.set_extra_http_headers()`.
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.

        Returns
        -------
        Union[Response, None]
        """

        return mapping.from_impl_nullable(
            self._sync(
                self._impl_obj.goto(
                    url=url,
                    referer=referer,
                    timeout=to_milliseconds(timeout),
                    waitUntil=wait_until,
                )
            )
        )

    def hide_highlight(self) -> None:
        """Page.hide_highlight

        Hide all locator highlight overlays previously added by `locator.highlight()` on this page.
        """

        self._sync(self._impl_obj.hide_highlight())

    def hover(
        self,
        selector: str,
        *,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Page.hover

        This method hovers over an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to hover over the center of the element, or the specified `position`.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.hover(
                selector=selector,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def inner_html(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Page.inner_html

        Returns `element.innerHTML`.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.inner_html(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def inner_text(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Page.inner_text

        Returns `element.innerText`.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.inner_text(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def input_value(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> str:
        """Page.input_value

        Returns `input.value` for the selected `<input>` or `<textarea>` or `<select>` element.

        Throws for non-input elements. However, if the element is inside the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), returns the value of the
        control.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.input_value(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_checked(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Page.is_checked

        Returns whether the element is checked. Throws if the element is not a checkbox or radio input.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_checked(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_closed(self) -> bool:
        """Page.is_closed

        Indicates that the page has been closed.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._impl_obj.is_closed())

    def is_disabled(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Page.is_disabled

        Returns whether the element is disabled, the opposite of [enabled](https://playwright.dev/python/docs/actionability#enabled).

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_disabled(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_editable(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Page.is_editable

        Returns whether the element is [editable](https://playwright.dev/python/docs/actionability#editable).

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_editable(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_enabled(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Page.is_enabled

        Returns whether the element is [enabled](https://playwright.dev/python/docs/actionability#enabled).

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_enabled(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_hidden(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Page.is_hidden

        Returns whether the element is hidden, the opposite of [visible](https://playwright.dev/python/docs/actionability#visible).  `selector` that
        does not match any elements is considered hidden.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Deprecated: This option is ignored. `page.is_hidden()` does not wait for the↵element to become hidden and returns immediately.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_hidden(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def is_visible(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> bool:
        """Page.is_visible

        Returns whether the element is [visible](https://playwright.dev/python/docs/actionability#visible). `selector` that does not match any elements
        is considered not visible.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Deprecated: This option is ignored. `page.is_visible()` does not wait↵for the element to become visible and returns immediately.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.is_visible(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    @property
    def keyboard(self) -> "Keyboard":
        """Page.keyboard

        Returns
        -------
        Keyboard
        """
        return mapping.from_impl(self._impl_obj.keyboard)

    @property
    def local_storage(self) -> "WebStorage":
        """Page.local_storage

        Provides access to the page's `localStorage` for the current origin. See `WebStorage`.

        Returns
        -------
        WebStorage
        """
        return mapping.from_impl(self._impl_obj.local_storage)

    def locator(
        self,
        selector: str,
        *,
        has: typing.Optional["Locator"] = None,
        has_not: typing.Optional["Locator"] = None,
        has_not_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
        has_text: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> "Locator":
        """Page.locator

        The method returns an element locator that can be used to perform actions on this page / frame. Locator is resolved
        to the element immediately before performing an action, so a series of actions on the same locator can in fact be
        performed on different DOM elements. That would happen if the DOM structure between those actions has changed.

        [Learn more about locators](https://playwright.dev/python/docs/locators).

        Parameters
        ----------
        selector : str
            A selector to use when resolving DOM element.
        has : Union[Locator, None]
            Narrows down the results of the method to those which contain elements matching this relative locator. For example,
            `article` that has `text=Playwright` matches `<article><div>Playwright</div></article>`.

            Inner locator **must be relative** to the outer locator and is queried starting with the outer locator match, not
            the document root. For example, you can find `content` that has `div` in
            `<article><content><div>Playwright</div></content></article>`. However, looking for `content` that has `article
            div` will fail, because the inner locator must be relative and should not use any elements outside the `content`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not : Union[Locator, None]
            Matches elements that do not contain an element that matches an inner locator. Inner locator is queried against the
            outer one. For example, `article` that does not have `div` matches `<article><span>Playwright</span></article>`.

            Note that outer and inner locators must belong to the same frame. Inner locator must not contain `FrameLocator`s.
        has_not_text : Union[Pattern[str], str, None]
            Matches elements that do not contain specified text somewhere inside, possibly in a child or a descendant element.
            When passed a [string], matching is case-insensitive and searches for a substring.
        has_text : Union[Pattern[str], str, None]
            Matches elements containing specified text somewhere inside, possibly in a child or a descendant element. When
            passed a [string], matching is case-insensitive and searches for a substring. For example, `"Playwright"` matches
            `<article><div>Playwright</div></article>`.

        Returns
        -------
        Locator
        """

        return mapping.from_impl(
            self._impl_obj.locator(
                selector=selector,
                has=has._impl_obj if has else None,
                hasNot=has_not._impl_obj if has_not else None,
                hasNotText=has_not_text,
                hasText=has_text,
            )
        )

    @property
    def main_frame(self) -> "Frame":
        """Page.main_frame

        The page's main frame. Page is guaranteed to have a main frame which persists during navigations.

        Returns
        -------
        Frame
        """
        return mapping.from_impl(self._impl_obj.main_frame)

    @property
    def mouse(self) -> "Mouse":
        """Page.mouse

        Returns
        -------
        Mouse
        """
        return mapping.from_impl(self._impl_obj.mouse)

    @typing.overload
    def on(self, event: Literal["close"], f: typing.Callable[["Page"], "None"]) -> None:
        """
        Emitted when the page closes."""

    @typing.overload
    def on(
        self, event: Literal["console"], f: typing.Callable[["ConsoleMessage"], "None"]
    ) -> None:
        """
        Emitted when JavaScript within the page calls one of console API methods, e.g. `console.log` or `console.dir`.

        The arguments passed into `console.log` are available on the `ConsoleMessage` event handler argument.

        **Usage**

        ```py
        def print_args(msg):
            for arg in msg.args:
                print(arg.json_value())

        page.on(\"console\", print_args)
        page.evaluate(\"console.log('hello', 5, { foo: 'bar' })\")
        ```"""

    @typing.overload
    def on(self, event: Literal["crash"], f: typing.Callable[["Page"], "None"]) -> None:
        """
        Emitted when the page crashes. Browser pages might crash if they try to allocate too much memory. When the page
        crashes, ongoing and subsequent operations will throw.

        The most common way to deal with crashes is to catch an exception:

        ```py
        try:
            # crash might happen during a click.
            page.click(\"button\")
            # or while waiting for an event.
            page.wait_for_event(\"popup\")
        except Error as e:
            pass
            # when the page crashes, exception message contains \"crash\".
        ```"""

    @typing.overload
    def on(
        self, event: Literal["dialog"], f: typing.Callable[["Dialog"], "None"]
    ) -> None:
        """
        Emitted when a JavaScript dialog appears, such as `alert`, `prompt`, `confirm` or `beforeunload`. Listener **must**
        either `dialog.accept()` or `dialog.dismiss()` the dialog - otherwise the page will
        [freeze](https://developer.mozilla.org/en-US/docs/Web/JavaScript/EventLoop#never_blocking) waiting for the dialog,
        and actions like click will never finish.

        **Usage**

        ```python
        page.on(\"dialog\", lambda dialog: dialog.accept())
        ```

        **NOTE** When no `page.on('dialog')` or `browser_context.on('dialog')` listeners are present, all dialogs are
        automatically dismissed."""

    @typing.overload
    def on(
        self, event: Literal["dialogclosed"], f: typing.Callable[["Dialog"], "None"]
    ) -> None:
        """
        Emitted when a JavaScript dialog has been closed, either by `dialog.accept()`, by `dialog.dismiss()`, or manually
        by the user in the headed browser."""

    @typing.overload
    def on(
        self, event: Literal["domcontentloaded"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when the JavaScript
        [`DOMContentLoaded`](https://developer.mozilla.org/en-US/docs/Web/Events/DOMContentLoaded) event is dispatched.
        """

    @typing.overload
    def on(
        self, event: Literal["download"], f: typing.Callable[["Download"], "None"]
    ) -> None:
        """
        Emitted when attachment download started. User can access basic file operations on downloaded content via the
        passed `Download` instance."""

    @typing.overload
    def on(
        self, event: Literal["filechooser"], f: typing.Callable[["FileChooser"], "None"]
    ) -> None:
        """
        Emitted when a file chooser is supposed to appear, such as after clicking the  `<input type=file>`. Playwright can
        respond to it via setting the input files using `file_chooser.set_files()` that can be uploaded after that.

        ```py
        page.on(\"filechooser\", lambda file_chooser: file_chooser.set_files(\"/tmp/myfile.pdf\"))
        ```"""

    @typing.overload
    def on(
        self, event: Literal["frameattached"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is attached."""

    @typing.overload
    def on(
        self, event: Literal["framedetached"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is detached."""

    @typing.overload
    def on(
        self, event: Literal["framenavigated"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is navigated to a new url."""

    @typing.overload
    def on(self, event: Literal["load"], f: typing.Callable[["Page"], "None"]) -> None:
        """
        Emitted when the JavaScript [`load`](https://developer.mozilla.org/en-US/docs/Web/Events/load) event is dispatched.
        """

    @typing.overload
    def on(
        self, event: Literal["pageerror"], f: typing.Callable[["Error"], "None"]
    ) -> None:
        """
        Emitted when an uncaught exception happens within the page.

        ```py
        # Log all uncaught errors to the terminal
        page.on(\"pageerror\", lambda exc: print(f\"uncaught exception: {exc}\"))

        # Navigate to a page with an exception.
        page.goto(\"data:text/html,<script>throw new Error('test')</script>\")
        ```"""

    @typing.overload
    def on(self, event: Literal["popup"], f: typing.Callable[["Page"], "None"]) -> None:
        """
        Emitted when the page opens a new tab or window. This event is emitted in addition to the
        `browser_context.on('page')`, but only for popups relevant to this page.

        The earliest moment that page is available is when it has navigated to the initial url. For example, when opening a
        popup with `window.open('http://example.com')`, this event will fire when the network request to
        \"http://example.com\" is done and its response has started loading in the popup. If you would like to route/listen
        to this network request, use `browser_context.route()` and `browser_context.on('request')` respectively instead of
        similar methods on the `Page`.

        ```py
        with page.expect_event(\"popup\") as page_info:
            page.get_by_text(\"open the popup\").click()
        popup = page_info.value
        print(popup.evaluate(\"location.href\"))
        ```

        **NOTE** Use `page.wait_for_load_state()` to wait until the page gets to a particular state (you should not need it
        in most cases)."""

    @typing.overload
    def on(
        self, event: Literal["request"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a page issues a request. The [request] object is read-only. In order to intercept and mutate requests,
        see `page.route()` or `browser_context.route()`."""

    @typing.overload
    def on(
        self, event: Literal["requestfailed"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request fails, for example by timing out.

        ```python
        page.on(\"requestfailed\", lambda request: print(request.url + \" \" + request.failure.error_text))
        ```

        **NOTE** HTTP Error responses, such as 404 or 503, are still successful responses from HTTP standpoint, so request
        will complete with `page.on('requestfinished')` event and not with `page.on('requestfailed')`. A request will only
        be considered failed when the client cannot get an HTTP response from the server, e.g. due to network error
        net::ERR_FAILED."""

    @typing.overload
    def on(
        self, event: Literal["requestfinished"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request finishes successfully after downloading the response body. For a successful response, the
        sequence of events is `request`, `response` and `requestfinished`."""

    @typing.overload
    def on(
        self, event: Literal["response"], f: typing.Callable[["Response"], "None"]
    ) -> None:
        """
        Emitted when [response] status and headers are received for a request. For a successful response, the sequence of
        events is `request`, `response` and `requestfinished`."""

    @typing.overload
    def on(
        self, event: Literal["websocket"], f: typing.Callable[["WebSocket"], "None"]
    ) -> None:
        """
        Emitted when `WebSocket` request is sent."""

    @typing.overload
    def on(
        self, event: Literal["worker"], f: typing.Callable[["Worker"], "None"]
    ) -> None:
        """
        Emitted when a dedicated [WebWorker](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API) is spawned
        by the page."""

    def on(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().on(event=event, f=f)

    @typing.overload
    def once(
        self, event: Literal["close"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when the page closes."""

    @typing.overload
    def once(
        self, event: Literal["console"], f: typing.Callable[["ConsoleMessage"], "None"]
    ) -> None:
        """
        Emitted when JavaScript within the page calls one of console API methods, e.g. `console.log` or `console.dir`.

        The arguments passed into `console.log` are available on the `ConsoleMessage` event handler argument.

        **Usage**

        ```py
        def print_args(msg):
            for arg in msg.args:
                print(arg.json_value())

        page.on(\"console\", print_args)
        page.evaluate(\"console.log('hello', 5, { foo: 'bar' })\")
        ```"""

    @typing.overload
    def once(
        self, event: Literal["crash"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when the page crashes. Browser pages might crash if they try to allocate too much memory. When the page
        crashes, ongoing and subsequent operations will throw.

        The most common way to deal with crashes is to catch an exception:

        ```py
        try:
            # crash might happen during a click.
            page.click(\"button\")
            # or while waiting for an event.
            page.wait_for_event(\"popup\")
        except Error as e:
            pass
            # when the page crashes, exception message contains \"crash\".
        ```"""

    @typing.overload
    def once(
        self, event: Literal["dialog"], f: typing.Callable[["Dialog"], "None"]
    ) -> None:
        """
        Emitted when a JavaScript dialog appears, such as `alert`, `prompt`, `confirm` or `beforeunload`. Listener **must**
        either `dialog.accept()` or `dialog.dismiss()` the dialog - otherwise the page will
        [freeze](https://developer.mozilla.org/en-US/docs/Web/JavaScript/EventLoop#never_blocking) waiting for the dialog,
        and actions like click will never finish.

        **Usage**

        ```python
        page.on(\"dialog\", lambda dialog: dialog.accept())
        ```

        **NOTE** When no `page.on('dialog')` or `browser_context.on('dialog')` listeners are present, all dialogs are
        automatically dismissed."""

    @typing.overload
    def once(
        self, event: Literal["dialogclosed"], f: typing.Callable[["Dialog"], "None"]
    ) -> None:
        """
        Emitted when a JavaScript dialog has been closed, either by `dialog.accept()`, by `dialog.dismiss()`, or manually
        by the user in the headed browser."""

    @typing.overload
    def once(
        self, event: Literal["domcontentloaded"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when the JavaScript
        [`DOMContentLoaded`](https://developer.mozilla.org/en-US/docs/Web/Events/DOMContentLoaded) event is dispatched.
        """

    @typing.overload
    def once(
        self, event: Literal["download"], f: typing.Callable[["Download"], "None"]
    ) -> None:
        """
        Emitted when attachment download started. User can access basic file operations on downloaded content via the
        passed `Download` instance."""

    @typing.overload
    def once(
        self, event: Literal["filechooser"], f: typing.Callable[["FileChooser"], "None"]
    ) -> None:
        """
        Emitted when a file chooser is supposed to appear, such as after clicking the  `<input type=file>`. Playwright can
        respond to it via setting the input files using `file_chooser.set_files()` that can be uploaded after that.

        ```py
        page.on(\"filechooser\", lambda file_chooser: file_chooser.set_files(\"/tmp/myfile.pdf\"))
        ```"""

    @typing.overload
    def once(
        self, event: Literal["frameattached"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is attached."""

    @typing.overload
    def once(
        self, event: Literal["framedetached"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is detached."""

    @typing.overload
    def once(
        self, event: Literal["framenavigated"], f: typing.Callable[["Frame"], "None"]
    ) -> None:
        """
        Emitted when a frame is navigated to a new url."""

    @typing.overload
    def once(
        self, event: Literal["load"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when the JavaScript [`load`](https://developer.mozilla.org/en-US/docs/Web/Events/load) event is dispatched.
        """

    @typing.overload
    def once(
        self, event: Literal["pageerror"], f: typing.Callable[["Error"], "None"]
    ) -> None:
        """
        Emitted when an uncaught exception happens within the page.

        ```py
        # Log all uncaught errors to the terminal
        page.on(\"pageerror\", lambda exc: print(f\"uncaught exception: {exc}\"))

        # Navigate to a page with an exception.
        page.goto(\"data:text/html,<script>throw new Error('test')</script>\")
        ```"""

    @typing.overload
    def once(
        self, event: Literal["popup"], f: typing.Callable[["Page"], "None"]
    ) -> None:
        """
        Emitted when the page opens a new tab or window. This event is emitted in addition to the
        `browser_context.on('page')`, but only for popups relevant to this page.

        The earliest moment that page is available is when it has navigated to the initial url. For example, when opening a
        popup with `window.open('http://example.com')`, this event will fire when the network request to
        \"http://example.com\" is done and its response has started loading in the popup. If you would like to route/listen
        to this network request, use `browser_context.route()` and `browser_context.on('request')` respectively instead of
        similar methods on the `Page`.

        ```py
        with page.expect_event(\"popup\") as page_info:
            page.get_by_text(\"open the popup\").click()
        popup = page_info.value
        print(popup.evaluate(\"location.href\"))
        ```

        **NOTE** Use `page.wait_for_load_state()` to wait until the page gets to a particular state (you should not need it
        in most cases)."""

    @typing.overload
    def once(
        self, event: Literal["request"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a page issues a request. The [request] object is read-only. In order to intercept and mutate requests,
        see `page.route()` or `browser_context.route()`."""

    @typing.overload
    def once(
        self, event: Literal["requestfailed"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request fails, for example by timing out.

        ```python
        page.on(\"requestfailed\", lambda request: print(request.url + \" \" + request.failure.error_text))
        ```

        **NOTE** HTTP Error responses, such as 404 or 503, are still successful responses from HTTP standpoint, so request
        will complete with `page.on('requestfinished')` event and not with `page.on('requestfailed')`. A request will only
        be considered failed when the client cannot get an HTTP response from the server, e.g. due to network error
        net::ERR_FAILED."""

    @typing.overload
    def once(
        self, event: Literal["requestfinished"], f: typing.Callable[["Request"], "None"]
    ) -> None:
        """
        Emitted when a request finishes successfully after downloading the response body. For a successful response, the
        sequence of events is `request`, `response` and `requestfinished`."""

    @typing.overload
    def once(
        self, event: Literal["response"], f: typing.Callable[["Response"], "None"]
    ) -> None:
        """
        Emitted when [response] status and headers are received for a request. For a successful response, the sequence of
        events is `request`, `response` and `requestfinished`."""

    @typing.overload
    def once(
        self, event: Literal["websocket"], f: typing.Callable[["WebSocket"], "None"]
    ) -> None:
        """
        Emitted when `WebSocket` request is sent."""

    @typing.overload
    def once(
        self, event: Literal["worker"], f: typing.Callable[["Worker"], "None"]
    ) -> None:
        """
        Emitted when a dedicated [WebWorker](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API) is spawned
        by the page."""

    def once(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().once(event=event, f=f)

    def opener(self) -> typing.Optional["Page"]:
        """Page.opener

        Returns the opener for popup pages and `null` for others. If the opener has been closed already the returns `null`.

        Returns
        -------
        Union[Page, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.opener()))

    def page_errors(
        self, *, filter: typing.Optional[Literal["all", "since-navigation"]] = None
    ) -> typing.List["Error"]:
        """Page.page_errors

        Returns up to (currently) 200 last page errors from this page. See `page.on('pageerror')` for more details.

        Parameters
        ----------
        filter : Union["all", "since-navigation", None]
            Controls which errors are returned:

        Returns
        -------
        List[Error]
        """

        return mapping.from_impl_list(
            self._sync(self._impl_obj.page_errors(filter=filter))
        )

    def pause(self) -> None:
        """Page.pause

        Pauses script execution. Playwright will stop executing the script and wait for the user to either press the
        'Resume' button in the page overlay or to call `playwright.resume()` in the DevTools console.

        User can inspect selectors or perform manual steps while paused. Resume will continue running the original script
        from the place it was paused.

        **NOTE** This method requires Playwright to be started in a headed mode, with a falsy `headless` option.
        """

        self._sync(self._impl_obj.pause())

    def pdf(
        self,
        *,
        display_header_footer: typing.Optional[bool] = None,
        footer_template: typing.Optional[str] = None,
        format: typing.Optional[str] = None,
        header_template: typing.Optional[str] = None,
        height: typing.Optional[typing.Union[str, float]] = None,
        landscape: typing.Optional[bool] = None,
        margin: typing.Optional[PdfMargins] = None,
        outline: typing.Optional[bool] = None,
        page_ranges: typing.Optional[str] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        prefer_css_page_size: typing.Optional[bool] = None,
        print_background: typing.Optional[bool] = None,
        scale: typing.Optional[float] = None,
        tagged: typing.Optional[bool] = None,
        width: typing.Optional[typing.Union[str, float]] = None,
    ) -> bytes:
        """Page.pdf

        Returns the PDF buffer.

        `page.pdf()` generates a pdf of the page with `print` css media. To generate a pdf with `screen` media, call
        `page.emulate_media()` before calling `page.pdf()`:

        **NOTE** By default, `page.pdf()` generates a pdf with modified colors for printing. Use the
        [`-webkit-print-color-adjust`](https://developer.mozilla.org/en-US/docs/Web/CSS/-webkit-print-color-adjust)
        property to force rendering of exact colors.

        **Usage**

        ```py
        # generates a pdf with \"screen\" media type.
        page.emulate_media(media=\"screen\")
        page.pdf(path=\"page.pdf\")
        ```

        The `width`, `height`, and `margin` options accept values labeled with units. Unlabeled values are treated as
        pixels.

        A few examples:
        - `page.pdf({width: 100})` - prints with width set to 100 pixels
        - `page.pdf({width: '100px'})` - prints with width set to 100 pixels
        - `page.pdf({width: '10cm'})` - prints with width set to 10 centimeters.

        All possible units are:
        - `px` - pixel
        - `in` - inch
        - `cm` - centimeter
        - `mm` - millimeter

        The `format` options are:
        - `Letter`: 8.5in x 11in
        - `Legal`: 8.5in x 14in
        - `Tabloid`: 11in x 17in
        - `Ledger`: 17in x 11in
        - `A0`: 33.1in x 46.8in
        - `A1`: 23.4in x 33.1in
        - `A2`: 16.54in x 23.4in
        - `A3`: 11.7in x 16.54in
        - `A4`: 8.27in x 11.7in
        - `A5`: 5.83in x 8.27in
        - `A6`: 4.13in x 5.83in

        **NOTE** `header_template` and `footer_template` markup have the following limitations: > 1. Script tags inside
        templates are not evaluated. > 2. Page styles are not visible inside templates.

        Parameters
        ----------
        display_header_footer : Union[bool, None]
            Display header and footer. Defaults to `false`.
        footer_template : Union[str, None]
            HTML template for the print footer. Should use the same format as the `header_template`.
        format : Union[str, None]
            Paper format. If set, takes priority over `width` or `height` options. Defaults to 'Letter'.
        header_template : Union[str, None]
            HTML template for the print header. Should be valid HTML markup with following classes used to inject printing
            values into them:
            - `'date'` formatted print date
            - `'title'` document title
            - `'url'` document location
            - `'pageNumber'` current page number
            - `'totalPages'` total pages in the document
        height : Union[float, str, None]
            Paper height, accepts values labeled with units.
        landscape : Union[bool, None]
            Paper orientation. Defaults to `false`.
        margin : Union[{top: Union[float, str, None], right: Union[float, str, None], bottom: Union[float, str, None], left: Union[float, str, None]}, None]
            Paper margins, defaults to none.
        outline : Union[bool, None]
            Whether or not to embed the document outline into the PDF. Defaults to `false`.
        page_ranges : Union[str, None]
            Paper ranges to print, e.g., '1-5, 8, 11-13'. Defaults to the empty string, which means print all pages.
        path : Union[pathlib.Path, str, None]
            The file path to save the PDF to. If `path` is a relative path, then it is resolved relative to the current working
            directory. If no path is provided, the PDF won't be saved to the disk.
        prefer_css_page_size : Union[bool, None]
            Give any CSS `@page` size declared in the page priority over what is declared in `width` and `height` or `format`
            options. Defaults to `false`, which will scale the content to fit the paper size.
        print_background : Union[bool, None]
            Print background graphics. Defaults to `false`.
        scale : Union[float, None]
            Scale of the webpage rendering. Defaults to `1`. Scale amount must be between 0.1 and 2.
        tagged : Union[bool, None]
            Whether or not to generate tagged (accessible) PDF. Defaults to `false`.
        width : Union[float, str, None]
            Paper width, accepts values labeled with units.

        Returns
        -------
        bytes
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.pdf(
                    displayHeaderFooter=display_header_footer,
                    footerTemplate=footer_template,
                    format=format,
                    headerTemplate=header_template,
                    height=height,
                    landscape=landscape,
                    margin=margin,
                    outline=outline,
                    pageRanges=page_ranges,
                    path=path,
                    preferCSSPageSize=prefer_css_page_size,
                    printBackground=print_background,
                    scale=scale,
                    tagged=tagged,
                    width=width,
                )
            )
        )

    def pick_locator(self) -> "Locator":
        """Page.pick_locator

        Enters pick locator mode where hovering over page elements highlights them and shows the corresponding locator.
        Once the user clicks an element, the mode is deactivated and the `Locator` for the picked element is returned.

        **Usage**

        ```py
        locator = page.pick_locator()
        print(locator)
        ```

        Returns
        -------
        Locator
        """

        return mapping.from_impl(self._sync(self._impl_obj.pick_locator()))

    def press(
        self,
        selector: str,
        key: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Page.press

        Focuses the element, and then uses `keyboard.down()` and `keyboard.up()`.

        `key` can specify the intended
        [keyboardEvent.key](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key) value or a single character
        to generate the text for. A superset of the `key` values can be found
        [here](https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/key/Key_Values). Examples of the keys are:

        `F1` - `F12`, `Digit0`- `Digit9`, `KeyA`- `KeyZ`, `Backquote`, `Minus`, `Equal`, `Backslash`, `Backspace`, `Tab`,
        `Delete`, `Escape`, `ArrowDown`, `End`, `Enter`, `Home`, `Insert`, `PageDown`, `PageUp`, `ArrowRight`, `ArrowUp`,
        etc.

        Following modification shortcuts are also supported: `Shift`, `Control`, `Alt`, `Meta`, `ShiftLeft`,
        `ControlOrMeta`. `ControlOrMeta` resolves to `Control` on Windows and Linux and to `Meta` on macOS.

        Holding down `Shift` will type the text that corresponds to the `key` in the upper case.

        If `key` is a single character, it is case-sensitive, so the values `a` and `A` will generate different respective
        texts.

        Shortcuts such as `key: \"Control+o\"`, `key: \"Control++` or `key: \"Control+Shift+T\"` are supported as well. When
        specified with the modifier, modifier is pressed and being held while the subsequent key is being pressed.

        **Usage**

        ```py
        page = browser.new_page()
        page.goto(\"https://keycode.info\")
        page.press(\"body\", \"A\")
        page.screenshot(path=\"a.png\")
        page.press(\"body\", \"ArrowLeft\")
        page.screenshot(path=\"arrow_left.png\")
        page.press(\"body\", \"Shift+O\")
        page.screenshot(path=\"o.png\")
        browser.close()
        ```

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        key : str
            Name of the key to press or a character to generate, such as `ArrowLeft` or `a`.
        delay : Union[float, None]
            Time to wait between `keydown` and `keyup` in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            Actions that initiate navigations are waiting for these navigations to happen and for pages to start loading. You
            can opt out of waiting via setting this flag. You would only need this option in the exceptional cases such as
            navigating to inaccessible pages. Defaults to `false`.
            Deprecated: This option will default to `true` in the future.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.press(
                selector=selector,
                key=key,
                delay=delay,
                noWaitAfter=no_wait_after,
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def query_selector(
        self, selector: str, *, strict: typing.Optional[bool] = None
    ) -> typing.Optional["ElementHandle"]:
        """Page.query_selector

        The method finds an element matching the specified selector within the page. If no elements match the selector, the
        return value resolves to `null`. To wait for an element on the page, use `locator.wait_for()`.

        Parameters
        ----------
        selector : str
            A selector to query for.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.

        Returns
        -------
        Union[ElementHandle, None]
        """

        return mapping.from_impl_nullable(
            self._sync(self._impl_obj.query_selector(selector=selector, strict=strict))
        )

    def query_selector_all(self, selector: str) -> typing.List["ElementHandle"]:
        """Page.query_selector_all

        The method finds all elements matching the specified selector within the page. If no elements match the selector,
        the return value resolves to `[]`.

        Parameters
        ----------
        selector : str
            A selector to query for.

        Returns
        -------
        List[ElementHandle]
        """

        return mapping.from_impl_list(
            self._sync(self._impl_obj.query_selector_all(selector=selector))
        )

    def reload(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> typing.Optional["Response"]:
        """Page.reload

        This method reloads the current page, in the same way as if the user had triggered a browser refresh. Returns the
        main resource response. In case of multiple redirects, the navigation will resolve with the response of the last
        redirect.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.

        Returns
        -------
        Union[Response, None]
        """

        return mapping.from_impl_nullable(
            self._sync(
                self._impl_obj.reload(
                    timeout=to_milliseconds(timeout), waitUntil=wait_until
                )
            )
        )

    def remove_locator_handler(self, locator: "Locator") -> None:
        """Page.remove_locator_handler

        Removes all locator handlers added by `page.add_locator_handler()` for a specific locator.

        Parameters
        ----------
        locator : Locator
            Locator passed to `page.add_locator_handler()`.
        """

        self._sync(self._impl_obj.remove_locator_handler(locator=locator._impl_obj))

    @property
    def request(self) -> "APIRequestContext":
        """Page.request

        API testing helper associated with this page. This method returns the same instance as `browser_context.request` on
        the page's context. See `browser_context.request` for more details.

        Returns
        -------
        APIRequestContext
        """
        return mapping.from_impl(self._impl_obj.request)

    def request_gc(self) -> None:
        """Page.request_gc

        Request the page to perform garbage collection. Note that there is no guarantee that all unreachable objects will
        be collected.

        This is useful to help detect memory leaks. For example, if your page has a large object `'suspect'` that might be
        leaked, you can check that it does not leak by using a
        [`WeakRef`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/WeakRef).

        ```py
        # 1. In your page, save a WeakRef for the \"suspect\".
        page.evaluate(\"globalThis.suspectWeakRef = new WeakRef(suspect)\")
        # 2. Request garbage collection.
        page.request_gc()
        # 3. Check that weak ref does not deref to the original object.
        assert page.evaluate(\"!globalThis.suspectWeakRef.deref()\")
        ```
        """

        self._sync(self._impl_obj.request_gc())

    def requests(self) -> typing.List["Request"]:
        """Page.requests

        Returns up to (currently) 100 last network request from this page. See `page.on('request')` for more details.

        Returned requests should be accessed immediately, otherwise they might be collected to prevent unbounded memory
        growth as new requests come in. Once collected, retrieving most information about the request is impossible.

        Note that requests reported through the `page.on('request')` request are not collected, so there is a trade off
        between efficient memory usage with `page.requests()` and the amount of available information reported through
        `page.on('request')`.

        Returns
        -------
        List[Request]
        """

        return mapping.from_impl_list(self._sync(self._impl_obj.requests()))

    def route(
        self,
        url: typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]],
        handler: typing.Union[
            typing.Callable[["Route"], typing.Any],
            typing.Callable[["Route", "Request"], typing.Any],
        ],
        *,
        times: typing.Optional[int] = None,
    ) -> "SyncContextManager":
        """Page.route

        Routing provides the capability to modify network requests that are made by a page.

        Once routing is enabled, every request matching the url pattern will stall unless it's continued, fulfilled or
        aborted.

        **NOTE** The handler will only be called for the first url if the response is a redirect.

        **NOTE** `page.route()` will not intercept requests intercepted by Service Worker. See
        [this](https://github.com/microsoft/playwright/issues/1090) issue. We recommend disabling Service Workers when
        using request interception by setting `service_workers` to `'block'`.

        **NOTE** `page.route()` will not intercept the first request of a popup page. Use `browser_context.route()`
        instead.

        **Usage**

        An example of a naive handler that aborts all image requests:

        ```py
        page = browser.new_page()
        page.route(\"**/*.{png,jpg,jpeg}\", lambda route: route.abort())
        page.goto(\"https://example.com\")
        browser.close()
        ```

        or the same snippet using a regex pattern instead:

        ```py
        page = browser.new_page()
        page.route(re.compile(r\"(\\.png$)|(\\.jpg$)\"), lambda route: route.abort())
        page.goto(\"https://example.com\")
        browser.close()
        ```

        It is possible to examine the request to decide the route action. For example, mocking all requests that contain
        some post data, and leaving all other requests as is:

        ```py
        def handle_route(route: Route):
          if (\"my-string\" in route.request.post_data):
            route.fulfill(body=\"mocked-data\")
          else:
            route.continue_()
        page.route(\"/api/**\", handle_route)
        ```

        If a request matches multiple registered routes, the most recently registered route takes precedence.

        Page routes take precedence over browser context routes (set up with `browser_context.route()`) when request
        matches both handlers.

        To remove a route with its handler you can use `page.unroute()`.

        **NOTE** Enabling routing disables http cache.

        Parameters
        ----------
        url : Union[Callable[[str], bool], Pattern[str], str]
            A glob pattern, regex pattern, or predicate that receives a [URL] to match during routing. If `base_url` is set in
            the context options and the provided URL is a string that does not start with `*`, it is resolved using the
            [`new URL()`](https://developer.mozilla.org/en-US/docs/Web/API/URL/URL) constructor.
        handler : Union[Callable[[Route, Request], Any], Callable[[Route], Any]]
            handler function to route the request.
        times : Union[int, None]
            How often a route should be used. By default it will be used every time.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.route(
                    url=self._wrap_handler(url),
                    handler=self._wrap_handler(handler),
                    times=times,
                )
            )
        )

    def route_from_har(
        self,
        har: typing.Union[str, pathlib.Path],
        *,
        not_found: typing.Optional[Literal["abort", "fallback"]] = None,
        update: typing.Optional[bool] = None,
        update_content: typing.Optional[Literal["attach", "embed"]] = None,
        update_mode: typing.Optional[Literal["full", "minimal"]] = None,
        url: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> None:
        """Page.route_from_har

        If specified the network requests that are made in the page will be served from the HAR file. Read more about
        [Replaying from HAR](https://playwright.dev/python/docs/mock#replaying-from-har).

        Playwright will not serve requests intercepted by Service Worker from the HAR file. See
        [this](https://github.com/microsoft/playwright/issues/1090) issue. We recommend disabling Service Workers when
        using request interception by setting `service_workers` to `'block'`.

        Parameters
        ----------
        har : Union[pathlib.Path, str]
            Path to a [HAR](http://www.softwareishard.com/blog/har-12-spec) file with prerecorded network data. If `path` is a
            relative path, then it is resolved relative to the current working directory.
        not_found : Union["abort", "fallback", None]
            - If set to 'abort' any request not found in the HAR file will be aborted.
            - If set to 'fallback' missing requests will be sent to the network.

            Defaults to abort.
        update : Union[bool, None]
            If specified, updates the given HAR with the actual network information instead of serving from file. The file is
            written to disk when `browser_context.close()` is called.
        update_content : Union["attach", "embed", None]
            Optional setting to control resource content management. If `attach` is specified, resources are persisted as
            separate files or entries in the ZIP archive. If `embed` is specified, content is stored inline the HAR file.
        update_mode : Union["full", "minimal", None]
            When set to `minimal`, only record information necessary for routing from HAR. This omits sizes, timing, page,
            cookies, security and other types of HAR information that are not used when replaying from HAR. Defaults to
            `minimal`.
        url : Union[Pattern[str], str, None]
            A glob pattern, regular expression or predicate to match the request URL. Only requests with URL matching the
            pattern will be served from the HAR file. If not specified, all requests are served from the HAR file.
        """

        self._sync(
            self._impl_obj.route_from_har(
                har=har,
                notFound=not_found,
                update=update,
                updateContent=update_content,
                updateMode=update_mode,
                url=url,
            )
        )

    def route_web_socket(
        self,
        url: typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]],
        handler: typing.Callable[["WebSocketRoute"], typing.Any],
    ) -> None:
        """Page.route_web_socket

        This method allows to modify websocket connections that are made by the page.

        Note that only `WebSocket`s created after this method was called will be routed. It is recommended to call this
        method before navigating the page.

        **Usage**

        Below is an example of a simple mock that responds to a single message. See `WebSocketRoute` for more details and
        examples.

        ```py
        def message_handler(ws: WebSocketRoute, message: Union[str, bytes]):
          if message == \"request\":
            ws.send(\"response\")

        def handler(ws: WebSocketRoute):
          ws.on_message(lambda message: message_handler(ws, message))

        page.route_web_socket(\"/ws\", handler)
        ```

        Parameters
        ----------
        url : Union[Callable[[str], bool], Pattern[str], str]
            Only WebSockets with the url matching this pattern will be routed. A string pattern can be relative to the
            `base_url` context option.
        handler : Callable[[WebSocketRoute], Any]
            Handler function to route the WebSocket.
        """

        self._sync(
            self._impl_obj.route_web_socket(
                url=self._wrap_handler(url), handler=self._wrap_handler(handler)
            )
        )

    @property
    def screencast(self) -> "Screencast":
        """Page.screencast

        `Screencast` object associated with this page.

        **Usage**

        Returns
        -------
        Screencast
        """
        return mapping.from_impl(self._impl_obj.screencast)

    def screenshot(
        self,
        *,
        animations: typing.Optional[Literal["allow", "disabled"]] = None,
        caret: typing.Optional[Literal["hide", "initial"]] = None,
        clip: typing.Optional[FloatRect] = None,
        full_page: typing.Optional[bool] = None,
        mask: typing.Optional[typing.Sequence["Locator"]] = None,
        mask_color: typing.Optional[str] = None,
        omit_background: typing.Optional[bool] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        quality: typing.Optional[int] = None,
        scale: typing.Optional[Literal["css", "device"]] = None,
        style: typing.Optional[str] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        type: typing.Optional[Literal["jpeg", "png", "webp"]] = None,
    ) -> bytes:
        """Page.screenshot

        Returns the buffer with the captured screenshot.

        Parameters
        ----------
        animations : Union["allow", "disabled", None]
            When set to `"disabled"`, stops CSS animations, CSS transitions and Web Animations. Animations get different
            treatment depending on their duration:
            - finite animations are fast-forwarded to completion, so they'll fire `transitionend` event.
            - infinite animations are canceled to initial state, and then played over after the screenshot.

            Defaults to `"allow"` that leaves animations untouched.
        caret : Union["hide", "initial", None]
            When set to `"hide"`, screenshot will hide text caret. When set to `"initial"`, text caret behavior will not be
            changed.  Defaults to `"hide"`.
        clip : Union[{x: float, y: float, width: float, height: float}, None]
            An object which specifies clipping of the resulting image.
        full_page : Union[bool, None]
            When true, takes a screenshot of the full scrollable page, instead of the currently visible viewport. Defaults to
            `false`.
        mask : Union[Sequence[Locator], None]
            Specify locators that should be masked when the screenshot is taken. Masked elements will be overlaid with a pink
            box `#FF00FF` (customized by `mask_color`) that completely covers its bounding box. The mask is also applied to
            invisible elements, see [Matching only visible elements](../locators.md#matching-only-visible-elements) to disable
            that.
        mask_color : Union[str, None]
            Specify the color of the overlay box for masked elements, in
            [CSS color format](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value). Default color is pink `#FF00FF`.
        omit_background : Union[bool, None]
            Hides default white background and allows capturing screenshots with transparency. Not applicable to `jpeg` images.
            Defaults to `false`.
        path : Union[pathlib.Path, str, None]
            The file path to save the image to. The screenshot type will be inferred from file extension. If `path` is a
            relative path, then it is resolved relative to the current working directory. If no path is provided, the image
            won't be saved to the disk.
        quality : Union[int, None]
            The quality of the image, between 0-100. Not applicable to `png` images. For `jpeg` the default is `80`. For
            `webp`, a quality of `100` (the default) produces a lossless image, while lower values use lossy compression.
        scale : Union["css", "device", None]
            When set to `"css"`, screenshot will have a single pixel per each css pixel on the page. For high-dpi devices, this
            will keep screenshots small. Using `"device"` option will produce a single pixel per each device pixel, so
            screenshots of high-dpi devices will be twice as large or even larger.

            Defaults to `"device"`.
        style : Union[str, None]
            Text of the stylesheet to apply while making the screenshot. This is where you can hide dynamic elements, make
            elements invisible or change their properties to help you creating repeatable screenshots. This stylesheet pierces
            the Shadow DOM and applies to the inner frames.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        type : Union["jpeg", "png", "webp", None]
            Specify screenshot type, defaults to `png`.

        Returns
        -------
        bytes
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.screenshot(
                    animations=animations,
                    caret=caret,
                    clip=clip,
                    fullPage=full_page,
                    mask=mapping.to_impl(mask),
                    maskColor=mask_color,
                    omitBackground=omit_background,
                    path=path,
                    quality=quality,
                    scale=scale,
                    style=style,
                    timeout=to_milliseconds(timeout),
                    type=type,
                )
            )
        )

    def select_option(
        self,
        selector: str,
        value: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None,
        *,
        element: typing.Optional[
            typing.Union["ElementHandle", typing.Sequence["ElementHandle"]]
        ] = None,
        force: typing.Optional[bool] = None,
        index: typing.Optional[typing.Union[int, typing.Sequence[int]]] = None,
        label: typing.Optional[typing.Union[str, typing.Sequence[str]]] = None,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.List[str]:
        """Page.select_option

        This method waits for an element matching `selector`, waits for [actionability](https://playwright.dev/python/docs/actionability) checks, waits
        until all specified options are present in the `<select>` element and selects these options.

        If the target element is not a `<select>` element, this method throws an error. However, if the element is inside
        the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), the control will be used
        instead.

        Returns the array of option values that have been successfully selected.

        Triggers a `change` and `input` event once all the provided options have been selected.

        **Usage**

        ```py
        # Single selection matching the value or label
        page.select_option(\"select#colors\", \"blue\")
        # single selection matching both the label
        page.select_option(\"select#colors\", label=\"blue\")
        # multiple selection
        page.select_option(\"select#colors\", value=[\"red\", \"green\", \"blue\"])
        ```

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        value : Union[Sequence[str], str, None]
            Options to select by value. If the `<select>` has the `multiple` attribute, all given options are selected,
            otherwise only the first option matching one of the passed options is selected. Optional.
        element : Union[ElementHandle, Sequence[ElementHandle], None]
            Option elements to select. Optional.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        index : Union[Sequence[int], int, None]
            Options to select by index. Optional.
        label : Union[Sequence[str], str, None]
            Options to select by label. If the `<select>` has the `multiple` attribute, all given options are selected,
            otherwise only the first option matching one of the passed options is selected. Optional.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        List[str]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.select_option(
                    selector=selector,
                    value=mapping.to_impl(value),
                    element=mapping.to_impl(element),
                    force=force,
                    index=mapping.to_impl(index),
                    label=mapping.to_impl(label),
                    noWaitAfter=no_wait_after,
                    strict=strict,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    @property
    def session_storage(self) -> "WebStorage":
        """Page.session_storage

        Provides access to the page's `sessionStorage` for the current origin. See `WebStorage`.

        Returns
        -------
        WebStorage
        """
        return mapping.from_impl(self._impl_obj.session_storage)

    def set_checked(
        self,
        selector: str,
        checked: bool,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Page.set_checked

        This method checks or unchecks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Ensure that matched element is a checkbox or a radio input. If not, this method throws.
        1. If the element already has the right checked state, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now checked or unchecked. If not, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        checked : bool
            Whether to check or uncheck the checkbox.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.set_checked(
                selector=selector,
                checked=checked,
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def set_content(
        self,
        html: str,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> None:
        """Page.set_content

        This method internally calls [document.write()](https://developer.mozilla.org/en-US/docs/Web/API/Document/write),
        inheriting all its specific characteristics and behaviors.

        Parameters
        ----------
        html : str
            HTML markup to assign to the page.
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.
        """

        self._sync(
            self._impl_obj.set_content(
                html=html, timeout=to_milliseconds(timeout), waitUntil=wait_until
            )
        )

    def set_default_navigation_timeout(
        self, timeout: typing.Union[float, datetime.timedelta]
    ) -> None:
        """Page.set_default_navigation_timeout

        This setting will change the default maximum navigation time for the following methods and related shortcuts:
        - `page.go_back()`
        - `page.go_forward()`
        - `page.goto()`
        - `page.reload()`
        - `page.set_content()`
        - `page.expect_navigation()`
        - `page.wait_for_url()`

        **NOTE** `page.set_default_navigation_timeout()` takes priority over `page.set_default_timeout()`,
        `browser_context.set_default_timeout()` and `browser_context.set_default_navigation_timeout()`.

        Parameters
        ----------
        timeout : float
            Maximum navigation time in milliseconds
        """

        self._impl_obj.set_default_navigation_timeout(timeout=to_milliseconds(timeout))

    def set_default_timeout(
        self, timeout: typing.Union[float, datetime.timedelta]
    ) -> None:
        """Page.set_default_timeout

        This setting will change the default maximum time for all the methods accepting `timeout` option.

        **NOTE** `page.set_default_navigation_timeout()` takes priority over `page.set_default_timeout()`.

        Parameters
        ----------
        timeout : float
            Maximum time in milliseconds. Pass `0` to disable timeout.
        """

        self._impl_obj.set_default_timeout(timeout=to_milliseconds(timeout))

    def set_extra_http_headers(self, headers: typing.Dict[str, str]) -> None:
        """Page.set_extra_http_headers

        The extra HTTP headers will be sent with every request the page initiates.

        **NOTE** `page.set_extra_http_headers()` does not guarantee the order of headers in the outgoing requests.

        Parameters
        ----------
        headers : Dict[str, str]
            An object containing additional HTTP headers to be sent with every request. All header values must be strings.
        """

        self._sync(
            self._impl_obj.set_extra_http_headers(headers=mapping.to_impl(headers))
        )

    def set_input_files(
        self,
        selector: str,
        files: typing.Union[
            str,
            pathlib.Path,
            typing.Sequence[typing.Union[str, pathlib.Path]],
            FilePayload,
            typing.Sequence[FilePayload],
        ],
        *,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Page.set_input_files

        Sets the value of the file input to these file paths or files. If some of the `filePaths` are relative paths, then
        they are resolved relative to the current working directory. For empty array, clears the selected files. For inputs
        with a `[webkitdirectory]` attribute, only a single directory path is supported.

        This method expects `selector` to point to an
        [input element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input). However, if the element is inside
        the `<label>` element that has an associated
        [control](https://developer.mozilla.org/en-US/docs/Web/API/HTMLLabelElement/control), targets the control instead.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        files : Union[Sequence[Union[pathlib.Path, str]], Sequence[{name: str, mimeType: str, buffer: bytes}], pathlib.Path, str, {name: str, mimeType: str, buffer: bytes}]
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.set_input_files(
                selector=selector,
                files=mapping.to_impl(files),
                noWaitAfter=no_wait_after,
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def set_viewport_size(self, viewport_size: ViewportSize) -> None:
        """Page.set_viewport_size

        In the case of multiple pages in a single browser, each page can have its own viewport size. However,
        `browser.new_context()` allows to set viewport size (and more) for all pages in the context at once.

        `page.set_viewport_size()` will resize the page. A lot of websites don't expect phones to change size, so you
        should set the viewport size before navigating to the page. `page.set_viewport_size()` will also reset `screen`
        size, use `browser.new_context()` with `screen` and `viewport` parameters if you need better control of these
        properties.

        **Usage**

        ```py
        page = browser.new_page()
        page.set_viewport_size({\"width\": 640, \"height\": 480})
        page.goto(\"https://example.com\")
        ```

        Parameters
        ----------
        viewport_size : {width: int, height: int}
        """

        self._sync(self._impl_obj.set_viewport_size(viewportSize=viewport_size))

    def tap(
        self,
        selector: str,
        *,
        force: typing.Optional[bool] = None,
        modifiers: typing.Optional[
            typing.Sequence[Literal["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]]
        ] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Page.tap

        This method taps an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.touchscreen` to tap the center of the element, or the specified `position`.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        **NOTE** `page.tap()` will throw if the `has_touch` option of the browser context is false.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        modifiers : Union[Sequence[Union["Alt", "Control", "ControlOrMeta", "Meta", "Shift"]], None]
            Modifier keys to press. Ensures that only these modifiers are pressed during the operation, and then restores
            current modifiers back. If not specified, currently pressed modifiers are used. "ControlOrMeta" resolves to
            "Control" on Windows and Linux and to "Meta" on macOS.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it. Note that keyboard
            `modifiers` will be pressed regardless of `trial` to allow testing elements which are only visible when those keys
            are pressed.
        """

        self._sync(
            self._impl_obj.tap(
                selector=selector,
                force=force,
                modifiers=mapping.to_impl(modifiers),
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def text_content(
        self,
        selector: str,
        *,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional[str]:
        """Page.text_content

        Returns `element.textContent`.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.text_content(
                    selector=selector, strict=strict, timeout=to_milliseconds(timeout)
                )
            )
        )

    def title(self) -> str:
        """Page.title

        Returns the page's title.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.title()))

    @property
    def touchscreen(self) -> "Touchscreen":
        """Page.touchscreen

        Returns
        -------
        Touchscreen
        """
        return mapping.from_impl(self._impl_obj.touchscreen)

    def type(
        self,
        selector: str,
        text: str,
        *,
        delay: typing.Optional[float] = None,
        no_wait_after: typing.Optional[bool] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Page.type

        Sends a `keydown`, `keypress`/`input`, and `keyup` event for each character in the text. `page.type` can be used to
        send fine-grained keyboard events. To fill values in form fields, use `page.fill()`.

        To press a special key, like `Control` or `ArrowDown`, use `keyboard.press()`.

        **Usage**

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        text : str
            A text to type into a focused element.
        delay : Union[float, None]
            Time to wait between key presses in milliseconds. Defaults to 0.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        """

        self._sync(
            self._impl_obj.type(
                selector=selector,
                text=text,
                delay=delay,
                noWaitAfter=no_wait_after,
                strict=strict,
                timeout=to_milliseconds(timeout),
            )
        )

    def uncheck(
        self,
        selector: str,
        *,
        force: typing.Optional[bool] = None,
        no_wait_after: typing.Optional[bool] = None,
        position: typing.Optional[Position] = None,
        scroll: typing.Optional[Literal["auto", "none"]] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        trial: typing.Optional[bool] = None,
    ) -> None:
        """Page.uncheck

        This method unchecks an element matching `selector` by performing the following steps:
        1. Find an element matching `selector`. If there is none, wait until a matching element is attached to the DOM.
        1. Ensure that matched element is a checkbox or a radio input. If not, this method throws. If the element is
           already unchecked, this method returns immediately.
        1. Wait for [actionability](https://playwright.dev/python/docs/actionability) checks on the matched element, unless `force` option is set. If
           the element is detached during the checks, the whole action is retried.
        1. Scroll the element into view if needed.
        1. Use `page.mouse` to click in the center of the element.
        1. Ensure that the element is now unchecked. If not, this method throws.

        When all steps combined have not finished during the specified `timeout`, this method throws a `TimeoutError`.
        Passing zero timeout disables this.

        Parameters
        ----------
        selector : str
            A selector to search for an element. If there are multiple elements satisfying the selector, the first will be
            used.
        force : Union[bool, None]
            Whether to bypass the [actionability](../actionability.md) checks. Defaults to `false`.
        no_wait_after : Union[bool, None]
            This option has no effect.
            Deprecated: This option has no effect.
        position : Union[{x: float, y: float}, None]
            A point to use relative to the top-left corner of element padding box. If not specified, uses some visible point of
            the element.
        scroll : Union["auto", "none", None]
            Controls whether Playwright scrolls the element into view before performing the action. Defaults to `"auto"`, which
            scrolls the element into view when necessary, including scrolling nested scrollable containers. When set to
            `"none"`, Playwright does not scroll the element and the action fails if the element is not already in the
            viewport. This is useful to assert that an element is reachable by the user without additional scrolling.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.
        trial : Union[bool, None]
            When set, this method only performs the [actionability](../actionability.md) checks and skips the action. Defaults
            to `false`. Useful to wait until the element is ready for the action without performing it.
        """

        self._sync(
            self._impl_obj.uncheck(
                selector=selector,
                force=force,
                noWaitAfter=no_wait_after,
                position=position,
                scroll=scroll,
                strict=strict,
                timeout=to_milliseconds(timeout),
                trial=trial,
            )
        )

    def unroute(
        self,
        url: typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]],
        handler: typing.Optional[
            typing.Union[
                typing.Callable[["Route"], typing.Any],
                typing.Callable[["Route", "Request"], typing.Any],
            ]
        ] = None,
    ) -> None:
        """Page.unroute

        Removes a route created with `page.route()`. When `handler` is not specified, removes all routes for the `url`.

        Parameters
        ----------
        url : Union[Callable[[str], bool], Pattern[str], str]
            A glob pattern, regex pattern, or predicate receiving [URL] to match while routing.
        handler : Union[Callable[[Route, Request], Any], Callable[[Route], Any], None]
            Optional handler function to route the request.
        """

        self._sync(
            self._impl_obj.unroute(
                url=self._wrap_handler(url), handler=self._wrap_handler(handler)
            )
        )

    def unroute_all(
        self,
        *,
        behavior: typing.Optional[Literal["default", "ignoreErrors", "wait"]] = None,
    ) -> None:
        """Page.unroute_all

        Removes all routes created with `page.route()` and `page.route_from_har()`.

        Parameters
        ----------
        behavior : Union["default", "ignoreErrors", "wait", None]
            Specifies whether to wait for already running handlers and what to do if they throw errors:
            - `'default'` - do not wait for current handler calls (if any) to finish, if unrouted handler throws, it may
              result in unhandled error
            - `'wait'` - wait for current handler calls (if any) to finish
            - `'ignoreErrors'` - do not wait for current handler calls (if any) to finish, all errors thrown by the handlers
              after unrouting are silently caught
        """

        self._sync(self._impl_obj.unroute_all(behavior=behavior))

    @property
    def url(self) -> str:
        """Page.url

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)

    @property
    def video(self) -> typing.Optional["Video"]:
        """Page.video

        Video object associated with this page. Can be used to access the video file when using the `recordVideo` context
        option.

        Returns
        -------
        Union[Video, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.video)

    @property
    def viewport_size(self) -> typing.Optional[ViewportSize]:
        """Page.viewport_size

        Returns
        -------
        Union[{width: int, height: int}, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.viewport_size)

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["close"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["console"],
        predicate: typing.Optional[typing.Callable[["ConsoleMessage"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "ConsoleMessage": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["crash"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["dialog"],
        predicate: typing.Optional[typing.Callable[["Dialog"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Dialog": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["dialogclosed"],
        predicate: typing.Optional[typing.Callable[["Dialog"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Dialog": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["domcontentloaded"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["download"],
        predicate: typing.Optional[typing.Callable[["Download"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Download": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["filechooser"],
        predicate: typing.Optional[typing.Callable[["FileChooser"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "FileChooser": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["frameattached"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Frame": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["framedetached"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Frame": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["framenavigated"],
        predicate: typing.Optional[typing.Callable[["Frame"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Frame": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["load"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["pageerror"],
        predicate: typing.Optional[typing.Callable[["Error"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Error": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["popup"],
        predicate: typing.Optional[typing.Callable[["Page"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Page": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["request"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Request": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["requestfailed"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Request": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["requestfinished"],
        predicate: typing.Optional[typing.Callable[["Request"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Request": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["response"],
        predicate: typing.Optional[typing.Callable[["Response"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Response": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["websocket"],
        predicate: typing.Optional[typing.Callable[["WebSocket"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "WebSocket": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["worker"],
        predicate: typing.Optional[typing.Callable[["Worker"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "Worker": ...

    @typing.overload
    def wait_for_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable[..., bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> typing.Any: ...

    def wait_for_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Any:
        """Page.wait_for_event

        **NOTE** In most cases, you should use `page.expect_event()`.

        Waits for given `event` to fire. If predicate is provided, it passes event's value into the `predicate` function
        and waits for `predicate(event)` to return a truthy value. Will throw an error if the page is closed before the
        `event` is fired.

        Parameters
        ----------
        event : str
            Event name, same one typically passed into `*.on(event)`.
        predicate : Union[Callable, None]
            Receives the event data and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.wait_for_event(
                    event=event,
                    predicate=self._wrap_handler(predicate),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def wait_for_function(
        self,
        expression: str,
        *,
        arg: typing.Optional[typing.Any] = None,
        polling: typing.Optional[typing.Union[float, Literal["raf"]]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> "JSHandle":
        """Page.wait_for_function

        Returns when the `expression` returns a truthy value. It resolves to a JSHandle of the truthy value.

        **Usage**

        The `page.wait_for_function()` can be used to observe viewport size change:

        ```py
        from playwright.sync_api import sync_playwright, Playwright

        def run(playwright: Playwright):
            webkit = playwright.webkit
            browser = webkit.launch()
            page = browser.new_page()
            page.evaluate(\"window.x = 0; setTimeout(() => { window.x = 100 }, 1000);\")
            page.wait_for_function(\"() => window.x > 0\")
            browser.close()

        with sync_playwright() as playwright:
            run(playwright)
        ```

        To pass an argument to the predicate of `page.wait_for_function()` function:

        ```py
        selector = \".foo\"
        page.wait_for_function(\"selector => !!document.querySelector(selector)\", selector)
        ```

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.
        polling : Union["raf", float, None]
            If `polling` is `'raf'`, then `expression` is constantly executed in `requestAnimationFrame` callback. If `polling`
            is a number, then it is treated as an interval in milliseconds at which the function would be executed. Defaults to
            `raf`.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()`
            methods.

        Returns
        -------
        JSHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.wait_for_function(
                    expression=expression,
                    arg=mapping.to_impl(arg),
                    polling=polling,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def wait_for_load_state(
        self,
        state: typing.Optional[
            Literal["domcontentloaded", "load", "networkidle"]
        ] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """Page.wait_for_load_state

        Returns when the required load state has been reached.

        This resolves when the page reaches a required load state, `load` by default. The navigation must have been
        committed when this method is called. If current document has already reached the required state, resolves
        immediately.

        **NOTE** Most of the time, this method is not needed because Playwright
        [auto-waits before every action](https://playwright.dev/python/docs/actionability).

        **Usage**

        ```py
        page.get_by_role(\"button\").click() # click triggers navigation.
        page.wait_for_load_state() # the promise resolves after \"load\" event.
        ```

        ```py
        with page.expect_popup() as page_info:
            page.get_by_role(\"button\").click() # click triggers a popup.
        popup = page_info.value
        # Wait for the \"DOMContentLoaded\" event.
        popup.wait_for_load_state(\"domcontentloaded\")
        print(popup.title()) # popup is ready to use.
        ```

        Parameters
        ----------
        state : Union["domcontentloaded", "load", "networkidle", None]
            Optional load state to wait for, defaults to `load`. If the state has been already reached while loading current
            document, the method resolves immediately. Can be one of:
            - `'load'` - wait for the `load` event to be fired.
            - `'domcontentloaded'` - wait for the `DOMContentLoaded` event to be fired.
            - `'networkidle'` - **DISCOURAGED** wait until there are no network connections for at least `500` ms. Don't use
              this method for testing, rely on web assertions to assess readiness instead.
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        """

        self._sync(
            self._impl_obj.wait_for_load_state(
                state=state, timeout=to_milliseconds(timeout)
            )
        )

    def wait_for_selector(
        self,
        selector: str,
        *,
        state: typing.Optional[
            Literal["attached", "detached", "hidden", "visible"]
        ] = None,
        strict: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Optional["ElementHandle"]:
        """Page.wait_for_selector

        Returns when element specified by selector satisfies `state` option. Returns `null` if waiting for `hidden` or
        `detached`.

        **NOTE** Playwright automatically waits for element to be ready before performing an action. Using `Locator`
        objects and web-first assertions makes the code wait-for-selector-free.

        Wait for the `selector` to satisfy `state` option (either appear/disappear from dom, or become visible/hidden). If
        at the moment of calling the method `selector` already satisfies the condition, the method will return immediately.
        If the selector doesn't satisfy the condition for the `timeout` milliseconds, the function will throw.

        **Usage**

        This method works across navigations:

        ```py
        from playwright.sync_api import sync_playwright, Playwright

        def run(playwright: Playwright):
            chromium = playwright.chromium
            browser = chromium.launch()
            page = browser.new_page()
            for current_url in [\"https://google.com\", \"https://bbc.com\"]:
                page.goto(current_url, wait_until=\"domcontentloaded\")
                element = page.wait_for_selector(\"img\")
                print(\"Loaded image: \" + str(element.get_attribute(\"src\")))
            browser.close()

        with sync_playwright() as playwright:
            run(playwright)
        ```

        Parameters
        ----------
        selector : str
            A selector to query for.
        state : Union["attached", "detached", "hidden", "visible", None]
            Defaults to `'visible'`. Can be either:
            - `'attached'` - wait for element to be present in DOM.
            - `'detached'` - wait for element to not be present in DOM.
            - `'visible'` - wait for element to have non-empty bounding box and no `visibility:hidden`. Note that element
              without any content or with `display:none` has an empty bounding box and is not considered visible.
            - `'hidden'` - wait for element to be either detached from DOM, or have an empty bounding box or
              `visibility:hidden`. This is opposite to the `'visible'` option.
        strict : Union[bool, None]
            When true, the call requires selector to resolve to a single element. If given selector resolves to more than one
            element, the call throws an exception.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Union[ElementHandle, None]
        """

        return mapping.from_impl_nullable(
            self._sync(
                self._impl_obj.wait_for_selector(
                    selector=selector,
                    state=state,
                    strict=strict,
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def wait_for_timeout(
        self, timeout: typing.Union[float, datetime.timedelta]
    ) -> None:
        """Page.wait_for_timeout

        Waits for the given `timeout` in milliseconds.

        Note that `page.waitForTimeout()` should only be used for debugging. Tests using the timer in production are going
        to be flaky. Use signals such as network events, selectors becoming visible and others instead.

        **Usage**

        ```py
        # wait for 1 second
        page.wait_for_timeout(1000)
        ```

        Parameters
        ----------
        timeout : float
            A timeout to wait for
        """

        self._sync(self._impl_obj.wait_for_timeout(timeout=to_milliseconds(timeout)))

    def wait_for_url(
        self,
        url: typing.Union[str, typing.Pattern[str], typing.Callable[[str], bool]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        wait_until: typing.Optional[
            Literal["commit", "domcontentloaded", "load", "networkidle"]
        ] = None,
    ) -> None:
        """Page.wait_for_url

        Waits for the main frame to navigate to the given URL.

        **Usage**

        ```py
        page.click(\"a.delayed-navigation\") # clicking the link will indirectly cause a navigation
        page.wait_for_url(\"**/target.html\")
        ```

        Parameters
        ----------
        url : Union[Callable[[str], bool], Pattern[str], str]
            A glob pattern, regex pattern, or predicate receiving [URL] to match while waiting for the navigation. Note that if
            the parameter is a string without wildcard characters, the method will wait for navigation to URL that is exactly
            equal to the string.
        timeout : Union[float, None]
            Maximum operation time in milliseconds, defaults to 30 seconds, pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_navigation_timeout()`,
            `browser_context.set_default_timeout()`, `page.set_default_navigation_timeout()` or `page.set_default_timeout()`
            methods.
        wait_until : Union["commit", "domcontentloaded", "load", "networkidle", None]
            When to consider operation succeeded, defaults to `load`. Events can be either:
            - `'domcontentloaded'` - consider operation to be finished when the `DOMContentLoaded` event is fired.
            - `'load'` - consider operation to be finished when the `load` event is fired.
            - `'networkidle'` - **DISCOURAGED** consider operation to be finished when there are no network connections for
              at least `500` ms. Don't use this method for testing, rely on web assertions to assess readiness instead.
            - `'commit'` - consider operation to be finished when network response is received and the document started
              loading.
        """

        self._sync(
            self._impl_obj.wait_for_url(
                url=self._wrap_handler(url),
                timeout=to_milliseconds(timeout),
                waitUntil=wait_until,
            )
        )

    @property
    def webmcp(self) -> "WebMCP":
        """Page.webmcp

        Tools that the main frame registers through the experimental `WebMCP` browser API. Shortcut for `frame.webmcp` of
        `page.main_frame`, see `WebMCP` for details.

        **Usage**

        Returns
        -------
        WebMCP
        """
        return mapping.from_impl(self._impl_obj.webmcp)

    @property
    def workers(self) -> typing.List["Worker"]:
        """Page.workers

        This method returns all of the dedicated
        [WebWorkers](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API) associated with the page.

        **NOTE** This does not contain ServiceWorkers

        Returns
        -------
        List[Worker]
        """
        return mapping.from_impl_list(self._impl_obj.workers)


mapping.register(PageImpl, Page)


class PageAssertions(SyncBase):
    _impl_obj: PageAssertionsImpl

    def not_to_have_title(
        self,
        title_or_reg_exp: typing.Union[str, typing.Pattern[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """PageAssertions.not_to_have_title

        The opposite of `page_assertions.to_have_title()`.

        Parameters
        ----------
        title_or_reg_exp : Union[Pattern[str], str]
            Expected title or RegExp.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_title(
                titleOrRegExp=title_or_reg_exp, timeout=to_milliseconds(timeout)
            )
        )

    def not_to_have_url(
        self,
        url_or_reg_exp: typing.Union[str, typing.Pattern[str]],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """PageAssertions.not_to_have_url

        The opposite of `page_assertions.to_have_url()`.

        Parameters
        ----------
        url_or_reg_exp : Union[Pattern[str], str]
            Expected URL string or RegExp.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression flag if specified.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_have_url(
                urlOrRegExp=url_or_reg_exp,
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
            )
        )

    def not_to_match_aria_snapshot(
        self,
        expected: str,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """PageAssertions.not_to_match_aria_snapshot

        The opposite of `page_assertions.to_match_aria_snapshot()`.

        Parameters
        ----------
        expected : str
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.not_to_match_aria_snapshot(
                expected=expected, timeout=to_milliseconds(timeout)
            )
        )

    def to_have_title(
        self,
        title_or_reg_exp: typing.Union[str, typing.Pattern[str]],
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """PageAssertions.to_have_title

        Ensures the page has the given title.

        **Usage**

        ```py
        import re
        from playwright.sync_api import expect

        # ...
        expect(page).to_have_title(re.compile(r\".*checkout\"))
        ```

        Parameters
        ----------
        title_or_reg_exp : Union[Pattern[str], str]
            Expected title or RegExp.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_title(
                titleOrRegExp=title_or_reg_exp, timeout=to_milliseconds(timeout)
            )
        )

    def to_have_url(
        self,
        url_or_reg_exp: typing.Union[str, typing.Pattern[str]],
        *,
        ignore_case: typing.Optional[bool] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """PageAssertions.to_have_url

        Ensures the page is navigated to the given URL.

        **Usage**

        ```py
        import re
        from playwright.sync_api import expect

        # ...
        expect(page).to_have_url(re.compile(\".*checkout\"))
        ```

        Parameters
        ----------
        url_or_reg_exp : Union[Pattern[str], str]
            Expected URL string or RegExp.
        ignore_case : Union[bool, None]
            Whether to perform case-insensitive match. `ignore_case` option takes precedence over the corresponding regular
            expression parameter if specified. A provided predicate ignores this flag.
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_have_url(
                urlOrRegExp=url_or_reg_exp,
                ignoreCase=ignore_case,
                timeout=to_milliseconds(timeout),
            )
        )

    def to_match_aria_snapshot(
        self,
        expected: str,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> None:
        """PageAssertions.to_match_aria_snapshot

        Asserts that the page body matches the given [accessibility snapshot](https://playwright.dev/python/docs/aria-snapshots).

        **Usage**

        ```py
        page.goto(\"https://demo.playwright.dev/todomvc/\")
        expect(page).to_match_aria_snapshot('''
          - heading \"todos\"
          - textbox \"What needs to be done?\"
        ''')
        ```

        Parameters
        ----------
        expected : str
        timeout : Union[float, None]
            Time to retry the assertion for in milliseconds. Defaults to `5000`.
        """
        __tracebackhide__ = True

        self._sync(
            self._impl_obj.to_match_aria_snapshot(
                expected=expected, timeout=to_milliseconds(timeout)
            )
        )


mapping.register(PageAssertionsImpl, PageAssertions)


class Playwright(SyncBase):
    _impl_obj: PlaywrightImpl

    def __getitem__(self, value: str) -> "BrowserType":

        return mapping.from_impl(self._impl_obj.__getitem__(value))

    @property
    def chromium(self) -> "BrowserType":
        """Playwright.chromium

        This object can be used to launch or connect to Chromium, returning instances of `Browser`.

        Returns
        -------
        BrowserType
        """
        return mapping.from_impl(self._impl_obj.chromium)

    @property
    def devices(self) -> typing.Dict:
        """Playwright.devices

        Returns a dictionary of devices to be used with `browser.new_context()` or `browser.new_page()`.

        ```py
        from playwright.sync_api import sync_playwright, Playwright

        def run(playwright: Playwright):
            webkit = playwright.webkit
            iphone = playwright.devices[\"iPhone 6\"]
            browser = webkit.launch()
            context = browser.new_context(**iphone)
            page = context.new_page()
            page.goto(\"http://example.com\")
            # other actions...
            browser.close()

        with sync_playwright() as playwright:
            run(playwright)
        ```

        Returns
        -------
        Dict
        """
        return mapping.from_maybe_impl(self._impl_obj.devices)

    @property
    def firefox(self) -> "BrowserType":
        """Playwright.firefox

        This object can be used to launch or connect to Firefox, returning instances of `Browser`.

        Returns
        -------
        BrowserType
        """
        return mapping.from_impl(self._impl_obj.firefox)

    @property
    def request(self) -> "APIRequest":
        """Playwright.request

        Exposes API that can be used for the Web API testing.

        Returns
        -------
        APIRequest
        """
        return mapping.from_impl(self._impl_obj.request)

    @property
    def selectors(self) -> "Selectors":
        """Playwright.selectors

        Selectors can be used to install custom selector engines. See [extensibility](https://playwright.dev/python/docs/extensibility) for more
        information.

        Returns
        -------
        Selectors
        """
        return mapping.from_impl(self._impl_obj.selectors)

    def stop(self) -> None:
        """Playwright.stop

        Terminates this instance of Playwright in case it was created bypassing the Python context manager. This is useful
        in REPL applications.

        ```py
        from playwright.sync_api import sync_playwright

        playwright = sync_playwright().start()

        browser = playwright.chromium.launch()
        page = browser.new_page()
        page.goto(\"https://playwright.dev/\")
        page.screenshot(path=\"example.png\")
        browser.close()

        playwright.stop()
        ```
        """

        self._sync(self._impl_obj.stop())

    @property
    def webkit(self) -> "BrowserType":
        """Playwright.webkit

        This object can be used to launch or connect to WebKit, returning instances of `Browser`.

        Returns
        -------
        BrowserType
        """
        return mapping.from_impl(self._impl_obj.webkit)


mapping.register(PlaywrightImpl, Playwright)


class Request(SyncBase):
    _impl_obj: RequestImpl

    def all_headers(self) -> typing.Dict[str, str]:
        """Request.all_headers

        An object with all the request HTTP headers associated with this request. The header names are lower-cased.

        Returns
        -------
        Dict[str, str]
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.all_headers()))

    @property
    def existing_response(self) -> typing.Optional["Response"]:
        """Request.existing_response

        Returns the `Response` object if the response has already been received, `null` otherwise.

        Unlike `request.response()`, this method does not wait for the response to arrive. It returns immediately with the
        response object if the response has been received, or `null` if the response has not been received yet.

        Returns
        -------
        Union[Response, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.existing_response)

    @property
    def failure(self) -> typing.Optional[str]:
        """Request.failure

        The method returns `null` unless this request has failed, as reported by `requestfailed` event.

        **Usage**

        Example of logging of all the failed requests:

        ```py
        page.on(\"requestfailed\", lambda request: print(request.url + \" \" + request.failure))
        ```

        Returns
        -------
        Union[str, None]
        """
        return mapping.from_maybe_impl(self._impl_obj.failure)

    @property
    def frame(self) -> "Frame":
        """Request.frame

        Returns the `Frame` that initiated this request.

        **Usage**

        ```py
        frame_url = request.frame.url
        ```

        **Details**

        Note that in some cases the frame is not available, and this method will throw.
        - When request originates in the Service Worker. You can use `request.serviceWorker()` to check that.
        - When navigation request is issued before the corresponding frame is created. You can use
          `request.is_navigation_request()` to check that.

        Here is an example that handles all the cases:

        Returns
        -------
        Frame
        """
        return mapping.from_impl(self._impl_obj.frame)

    def header_value(self, name: str) -> typing.Optional[str]:
        """Request.header_value

        Returns the value of the header matching the name. The name is case-insensitive.

        Parameters
        ----------
        name : str
            Name of the header.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.header_value(name=name))
        )

    @property
    def headers(self) -> typing.Dict[str, str]:
        """Request.headers

        An object with the request HTTP headers. The header names are lower-cased. Note that this method does not return
        security-related headers, including cookie-related ones. You can use `request.all_headers()` for complete list of
        headers that include `cookie` information.

        Returns
        -------
        Dict[str, str]
        """
        return mapping.from_maybe_impl(self._impl_obj.headers)

    def headers_array(self) -> typing.List[NameValue]:
        """Request.headers_array

        An array with all the request HTTP headers associated with this request. Unlike `request.all_headers()`, header
        names are NOT lower-cased. Headers with multiple entries, such as `Set-Cookie`, appear in the array multiple times.

        Returns
        -------
        List[{name: str, value: str}]
        """

        return mapping.from_impl_list(self._sync(self._impl_obj.headers_array()))

    def is_navigation_request(self) -> bool:
        """Request.is_navigation_request

        Whether this request is driving frame's navigation.

        Some navigation requests are issued before the corresponding frame is created, and therefore do not have
        `request.frame` available.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._impl_obj.is_navigation_request())

    @property
    def method(self) -> str:
        """Request.method

        Request's method (GET, POST, etc.)

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.method)

    @property
    def post_data(self) -> typing.Optional[str]:
        """Request.post_data

        Request's post body, if any.

        Returns
        -------
        Union[str, None]
        """
        return mapping.from_maybe_impl(self._impl_obj.post_data)

    @property
    def post_data_buffer(self) -> typing.Optional[bytes]:
        """Request.post_data_buffer

        Request's post body in a binary form, if any.

        Returns
        -------
        Union[bytes, None]
        """
        return mapping.from_maybe_impl(self._impl_obj.post_data_buffer)

    @property
    def post_data_json(self) -> typing.Optional[typing.Any]:
        """Request.post_data_json

        Returns parsed request's body for `form-urlencoded` and JSON as a fallback if any.

        When the response is `application/x-www-form-urlencoded` then a key/value object of the values will be returned.
        Otherwise it will be parsed as JSON.

        Returns
        -------
        Union[Any, None]
        """
        return mapping.from_maybe_impl(self._impl_obj.post_data_json)

    @property
    def redirected_from(self) -> typing.Optional["Request"]:
        """Request.redirected_from

        Request that was redirected by the server to this one, if any.

        When the server responds with a redirect, Playwright creates a new `Request` object. The two requests are connected
        by `redirectedFrom()` and `redirectedTo()` methods. When multiple server redirects has happened, it is possible to
        construct the whole redirect chain by repeatedly calling `redirectedFrom()`.

        **Usage**

        For example, if the website `http://example.com` redirects to `https://example.com`:

        ```py
        response = page.goto(\"http://example.com\")
        print(response.request.redirected_from.url) # \"http://example.com\"
        ```

        If the website `https://google.com` has no redirects:

        ```py
        response = page.goto(\"https://google.com\")
        print(response.request.redirected_from) # None
        ```

        Returns
        -------
        Union[Request, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.redirected_from)

    @property
    def redirected_to(self) -> typing.Optional["Request"]:
        """Request.redirected_to

        New request issued by the browser if the server responded with redirect.

        **Usage**

        This method is the opposite of `request.redirected_from`:

        ```py
        assert request.redirected_from.redirected_to == request
        ```

        Returns
        -------
        Union[Request, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.redirected_to)

    @property
    def resource_type(self) -> str:
        """Request.resource_type

        Contains the request's resource type as it was perceived by the rendering engine. ResourceType will be one of the
        following: `document`, `stylesheet`, `image`, `media`, `font`, `script`, `texttrack`, `xhr`, `fetch`,
        `eventsource`, `websocket`, `manifest`, `beacon`, `ping`, `cspreport`, `other`.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.resource_type)

    def response(self) -> typing.Optional["Response"]:
        """Request.response

        Returns the matching `Response` object, or `null` if the response was not received due to error.

        Returns
        -------
        Union[Response, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.response()))

    @property
    def service_worker(self) -> typing.Optional["Worker"]:
        """Request.service_worker

        The Service `Worker` that is performing the request.

        **Details**

        This method is Chromium only. It's safe to call when using other browsers, but it will always be `null`.

        Requests originated in a Service Worker do not have a `request.frame` available.

        Returns
        -------
        Union[Worker, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.service_worker)

    def sizes(self) -> RequestSizes:
        """Request.sizes

        Returns resource size information for given request.

        Returns
        -------
        {requestBodySize: int, requestHeadersSize: int, responseBodySize: int, responseHeadersSize: int}
        """

        return mapping.from_impl(self._sync(self._impl_obj.sizes()))

    @property
    def timing(self) -> ResourceTiming:
        """Request.timing

        Returns resource timing information for given request. Most of the timing values become available upon the
        response, `responseEnd` becomes available when request finishes. Find more information at
        [Resource Timing API](https://developer.mozilla.org/en-US/docs/Web/API/PerformanceResourceTiming).

        **Usage**

        ```py
        with page.expect_event(\"requestfinished\") as request_info:
            page.goto(\"http://example.com\")
        request = request_info.value
        print(request.timing)
        ```

        Returns
        -------
        {startTime: float, domainLookupStart: float, domainLookupEnd: float, connectStart: float, secureConnectionStart: float, connectEnd: float, requestStart: float, responseStart: float, responseEnd: float}
        """
        return mapping.from_impl(self._impl_obj.timing)

    @property
    def url(self) -> str:
        """Request.url

        URL of the request.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)


mapping.register(RequestImpl, Request)


class Response(SyncBase):
    _impl_obj: ResponseImpl

    def all_headers(self) -> typing.Dict[str, str]:
        """Response.all_headers

        An object with all the response HTTP headers associated with this response.

        Returns
        -------
        Dict[str, str]
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.all_headers()))

    def body(self) -> bytes:
        """Response.body

        Returns the buffer with response body.

        Returns
        -------
        bytes
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.body()))

    def finished(self) -> None:
        """Response.finished

        Waits for this response to finish, returns always `null`.
        """

        self._sync(self._impl_obj.finished())

    @property
    def frame(self) -> "Frame":
        """Response.frame

        Returns the `Frame` that initiated this response.

        Returns
        -------
        Frame
        """
        return mapping.from_impl(self._impl_obj.frame)

    @property
    def from_service_worker(self) -> bool:
        """Response.from_service_worker

        Indicates whether this Response was fulfilled by a Service Worker's Fetch Handler (i.e. via
        [FetchEvent.respondWith](https://developer.mozilla.org/en-US/docs/Web/API/FetchEvent/respondWith)).

        Returns
        -------
        bool
        """
        return mapping.from_maybe_impl(self._impl_obj.from_service_worker)

    def header_value(self, name: str) -> typing.Optional[str]:
        """Response.header_value

        Returns the value of the header matching the name. The name is case-insensitive. If multiple headers have the same
        name (except `set-cookie`), they are returned as a list separated by `, `. For `set-cookie`, the `\\n` separator is
        used. If no headers are found, `null` is returned.

        Parameters
        ----------
        name : str
            Name of the header.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.header_value(name=name))
        )

    def header_values(self, name: str) -> typing.List[str]:
        """Response.header_values

        Returns all values of the headers matching the name, for example `set-cookie`. The name is case-insensitive.

        Parameters
        ----------
        name : str
            Name of the header.

        Returns
        -------
        List[str]
        """

        return mapping.from_maybe_impl(
            self._sync(self._impl_obj.header_values(name=name))
        )

    @property
    def headers(self) -> typing.Dict[str, str]:
        """Response.headers

        An object with the response HTTP headers. The header names are lower-cased. Note that this method does not return
        security-related headers, including cookie-related ones. You can use `response.all_headers()` for complete list of
        headers that include `cookie` information.

        Returns
        -------
        Dict[str, str]
        """
        return mapping.from_maybe_impl(self._impl_obj.headers)

    def headers_array(self) -> typing.List[NameValue]:
        """Response.headers_array

        An array with all the response HTTP headers associated with this response. Unlike `response.all_headers()`, header
        names are NOT lower-cased. Headers with multiple entries, such as `Set-Cookie`, appear in the array multiple times.
        Some browser network stacks combine multiple field values before reporting them, so separate entries are not always
        available.

        Returns
        -------
        List[{name: str, value: str}]
        """

        return mapping.from_impl_list(self._sync(self._impl_obj.headers_array()))

    def http_version(self) -> str:
        """Response.http_version

        Returns the http version used by the response.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.http_version()))

    def json(self) -> typing.Any:
        """Response.json

        Returns the JSON representation of response body.

        This method will throw if the response body is not parsable via `JSON.parse`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.json()))

    @property
    def ok(self) -> bool:
        """Response.ok

        Contains a boolean stating whether the response was successful (status in the range 200-299) or not.

        Returns
        -------
        bool
        """
        return mapping.from_maybe_impl(self._impl_obj.ok)

    @property
    def request(self) -> "Request":
        """Response.request

        Returns the matching `Request` object.

        Returns
        -------
        Request
        """
        return mapping.from_impl(self._impl_obj.request)

    def security_details(self) -> typing.Optional[SecurityDetails]:
        """Response.security_details

        Returns SSL and other security information.

        Returns
        -------
        Union[{issuer: Union[str, None], protocol: Union[str, None], subjectName: Union[str, None], validFrom: Union[float, None], validTo: Union[float, None]}, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.security_details()))

    def server_addr(self) -> typing.Optional[RemoteAddr]:
        """Response.server_addr

        Returns the IP address and port of the server.

        Returns
        -------
        Union[{ipAddress: str, port: int}, None]
        """

        return mapping.from_impl_nullable(self._sync(self._impl_obj.server_addr()))

    @property
    def status(self) -> int:
        """Response.status

        Contains the status code of the response (e.g., 200 for a success).

        Returns
        -------
        int
        """
        return mapping.from_maybe_impl(self._impl_obj.status)

    @property
    def status_text(self) -> str:
        """Response.status_text

        Contains the status text of the response (e.g. usually an \"OK\" for a success).

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.status_text)

    def text(self) -> str:
        """Response.text

        Returns the text representation of response body.

        Returns
        -------
        str
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.text()))

    @property
    def url(self) -> str:
        """Response.url

        Contains the URL of the response.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)


mapping.register(ResponseImpl, Response)


class Route(SyncBase):
    _impl_obj: RouteImpl

    def abort(self, error_code: typing.Optional[str] = None) -> None:
        """Route.abort

        Aborts the route's request.

        Parameters
        ----------
        error_code : Union[str, None]
            Optional error code. Defaults to `failed`, could be one of the following:
            - `'aborted'` - An operation was aborted (due to user action)
            - `'accessdenied'` - Permission to access a resource, other than the network, was denied
            - `'addressunreachable'` - The IP address is unreachable. This usually means that there is no route to the
              specified host or network.
            - `'blockedbyclient'` - The client chose to block the request.
            - `'blockedbyresponse'` - The request failed because the response was delivered along with requirements which are
              not met ('X-Frame-Options' and 'Content-Security-Policy' ancestor checks, for instance).
            - `'connectionaborted'` - A connection timed out as a result of not receiving an ACK for data sent.
            - `'connectionclosed'` - A connection was closed (corresponding to a TCP FIN).
            - `'connectionfailed'` - A connection attempt failed.
            - `'connectionrefused'` - A connection attempt was refused.
            - `'connectionreset'` - A connection was reset (corresponding to a TCP RST).
            - `'internetdisconnected'` - The Internet connection has been lost.
            - `'namenotresolved'` - The host name could not be resolved.
            - `'timedout'` - An operation timed out.
            - `'failed'` - A generic failure occurred.
        """

        self._sync(self._impl_obj.abort(errorCode=error_code))

    def continue_(
        self,
        *,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        method: typing.Optional[str] = None,
        post_data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        url: typing.Optional[str] = None,
    ) -> None:
        """Route.continue_

        Sends route's request to the network with optional overrides.

        **Usage**

        ```py
        def handle(route, request):
            # override headers
            headers = {
                **request.headers,
                \"foo\": \"foo-value\", # set \"foo\" header
                \"bar\": None # remove \"bar\" header
            }
            route.continue_(headers=headers)

        page.route(\"**/*\", handle)
        ```

        **Details**

        The `headers` option applies to both the routed request and any redirects it initiates. However, `url`, `method`,
        and `post_data` only apply to the original request and are not carried over to redirected requests.

        `route.continue_()` will immediately send the request to the network, other matching handlers won't be invoked. Use
        `route.fallback()` If you want next matching handler in the chain to be invoked.

        **NOTE** Some request headers are **forbidden** and cannot be overridden (for example, `Cookie`, `Host`,
        `Content-Length` and others, see
        [this MDN page](https://developer.mozilla.org/en-US/docs/Glossary/Forbidden_request_header) for full list). If an
        override is provided for a forbidden header, it will be ignored and the original request header will be used.

        To set custom cookies, use `browser_context.add_cookies()`.

        Parameters
        ----------
        headers : Union[Dict[str, str], None]
            If set changes the request HTTP headers. Header values will be converted to a string.
        method : Union[str, None]
            If set changes the request method (e.g. GET or POST).
        post_data : Union[Any, bytes, str, None]
            If set changes the post data of request.
        url : Union[str, None]
            If set changes the request URL. New URL must have same protocol as original one.
        """

        self._sync(
            self._impl_obj.continue_(
                headers=mapping.to_impl(headers),
                method=method,
                postData=mapping.to_impl(post_data),
                url=url,
            )
        )

    def fallback(
        self,
        *,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        method: typing.Optional[str] = None,
        post_data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        url: typing.Optional[str] = None,
    ) -> None:
        """Route.fallback

        Continues route's request with optional overrides. The method is similar to `route.continue_()` with the difference
        that other matching handlers will be invoked before sending the request.

        **Usage**

        When several routes match the given pattern, they run in the order opposite to their registration. That way the
        last registered route can always override all the previous ones. In the example below, request will be handled by
        the bottom-most handler first, then it'll fall back to the previous one and in the end will be aborted by the first
        registered route.

        ```py
        page.route(\"**/*\", lambda route: route.abort())  # Runs last.
        page.route(\"**/*\", lambda route: route.fallback())  # Runs second.
        page.route(\"**/*\", lambda route: route.fallback())  # Runs first.
        ```

        Registering multiple routes is useful when you want separate handlers to handle different kinds of requests, for
        example API calls vs page resources or GET requests vs POST requests as in the example below.

        ```py
        # Handle GET requests.
        def handle_get(route):
            if route.request.method != \"GET\":
                route.fallback()
                return
          # Handling GET only.
          # ...

        # Handle POST requests.
        def handle_post(route):
            if route.request.method != \"POST\":
                route.fallback()
                return
          # Handling POST only.
          # ...

        page.route(\"**/*\", handle_get)
        page.route(\"**/*\", handle_post)
        ```

        One can also modify request while falling back to the subsequent handler, that way intermediate route handler can
        modify url, method, headers and postData of the request.

        ```py
        def handle(route, request):
            # override headers
            headers = {
                **request.headers,
                \"foo\": \"foo-value\", # set \"foo\" header
                \"bar\": None # remove \"bar\" header
            }
            route.fallback(headers=headers)

        page.route(\"**/*\", handle)
        ```

        Use `route.continue_()` to immediately send the request to the network, other matching handlers won't be invoked in
        that case.

        Parameters
        ----------
        headers : Union[Dict[str, str], None]
            If set changes the request HTTP headers. Header values will be converted to a string.
        method : Union[str, None]
            If set changes the request method (e.g. GET or POST).
        post_data : Union[Any, bytes, str, None]
            If set changes the post data of request.
        url : Union[str, None]
            If set changes the request URL. New URL must have same protocol as original one. Changing the URL won't affect the
            route matching, all the routes are matched using the original request URL.
        """

        self._sync(
            self._impl_obj.fallback(
                headers=mapping.to_impl(headers),
                method=method,
                postData=mapping.to_impl(post_data),
                url=url,
            )
        )

    def fetch(
        self,
        *,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        max_redirects: typing.Optional[int] = None,
        max_retries: typing.Optional[int] = None,
        method: typing.Optional[str] = None,
        post_data: typing.Optional[typing.Union[str, bytes, typing.Any]] = None,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
        url: typing.Optional[str] = None,
    ) -> "APIResponse":
        """Route.fetch

        Performs the request and fetches result without fulfilling it, so that the response could be modified and then
        fulfilled.

        **Usage**

        ```py
        def handle(route):
            response = route.fetch()
            json = response.json()
            json[\"message\"][\"big_red_dog\"] = []
            route.fulfill(response=response, json=json)

        page.route(\"https://dog.ceo/api/breeds/list/all\", handle)
        ```

        **Details**

        Note that `headers` option will apply to the fetched request as well as any redirects initiated by it. If you want
        to only apply `headers` to the original request, but not to redirects, look into `route.continue_()` instead.

        Parameters
        ----------
        headers : Union[Dict[str, str], None]
            If set changes the request HTTP headers. Header values will be converted to a string.
        max_redirects : Union[int, None]
            Maximum number of request redirects that will be followed automatically. An error will be thrown if the number is
            exceeded. Defaults to `20`. Pass `0` to not follow redirects.
        max_retries : Union[int, None]
            Maximum number of times network errors should be retried. Currently only `ECONNRESET` error is retried. Does not
            retry based on HTTP response codes. An error will be thrown if the limit is exceeded. Defaults to `0` - no retries.
        method : Union[str, None]
            If set changes the request method (e.g. GET or POST).
        post_data : Union[Any, bytes, str, None]
            Allows to set post data of the request. If the data parameter is an object, it will be serialized to json string
            and `content-type` header will be set to `application/json` if not explicitly set. Otherwise the `content-type`
            header will be set to `application/octet-stream` if not explicitly set.
        timeout : Union[float, None]
            Request timeout in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout.
        url : Union[str, None]
            If set changes the request URL. New URL must have same protocol as original one.

        Returns
        -------
        APIResponse
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.fetch(
                    headers=mapping.to_impl(headers),
                    maxRedirects=max_redirects,
                    maxRetries=max_retries,
                    method=method,
                    postData=mapping.to_impl(post_data),
                    timeout=to_milliseconds(timeout),
                    url=url,
                )
            )
        )

    def fulfill(
        self,
        *,
        body: typing.Optional[typing.Union[str, bytes]] = None,
        content_type: typing.Optional[str] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        json: typing.Optional[typing.Any] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        response: typing.Optional["APIResponse"] = None,
        status: typing.Optional[int] = None,
    ) -> None:
        """Route.fulfill

        Fulfills route's request with given response.

        **Usage**

        An example of fulfilling all requests with 404 responses:

        ```py
        page.route(\"**/*\", lambda route: route.fulfill(
            status=404,
            content_type=\"text/plain\",
            body=\"not found!\"))
        ```

        An example of serving static file:

        ```py
        page.route(\"**/xhr_endpoint\", lambda route: route.fulfill(path=\"mock_data.json\"))
        ```

        Parameters
        ----------
        body : Union[bytes, str, None]
            Response body.
        content_type : Union[str, None]
            If set, equals to setting `Content-Type` response header.
        headers : Union[Dict[str, str], None]
            Response headers. Header values will be converted to a string.
        json : Union[Any, None]
            JSON response. This method will set the content type to `application/json` if not set.
        path : Union[pathlib.Path, str, None]
            File path to respond with. The content type will be inferred from file extension. If `path` is a relative path,
            then it is resolved relative to the current working directory.
        response : Union[APIResponse, None]
            `APIResponse` to fulfill route's request with. Individual fields of the response (such as headers) can be
            overridden using fulfill options.
        status : Union[int, None]
            Response status code, defaults to `200`.
        """

        self._sync(
            self._impl_obj.fulfill(
                body=body,
                contentType=content_type,
                headers=mapping.to_impl(headers),
                json=mapping.to_impl(json),
                path=path,
                response=response._impl_obj if response else None,
                status=status,
            )
        )

    @property
    def request(self) -> "Request":
        """Route.request

        A request to be routed.

        Returns
        -------
        Request
        """
        return mapping.from_impl(self._impl_obj.request)


mapping.register(RouteImpl, Route)


class Screencast(SyncBase):
    _impl_obj: ScreencastImpl

    def hide_actions(self) -> None:
        """Screencast.hide_actions

        Removes action decorations.
        """

        self._sync(self._impl_obj.hide_actions())

    def hide_overlays(self) -> None:
        """Screencast.hide_overlays

        Hides overlays without removing them.
        """

        self._sync(self._impl_obj.hide_overlays())

    def show_actions(
        self,
        *,
        cursor: typing.Optional[Literal["none", "pointer"]] = None,
        duration: typing.Optional[float] = None,
        font_size: typing.Optional[int] = None,
        position: typing.Optional[
            Literal[
                "bottom", "bottom-left", "bottom-right", "top", "top-left", "top-right"
            ]
        ] = None,
        style: typing.Optional[ScreencastActionStyle] = None,
    ) -> "SyncContextManager":
        """Screencast.show_actions

        Enables visual annotations on interacted elements. Returns a disposable that stops showing actions when disposed.

        Parameters
        ----------
        cursor : Union["none", "pointer", None]
            Cursor decoration shown for pointer actions. `"pointer"` (the default) renders a mouse pointer that animates from
            the previous action point to the next one. `"none"` disables the cursor decoration.
        duration : Union[float, None]
            How long each annotation is displayed in milliseconds. Defaults to `500`.
        font_size : Union[int, None]
            Font size of the action title in pixels. Defaults to `24`.
            Deprecated: Use `title` in `style` instead, for example `style: { title: 'font-size: 32px' }`.
        position : Union["bottom", "bottom-left", "bottom-right", "top", "top-left", "top-right", None]
            Position of the action title overlay. Defaults to `"top-right"`.
        style : Union[{point: Union[str, None], highlight: Union[str, None], title: Union[str, None]}, None]
            Styles of the action decorations. All decorations fade out over `duration`.

            **Usage**

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.show_actions(
                    cursor=cursor,
                    duration=duration,
                    fontSize=font_size,
                    position=position,
                    style=style,
                )
            )
        )

    def show_chapter(
        self,
        title: str,
        *,
        description: typing.Optional[str] = None,
        duration: typing.Optional[float] = None,
    ) -> None:
        """Screencast.show_chapter

        Shows a chapter overlay with a title and optional description, centered on the page with a blurred backdrop. Useful
        for narrating video recordings. The overlay is removed after the specified duration, or 2000ms.

        Parameters
        ----------
        title : str
            Title text displayed prominently in the overlay.
        description : Union[str, None]
            Optional description text displayed below the title.
        duration : Union[float, None]
            Duration in milliseconds after which the overlay is automatically removed. Defaults to `2000`.
        """

        self._sync(
            self._impl_obj.show_chapter(
                title=title, description=description, duration=duration
            )
        )

    def show_overlay(
        self, html: str, *, duration: typing.Optional[float] = None
    ) -> "SyncContextManager":
        """Screencast.show_overlay

        Adds an overlay with the given HTML content. The overlay is displayed on top of the page until removed. Returns a
        disposable that removes the overlay when disposed.

        Parameters
        ----------
        html : str
            HTML content for the overlay.
        duration : Union[float, None]
            Duration in milliseconds after which the overlay is automatically removed. Overlay stays until dismissed if not
            provided.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(self._impl_obj.show_overlay(html=html, duration=duration))
        )

    def show_overlays(self) -> None:
        """Screencast.show_overlays

        Shows overlays.
        """

        self._sync(self._impl_obj.show_overlays())

    def start(
        self,
        *,
        fps: typing.Optional[int] = None,
        on_frame: typing.Optional[
            typing.Callable[[ScreencastFrame], typing.Any]
        ] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
        quality: typing.Optional[int] = None,
        size: typing.Optional[ScreencastSize] = None,
    ) -> "SyncContextManager":
        """Screencast.start

        Starts the screencast. When `path` is provided, it saves video recording to the specified file. When `on_frame` is
        provided, delivers JPEG-encoded frames to the callback. Both can be used together.

        **Usage**

        Parameters
        ----------
        fps : Union[int, None]
            Frame rate of the video recording in frames per second. Only used together with `path`. Defaults to `25`.

            Higher frame rates make animations and scrolling smoother at the cost of more CPU spent on encoding. Combine with
            `size` to record high resolution videos. The video can only contain as many distinct frames as the browser
            produces; Firefox and WebKit currently capture up to 25 frames per second.
        on_frame : Union[Callable[[{data: bytes, timestamp: float, viewportWidth: int, viewportHeight: int}], Any], None]
            Callback that receives JPEG-encoded frame data along with the page viewport size at the time of capture.
        path : Union[pathlib.Path, str, None]
            Path where the video should be saved when the screencast is stopped. When provided, video recording is started.
        quality : Union[int, None]
            The quality of the image, between 0-100.
        size : Union[{width: int, height: int}, None]
            Specifies the dimensions of screencast frames. The actual frame is scaled to preserve the page's aspect ratio and
            may be smaller than these bounds. If a screencast is already active (e.g. started by tracing or video recording),
            the existing configuration takes precedence and the frame size may exceed these bounds or this option may be
            ignored. If not specified the size will be equal to page viewport scaled down to fit into 800×800.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.start(
                    fps=fps,
                    onFrame=self._wrap_handler(on_frame),
                    path=path,
                    quality=quality,
                    size=size,
                )
            )
        )

    def stop(self) -> None:
        """Screencast.stop

        Stops the screencast and video recording if active. If a video was being recorded, saves it to the path specified
        in `screencast.start()`.
        """

        self._sync(self._impl_obj.stop())


mapping.register(ScreencastImpl, Screencast)


class Selectors(SyncBase):
    _impl_obj: SelectorsImpl

    def register(
        self,
        name: str,
        script: typing.Optional[str] = None,
        *,
        content_script: typing.Optional[bool] = None,
        path: typing.Optional[typing.Union[str, pathlib.Path]] = None,
    ) -> None:
        """Selectors.register

        Selectors must be registered before creating the page.

        **Usage**

        An example of registering selector engine that queries elements based on a tag name:

        ```py
        from playwright.sync_api import sync_playwright, Playwright

        def run(playwright: Playwright):
            tag_selector = \"\"\"
              {
                  // Returns the first element matching given selector in the root's subtree.
                  query(root, selector) {
                      return root.querySelector(selector);
                  },
                  // Returns all elements matching given selector in the root's subtree.
                  queryAll(root, selector) {
                      return Array.from(root.querySelectorAll(selector));
                  }
              }\"\"\"

            # Register the engine. Selectors will be prefixed with \"tag=\".
            playwright.selectors.register(\"tag\", tag_selector)
            browser = playwright.chromium.launch()
            page = browser.new_page()
            page.set_content('<div><button>Click me</button></div>')

            # Use the selector prefixed with its name.
            button = page.locator('tag=button')
            # Combine it with built-in locators.
            page.locator('tag=div').get_by_text('Click me').click()
            # Can use it in any methods supporting selectors.
            button_count = page.locator('tag=button').count()
            print(button_count)
            browser.close()

        with sync_playwright() as playwright:
            run(playwright)
        ```

        Parameters
        ----------
        name : str
            Name that is used in selectors as a prefix, e.g. `{name: 'foo'}` enables `foo=myselectorbody` selectors. May only
            contain `[a-zA-Z0-9_]` characters.
        script : Union[str, None]
            Raw script content.
        content_script : Union[bool, None]
            Whether to run this selector engine in isolated JavaScript environment. This environment has access to the same
            DOM, but not any JavaScript objects from the frame's scripts. Defaults to `false`. Note that running as a content
            script is not guaranteed when this engine is used together with other registered engines.
        path : Union[pathlib.Path, str, None]
            Path to the JavaScript file. If `path` is a relative path, then it is resolved relative to the current working
            directory.
        """

        self._sync(
            self._impl_obj.register(
                name=name, script=script, contentScript=content_script, path=path
            )
        )

    def set_test_id_attribute(self, attribute_name: str) -> None:
        """Selectors.set_test_id_attribute

        Defines custom attribute name to be used in `page.get_by_test_id()`. `data-testid` is used by default.

        Parameters
        ----------
        attribute_name : str
            Test id attribute name. To match elements with any of several attributes, pass them as a comma-separated list, e.g.
            `"data-pw,data-ti"`.
        """

        self._impl_obj.set_test_id_attribute(attributeName=attribute_name)


mapping.register(SelectorsImpl, Selectors)


class Touchscreen(SyncBase):
    _impl_obj: TouchscreenImpl

    def tap(self, x: float, y: float) -> None:
        """Touchscreen.tap

        Dispatches a `touchstart` and `touchend` event with a single touch at the position (`x`,`y`).

        **NOTE** `touchscreen.tap()` will throw if the `has_touch` option of the browser context is false.

        Parameters
        ----------
        x : float
            X coordinate relative to the main frame's viewport in CSS pixels.
        y : float
            Y coordinate relative to the main frame's viewport in CSS pixels.
        """

        self._sync(self._impl_obj.tap(x=x, y=y))


mapping.register(TouchscreenImpl, Touchscreen)


class Tracing(SyncBase):
    _impl_obj: TracingImpl

    def group(
        self, name: str, *, location: typing.Optional[TracingGroupLocation] = None
    ) -> "SyncContextManager":
        """Tracing.group

        **NOTE** Use `test.step` instead when available.

        Creates a new group within the trace, assigning any subsequent API calls to this group, until `tracing.group_end()`
        is called. Groups can be nested and will be visible in the trace viewer.

        **Usage**

        ```py
        # All actions between group and group_end
        # will be shown in the trace viewer as a group.
        page.context.tracing.group(\"Open Playwright.dev > API\")
        page.goto(\"https://playwright.dev/\")
        page.get_by_role(\"link\", name=\"API\").click()
        page.context.tracing.group_end()
        ```

        Parameters
        ----------
        name : str
            Group name shown in the trace viewer.
        location : Union[{file: str, line: Union[int, None], column: Union[int, None]}, None]
            Specifies a custom location for the group to be shown in the trace viewer. Defaults to the location of the
            `tracing.group()` call.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(self._impl_obj.group(name=name, location=location))
        )

    def group_end(self) -> None:
        """Tracing.group_end

        Closes the last group created by `tracing.group()`.
        """

        self._sync(self._impl_obj.group_end())

    def start(
        self,
        *,
        aria_snapshots: typing.Optional[bool] = None,
        live: typing.Optional[bool] = None,
        name: typing.Optional[str] = None,
        screen_snapshots: typing.Optional[bool] = None,
        screenshots: typing.Optional[bool] = None,
        snapshots: typing.Optional[bool] = None,
        sources: typing.Optional[bool] = None,
        title: typing.Optional[str] = None,
    ) -> "SyncContextManager":
        """Tracing.start

        Start tracing. Disposing the returned `Disposable` stops tracing without saving the trace, similarly to calling
        `tracing.stop()` without a path.

        **NOTE** You probably want to
        [enable tracing in your config file](https://playwright.dev/docs/api/class-testoptions#test-options-trace) instead
        of using `Tracing.start`.

        The `context.tracing` API captures browser operations and network activity, but it doesn't record test assertions
        (like `expect` calls). We recommend
        [enabling tracing through Playwright Test configuration](https://playwright.dev/docs/api/class-testoptions#test-options-trace),
        which includes those assertions and provides a more complete trace for debugging test failures.

        **Usage**

        ```py
        context.tracing.start(screenshots=True, snapshots=True)
        page = context.new_page()
        page.goto(\"https://playwright.dev\")
        context.tracing.stop(path = \"trace.zip\")
        ```

        Parameters
        ----------
        aria_snapshots : Union[bool, None]
            Whether to capture aria snapshot of the page on every action.
        live : Union[bool, None]
            When enabled, the trace is written to an unarchived file that is updated in real time as actions occur, instead of
            caching changes and archiving them into a zip file at the end. This is useful for live trace viewing during test
            execution.
        name : Union[str, None]
            If specified, intermediate trace files are going to be saved into the files with the given name prefix inside the
            `traces_dir` directory specified in `browser_type.launch()`. To specify the final trace zip file name, you need to
            pass `path` option to `tracing.stop()` instead.
        screen_snapshots : Union[bool, None]
            Whether to capture a screenshot of the page on every action.
        screenshots : Union[bool, None]
            Whether to capture screenshots during tracing. Screenshots are used to build a timeline preview.
        snapshots : Union[bool, None]
            Whether to capture DOM snapshot and record network activity on every action.
        sources : Union[bool, None]
            Whether to include source files for trace actions.
        title : Union[str, None]
            Trace name to be shown in the Trace Viewer.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.start(
                    ariaSnapshots=aria_snapshots,
                    live=live,
                    name=name,
                    screenSnapshots=screen_snapshots,
                    screenshots=screenshots,
                    snapshots=snapshots,
                    sources=sources,
                    title=title,
                )
            )
        )

    def start_chunk(
        self, *, name: typing.Optional[str] = None, title: typing.Optional[str] = None
    ) -> "SyncContextManager":
        """Tracing.start_chunk

        Start a new trace chunk. Disposing the returned `Disposable` stops the chunk without saving it, similarly to
        calling `tracing.stop_chunk()` without a path. If you'd like to record multiple traces on the same
        `BrowserContext`, use `tracing.start()` once, and then create multiple trace chunks with `tracing.start_chunk()`
        and `tracing.stop_chunk()`.

        **Usage**

        ```py
        context.tracing.start(screenshots=True, snapshots=True)
        page = context.new_page()
        page.goto(\"https://playwright.dev\")

        context.tracing.start_chunk()
        page.get_by_text(\"Get Started\").click()
        # Everything between start_chunk and stop_chunk will be recorded in the trace.
        context.tracing.stop_chunk(path = \"trace1.zip\")

        context.tracing.start_chunk()
        page.goto(\"http://example.com\")
        # Save a second trace file with different actions.
        context.tracing.stop_chunk(path = \"trace2.zip\")
        ```

        Parameters
        ----------
        name : Union[str, None]
            If specified, intermediate trace files are going to be saved into the files with the given name prefix inside the
            `traces_dir` directory specified in `browser_type.launch()`. To specify the final trace zip file name, you need to
            pass `path` option to `tracing.stop_chunk()` instead.
        title : Union[str, None]
            Trace name to be shown in the Trace Viewer.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(self._impl_obj.start_chunk(name=name, title=title))
        )

    def start_har(
        self,
        path: typing.Union[str, pathlib.Path],
        *,
        content: typing.Optional[Literal["attach", "embed", "omit"]] = None,
        mode: typing.Optional[Literal["full", "minimal"]] = None,
        url_filter: typing.Optional[typing.Union[str, typing.Pattern[str]]] = None,
    ) -> "SyncContextManager":
        """Tracing.start_har

        Start recording a HAR (HTTP Archive) of network activity in this context. The HAR file is written to disk when
        `tracing.stop_har()` is called, or when the returned `Disposable` is disposed.

        Only one HAR recording can be active at a time per `Tracing` instance.

        **Usage**

        ```py
        context.tracing.start_har(\"trace.har\")
        page = context.new_page()
        page.goto(\"https://playwright.dev\")
        context.tracing.stop_har()
        ```

        Parameters
        ----------
        path : Union[pathlib.Path, str]
            Path on the filesystem to write the HAR file to. If the file name ends with `.zip`, the HAR is saved as a zip
            archive with response bodies attached as separate files.
        content : Union["attach", "embed", "omit", None]
            Optional setting to control resource content management. If `omit` is specified, content is not persisted. If
            `attach` is specified, resources are persisted as separate files or entries in the ZIP archive. If `embed` is
            specified, content is stored inline the HAR file as per HAR specification. Defaults to `attach` for `.zip` output
            files and to `embed` for all other file extensions.
        mode : Union["full", "minimal", None]
            When set to `minimal`, only record information necessary for routing from HAR. This omits sizes, timing, page,
            cookies, security and other types of HAR information that are not used when replaying from HAR. Defaults to `full`.
        url_filter : Union[Pattern[str], str, None]
            A glob or regex pattern to filter requests that are stored in the HAR. Defaults to none.

        Returns
        -------
        SyncContextManager
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.start_har(
                    path=path, content=content, mode=mode, urlFilter=url_filter
                )
            )
        )

    def stop(
        self, *, path: typing.Optional[typing.Union[str, pathlib.Path]] = None
    ) -> None:
        """Tracing.stop

        Stop tracing.

        Parameters
        ----------
        path : Union[pathlib.Path, str, None]
            Export trace into the file with the given path.
        """

        self._sync(self._impl_obj.stop(path=path))

    def stop_chunk(
        self, *, path: typing.Optional[typing.Union[str, pathlib.Path]] = None
    ) -> None:
        """Tracing.stop_chunk

        Stop the trace chunk. See `tracing.start_chunk()` for more details about multiple trace chunks.

        Parameters
        ----------
        path : Union[pathlib.Path, str, None]
            Export trace collected since the last `tracing.start_chunk()` call into the file with the given path.
        """

        self._sync(self._impl_obj.stop_chunk(path=path))

    def stop_har(self) -> None:
        """Tracing.stop_har

        Stop HAR recording and save the HAR file to the path given to `tracing.start_har()`.
        """

        self._sync(self._impl_obj.stop_har())


mapping.register(TracingImpl, Tracing)


class Video(SyncBase):
    _impl_obj: VideoImpl

    def delete(self) -> None:
        """Video.delete

        Deletes the video file. Will wait for the video to finish if necessary.
        """

        self._sync(self._impl_obj.delete())

    def path(self) -> pathlib.Path:
        """Video.path

        Returns the file system path this video will be recorded to. The video is guaranteed to be written to the
        filesystem upon closing the browser context. This method throws when connected remotely.

        Returns
        -------
        pathlib.Path
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.path()))

    def save_as(self, path: typing.Union[str, pathlib.Path]) -> None:
        """Video.save_as

        Saves the video to a user-specified path. It is safe to call this method while the video is still in progress, or
        after the page has closed. This method waits until the page is closed and the video is fully saved.

        Parameters
        ----------
        path : Union[pathlib.Path, str]
            Path where the video should be saved.
        """

        self._sync(self._impl_obj.save_as(path=path))


mapping.register(VideoImpl, Video)


class WebError(SyncBase):
    _impl_obj: WebErrorImpl

    @property
    def error(self) -> "Error":
        """WebError.error

        Unhandled error that was thrown.

        Returns
        -------
        Error
        """
        return mapping.from_impl(self._impl_obj.error)

    @property
    def location(self) -> WebErrorLocation:
        """WebError.location

        Returns
        -------
        {url: str, line: int, column: int}
        """
        return mapping.from_impl(self._impl_obj.location)

    @property
    def page(self) -> typing.Optional["Page"]:
        """WebError.page

        The page that produced this unhandled exception, if any.

        Returns
        -------
        Union[Page, None]
        """
        return mapping.from_impl_nullable(self._impl_obj.page)


mapping.register(WebErrorImpl, WebError)


class WebMCP(SyncBase):
    _impl_obj: WebMCPImpl

    def call_tool(
        self,
        name: str,
        input: typing.Optional[typing.Any] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Any:
        """WebMCP.call_tool

        Calls a tool registered by the frame and returns its result. The result is whatever the tool's `execute` function
        resolved to, typically an object with a `content` array. A result with `isError: true` is returned as is. The
        method throws when the tool is not registered or its `execute` function throws.

        Parameters
        ----------
        name : str
            Name of the tool, as reported by `web_mcp.tools()`.
        input : Union[Any, None]
            Input for the tool, matching its `inputSchema`. Defaults to an empty object.
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.call_tool(
                    name=name,
                    input=mapping.to_impl(input),
                    timeout=to_milliseconds(timeout),
                )
            )
        )

    def tools(
        self,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.List[WebMCPTool]:
        """WebMCP.tools

        Returns the tools currently registered by the frame. Throws if the browser was launched without WebMCP support, see
        the note above for the launch options that enable it.

        `page.webmcp` covers the main frame only, child frames list their tools through their own `frame.webmcp`.

        Parameters
        ----------
        timeout : Union[float, None]
            Maximum time in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The default value can
            be changed by using the `browser_context.set_default_timeout()` or `page.set_default_timeout()` methods.

        Returns
        -------
        List[{name: str, description: str, inputSchema: Union[Any, None], annotations: Union[{readOnly: Union[bool, None], untrustedContent: Union[bool, None], consequential: Union[bool, None]}, None]}]
        """

        return mapping.from_impl_list(
            self._sync(self._impl_obj.tools(timeout=to_milliseconds(timeout)))
        )


mapping.register(WebMCPImpl, WebMCP)


class WebSocket(SyncBase):
    _impl_obj: WebSocketImpl

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["close"],
        predicate: typing.Optional[typing.Callable[["WebSocket"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["WebSocket"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["framereceived"],
        predicate: typing.Optional[
            typing.Callable[["typing.Union[bytes, str]"], bool]
        ] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["typing.Union[bytes, str]"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["framesent"],
        predicate: typing.Optional[
            typing.Callable[["typing.Union[bytes, str]"], bool]
        ] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["typing.Union[bytes, str]"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["socketerror"],
        predicate: typing.Optional[typing.Callable[["str"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["str"]: ...

    @typing.overload
    def expect_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable[..., bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager[typing.Any]: ...

    def expect_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager:
        """WebSocket.expect_event

        Waits for event to fire and passes its value into the predicate function. Returns when the predicate returns truthy
        value. Will throw an error if the webSocket is closed before the event is fired. Returns the event data value.

        Parameters
        ----------
        event : str
            Event name, same one would pass into `webSocket.on(event)`.
        predicate : Union[Callable, None]
            Receives the event data and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_event(
                event=event,
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    def is_closed(self) -> bool:
        """WebSocket.is_closed

        Indicates that the web socket has been closed.

        Returns
        -------
        bool
        """

        return mapping.from_maybe_impl(self._impl_obj.is_closed())

    @typing.overload
    def on(
        self, event: Literal["close"], f: typing.Callable[["WebSocket"], "None"]
    ) -> None:
        """
        Fired when the websocket closes."""

    @typing.overload
    def on(
        self,
        event: Literal["framereceived"],
        f: typing.Callable[["typing.Union[bytes, str]"], "None"],
    ) -> None:
        """
        Fired when the websocket receives a frame."""

    @typing.overload
    def on(
        self,
        event: Literal["framesent"],
        f: typing.Callable[["typing.Union[bytes, str]"], "None"],
    ) -> None:
        """
        Fired when the websocket sends a frame."""

    @typing.overload
    def on(
        self, event: Literal["socketerror"], f: typing.Callable[["str"], "None"]
    ) -> None:
        """
        Fired when the websocket has an error."""

    def on(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().on(event=event, f=f)

    @typing.overload
    def once(
        self, event: Literal["close"], f: typing.Callable[["WebSocket"], "None"]
    ) -> None:
        """
        Fired when the websocket closes."""

    @typing.overload
    def once(
        self,
        event: Literal["framereceived"],
        f: typing.Callable[["typing.Union[bytes, str]"], "None"],
    ) -> None:
        """
        Fired when the websocket receives a frame."""

    @typing.overload
    def once(
        self,
        event: Literal["framesent"],
        f: typing.Callable[["typing.Union[bytes, str]"], "None"],
    ) -> None:
        """
        Fired when the websocket sends a frame."""

    @typing.overload
    def once(
        self, event: Literal["socketerror"], f: typing.Callable[["str"], "None"]
    ) -> None:
        """
        Fired when the websocket has an error."""

    def once(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().once(event=event, f=f)

    @property
    def url(self) -> str:
        """WebSocket.url

        Contains the URL of the WebSocket.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["close"],
        predicate: typing.Optional[typing.Callable[["WebSocket"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "WebSocket": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["framereceived"],
        predicate: typing.Optional[
            typing.Callable[["typing.Union[bytes, str]"], bool]
        ] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "typing.Union[bytes, str]": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["framesent"],
        predicate: typing.Optional[
            typing.Callable[["typing.Union[bytes, str]"], bool]
        ] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "typing.Union[bytes, str]": ...

    @typing.overload
    def wait_for_event(
        self,
        event: typing.Literal["socketerror"],
        predicate: typing.Optional[typing.Callable[["str"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> "str": ...

    @typing.overload
    def wait_for_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable[..., bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> typing.Any: ...

    def wait_for_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> typing.Any:
        """WebSocket.wait_for_event

        **NOTE** In most cases, you should use `web_socket.expect_event()`.

        Waits for given `event` to fire. If predicate is provided, it passes event's value into the `predicate` function
        and waits for `predicate(event)` to return a truthy value. Will throw an error if the socket is closed before the
        `event` is fired.

        Parameters
        ----------
        event : str
            Event name, same one typically passed into `*.on(event)`.
        predicate : Union[Callable, None]
            Receives the event data and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.wait_for_event(
                    event=event,
                    predicate=self._wrap_handler(predicate),
                    timeout=to_milliseconds(timeout),
                )
            )
        )


mapping.register(WebSocketImpl, WebSocket)


class WebSocketRoute(SyncBase):
    _impl_obj: WebSocketRouteImpl

    def close(
        self, *, code: typing.Optional[int] = None, reason: typing.Optional[str] = None
    ) -> None:
        """WebSocketRoute.close

        Closes one side of the WebSocket connection.

        Parameters
        ----------
        code : Union[int, None]
            Optional [close code](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/close#code).
        reason : Union[str, None]
            Optional [close reason](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/close#reason).
        """

        self._sync(self._impl_obj.close(code=code, reason=reason))

    def connect_to_server(self) -> "WebSocketRoute":
        """WebSocketRoute.connect_to_server

        By default, routed WebSocket does not connect to the server, so you can mock entire WebSocket communication. This
        method connects to the actual WebSocket server, and returns the server-side `WebSocketRoute` instance, giving the
        ability to send and receive messages from the server.

        Once connected to the server:
        - Messages received from the server will be **automatically forwarded** to the WebSocket in the page, unless
          `web_socket_route.on_message()` is called on the server-side `WebSocketRoute`.
        - Messages sent by the [`WebSocket.send()`](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/send) call
          in the page will be **automatically forwarded** to the server, unless `web_socket_route.on_message()` is called
          on the original `WebSocketRoute`.

        See examples at the top for more details.

        Returns
        -------
        WebSocketRoute
        """

        return mapping.from_impl(self._impl_obj.connect_to_server())

    def on_close(
        self,
        handler: typing.Callable[
            [typing.Optional[int], typing.Optional[str]], typing.Any
        ],
    ) -> None:
        """WebSocketRoute.on_close

        Allows to handle [`WebSocket.close`](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/close).

        By default, closing one side of the connection, either in the page or on the server, will close the other side.
        However, when `web_socket_route.on_close()` handler is set up, the default forwarding of closure is disabled, and
        handler should take care of it.

        Parameters
        ----------
        handler : Callable[[Union[int, None], Union[str, None]], Any]
            Function that will handle WebSocket closure. Received an optional
            [close code](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/close#code) and an optional
            [close reason](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/close#reason).
        """

        self._impl_obj.on_close(handler=self._wrap_handler(handler))

    def on_message(
        self, handler: typing.Callable[[typing.Union[str, bytes]], typing.Any]
    ) -> None:
        """WebSocketRoute.on_message

        This method allows to handle messages that are sent by the WebSocket, either from the page or from the server.

        When called on the original WebSocket route, this method handles messages sent from the page. You can handle this
        messages by responding to them with `web_socket_route.send()`, forwarding them to the server-side connection
        returned by `web_socket_route.connect_to_server()` or do something else.

        Once this method is called, messages are not automatically forwarded to the server or to the page - you should do
        that manually by calling `web_socket_route.send()`. See examples at the top for more details.

        Calling this method again will override the handler with a new one.

        Parameters
        ----------
        handler : Callable[[Union[bytes, str]], Any]
            Function that will handle messages.
        """

        self._impl_obj.on_message(handler=self._wrap_handler(handler))

    @property
    def protocols(self) -> typing.List[str]:
        """WebSocketRoute.protocols

        The list of WebSocket subprotocols requested by the page, as passed via the second argument to the
        [`WebSocket` constructor](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/WebSocket). Corresponds to the
        `Sec-WebSocket-Protocol` request header.

        Returns an empty array if no protocols were specified.

        **Usage**

        ```py
        def handler(ws: WebSocketRoute):
          if \"chat.v2\" in ws.protocols:
            ws.on_message(lambda message: ws.send(f\"v2:{message}\"))
          else:
            ws.close(code=1002, reason=\"Unsupported protocol\")

        page.route_web_socket(\"wss://example.com/ws\", handler)
        ```

        Returns
        -------
        List[str]
        """
        return mapping.from_maybe_impl(self._impl_obj.protocols)

    def send(self, message: typing.Union[str, bytes]) -> None:
        """WebSocketRoute.send

        Sends a message to the WebSocket. When called on the original WebSocket, sends the message to the page. When called
        on the result of `web_socket_route.connect_to_server()`, sends the message to the server. See examples at the top
        for more details.

        Parameters
        ----------
        message : Union[bytes, str]
            Message to send.
        """

        self._impl_obj.send(message=message)

    @property
    def url(self) -> str:
        """WebSocketRoute.url

        URL of the WebSocket created in the page.

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)


mapping.register(WebSocketRouteImpl, WebSocketRoute)


class WebStorage(SyncBase):
    _impl_obj: WebStorageImpl

    def clear(self) -> None:
        """WebStorage.clear

        Removes all items from the storage.
        """

        self._sync(self._impl_obj.clear())

    def get_item(self, name: str) -> typing.Optional[str]:
        """WebStorage.get_item

        Returns the value for the given `name` if present.

        Parameters
        ----------
        name : str
            Name of the item to retrieve.

        Returns
        -------
        Union[str, None]
        """

        return mapping.from_maybe_impl(self._sync(self._impl_obj.get_item(name=name)))

    def items(self) -> typing.List[NameValue]:
        """WebStorage.items

        Returns all items in the storage as name/value pairs.

        Returns
        -------
        List[{name: str, value: str}]
        """

        return mapping.from_impl_list(self._sync(self._impl_obj.items()))

    def remove_item(self, name: str) -> None:
        """WebStorage.remove_item

        Removes the item with the given `name`. No-op if the item is absent.

        Parameters
        ----------
        name : str
            Name of the item to remove.
        """

        self._sync(self._impl_obj.remove_item(name=name))

    def set_item(self, name: str, value: str) -> None:
        """WebStorage.set_item

        Sets the value for the given `name`. Overwrites any existing value for that name.

        Parameters
        ----------
        name : str
            Name of the item to set.
        value : str
            New value for the item.
        """

        self._sync(self._impl_obj.set_item(name=name, value=value))


mapping.register(WebStorageImpl, WebStorage)


class Worker(SyncBase):
    _impl_obj: WorkerImpl

    def evaluate(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> typing.Any:
        """Worker.evaluate

        Returns the return value of `expression`.

        If the function passed to the `worker.evaluate()` returns a [Promise], then `worker.evaluate()` would wait for the
        promise to resolve and return its value.

        If the function passed to the `worker.evaluate()` returns a non-[Serializable] value, then `worker.evaluate()`
        returns `undefined`. Playwright also supports transferring some additional values that are not serializable by
        `JSON`: `-0`, `NaN`, `Infinity`, `-Infinity`.

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        Any
        """

        return mapping.from_maybe_impl(
            self._sync(
                self._impl_obj.evaluate(expression=expression, arg=mapping.to_impl(arg))
            )
        )

    def evaluate_handle(
        self, expression: str, arg: typing.Optional[typing.Any] = None
    ) -> "JSHandle":
        """Worker.evaluate_handle

        Returns the return value of `expression` as a `JSHandle`.

        The only difference between `worker.evaluate()` and `worker.evaluate_handle()` is that `worker.evaluate_handle()`
        returns `JSHandle`.

        If the function passed to the `worker.evaluate_handle()` returns a [Promise], then `worker.evaluate_handle()` would
        wait for the promise to resolve and return its value.

        Parameters
        ----------
        expression : str
            JavaScript expression to be evaluated in the browser context. If the expression evaluates to a function, the
            function is automatically invoked.
        arg : Union[Any, None]
            Optional argument to pass to `expression`.

        Returns
        -------
        JSHandle
        """

        return mapping.from_impl(
            self._sync(
                self._impl_obj.evaluate_handle(
                    expression=expression, arg=mapping.to_impl(arg)
                )
            )
        )

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["close"],
        predicate: typing.Optional[typing.Callable[["Worker"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["Worker"]: ...

    @typing.overload
    def expect_event(
        self,
        event: typing.Literal["console"],
        predicate: typing.Optional[typing.Callable[["ConsoleMessage"], bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager["ConsoleMessage"]: ...

    @typing.overload
    def expect_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable[..., bool]] = None,
        *,
        timeout: typing.Optional[float] = None,
    ) -> EventContextManager[typing.Any]: ...

    def expect_event(
        self,
        event: str,
        predicate: typing.Optional[typing.Callable] = None,
        *,
        timeout: typing.Optional[typing.Union[float, datetime.timedelta]] = None,
    ) -> EventContextManager:
        """Worker.expect_event

        Waits for event to fire and passes its value into the predicate function. Returns when the predicate returns truthy
        value. Will throw an error if the page is closed before the event is fired. Returns the event data value.

        **Usage**

        ```py
        with worker.expect_event(\"console\") as event_info:
            worker.evaluate(\"console.log(42)\")
        message = event_info.value
        ```

        Parameters
        ----------
        event : str
            Event name, same one typically passed into `*.on(event)`.
        predicate : Union[Callable, None]
            Receives the event data and resolves to truthy value when the waiting should resolve.
        timeout : Union[float, None]
            Maximum time to wait for in milliseconds. Defaults to `30000` (30 seconds). Pass `0` to disable timeout. The
            default value can be changed by using the `browser_context.set_default_timeout()`.

        Returns
        -------
        EventContextManager
        """
        return EventContextManager(
            self,
            self._impl_obj.expect_event(
                event=event,
                predicate=self._wrap_handler(predicate),
                timeout=to_milliseconds(timeout),
            ).future,
        )

    @typing.overload
    def on(
        self, event: Literal["close"], f: typing.Callable[["Worker"], "None"]
    ) -> None:
        """
        Emitted when this dedicated [WebWorker](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API) is
        terminated."""

    @typing.overload
    def on(
        self, event: Literal["console"], f: typing.Callable[["ConsoleMessage"], "None"]
    ) -> None:
        """
        Emitted when JavaScript within the worker calls one of console API methods, e.g. `console.log` or `console.dir`.
        """

    def on(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().on(event=event, f=f)

    @typing.overload
    def once(
        self, event: Literal["close"], f: typing.Callable[["Worker"], "None"]
    ) -> None:
        """
        Emitted when this dedicated [WebWorker](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API) is
        terminated."""

    @typing.overload
    def once(
        self, event: Literal["console"], f: typing.Callable[["ConsoleMessage"], "None"]
    ) -> None:
        """
        Emitted when JavaScript within the worker calls one of console API methods, e.g. `console.log` or `console.dir`.
        """

    def once(self, event: str, f: typing.Callable[..., None]) -> None:
        return super().once(event=event, f=f)

    @property
    def url(self) -> str:
        """Worker.url

        Returns
        -------
        str
        """
        return mapping.from_maybe_impl(self._impl_obj.url)


mapping.register(WorkerImpl, Worker)
